<?php 

//header

//include_once("include/header.php");

?>



            <!--Main Slider-->

            <section class="main-slider slider-two">

                <div class="icon-one"></div>

                <div class="icon-two"></div>

                <div class="icon-three"></div>

                <div class="icon-four"></div>

                <div class="icon-five"></div>

                <div class="icon-six"></div>

                <div class="container-fluid">

                    <div class="container-fluid">

                        <div class="rev_slider_wrapper fullwidthbanner-container" id="rev_slider_one_wrapper" data-source="gallery">

                            <div class="rev_slider fullwidthabanner" id="rev_slider_one" data-version="5.4.1">

                                <ul>

                                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1688" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-1.png" alt="pic" data-title="Slide Title" data-transition="parallaxvertical">

                                        <img alt="pic" class="rev-slidebg" data-bgfit="cover" data-bgparallax="" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="<?php echo base_url('assets/images/image-1.jpg');?>">



                                 <div class="tp-caption tp-shape rs-parallaxlevel-4 tp-shapewrapper tp-resizeme big-ipad-hidden" 

                                data-basealign="slide"

                                data-paddingbottom="[0,0,0,0]"

                                data-paddingleft="[0,0,0,0]"

                                data-paddingright="[0,0,0,0]"

                                data-paddingtop="[0,0,0,0]"

                                data-responsive_offset="on"

                                data-type="shape"

                                data-height="auto"

                                data-whitespace="nowrap"

                                data-width="none"

                                data-hoffset="['0','0','0','0']"

                                data-voffset="['85','0','0','0']"

                                data-x="['right','right','right','right']"

                                data-y="['top','top','top','top']"

                                data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                                    <figure class="content-image"><img src="<?php echo base_url('assets/images/cloud.png');?>" alt="pic"></figure>

                                </div>





                     

                                        <img alt="pic" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="<?php //echo base_url('assets/images/ii/ima.png');?>">

                                        <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive_offset="on" data-type="shape" data-height="auto" data-whitespace="nowrap" data-width="none" data-hoffset="['0','0','0','0']" data-voffset="['0','0','0','0']" data-x="['right','right','right','right']" data-y="['middle','middle','middle','middle']" data-frames='[{"from":"x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1000,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                                        <figure class="content-image image-one"><img src="<?php echo base_url('assets/images/ima.png');?>" alt="pic"></figure>

                                        </div>

                                        <div class="tp-caption tp-resizeme" data-paddingbottom="[0,0,0,0]" data-paddingleft="[0,0,0,0]" data-paddingright="[0,0,0,0]" data-paddingtop="[0,0,0,0]" data-responsive_offset="on" data-type="text" data-height="none" data-width="['820','700','650','420']" data-whitespace="normal" data-hoffset="['15','15','15','15']" data-voffset="['0','0','0','0']" data-x="['left','left','left','left']" data-y="['middle','middle','middle','middle']" data-textalign="['top','top','top','top']" data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                                            <h1>DIGITAL <br> <span class="market1">MARKETING</span></h1>

                                        </div>

                                    </li>

                                </ul>

                            </div>

                        </div>

                    </div>

                </div>

            <!--End Main Slider-->

            <!-- Feature Section -->

            <section class="feature-section mar-feature-section">

                <div class="auto-container">

                    <div class="sec-title text-center">

                        <span class="title color-text">Simplifying Business Process</span>

                        <h2>WHAT WE DO<br></h2>

                    </div>



                    <div class="container">
                      <div class="row">
                        <!-- Feature Block -->
                            <div class=" col-md-4 col-sm-6 col-xs-12">

                                <div class="box botry">

                                  <div class="btn-6">

                                    <span>

                                       <div class="lt_box">

                                           <div class="icon-box">

                                                <i class="flaticon-target-2">

                                                    <img src="<?php echo base_url('assets/images/icons/service_01.png');?>" alt="pic">

                                                </i>

                                            </div>

                                       </div> 

                                       <div class="rt_box">

                                           <h3><a href="">MARKET RESERCH</a></h3>

                                           <p>We start your digital marketing campaign with the market research activities. We research the marketing strategies of your competitors in order to plan a good strategy for your project.</p>

                                          

                                       </div> 

                                       <div class="clearfix"></div> 

                                    </span>

                                  </div>

                                </div>
                            </div>
                            <!-- Feature Block -->
                            <!-- Feature Block -->
                            <div class=" col-md-4 col-sm-6 col-xs-12">

                                <div class="box botry">

                                  <div class="btn-6">

                                    <span>

                                       <div class="lt_box">

                                           <div class="icon-box">

                                                <i class="flaticon-target-2">

                                                    <img src="<?php echo base_url('assets/images/icons/service_02.png');?>" alt="pic">

                                                </i>

                                            </div>

                                       </div> 

                                       <div class="rt_box">

                                           <h3><a href="">ADWORDS</a></h3>

                                           <p>Google AdWords is the most sought marketing activity in the world of marketing. With the help of search advertising and display advertising, we craft different strategy that gives immense power of direct selling.</p>

                                           

                                       </div> 

                                       <div class="clearfix"></div> 

                                    </span>

                                  </div>

                                </div>
                            </div>
                            <!-- Feature Block -->
                            <!-- Feature Block -->
                            <div class=" col-md-4 col-sm-6 col-xs-12">

                                <div class="box botry">

                                  <div class="btn-6">

                                    <span>

                                       <div class="lt_box">

                                           <div class="icon-box">

                                                <i class="flaticon-target-2">

                                                    <img src="<?php echo base_url('assets/images/icons/service_03.png');?>" alt="pic">

                                                </i>

                                            </div>

                                       </div> 

                                       <div class="rt_box">

                                           <h3><a href="">SOCIAL MEDIA MARKETING</a></h3>

                                           <p>Social media is the emerging trend and we know how to use it in the most innovative way to sell your products or services. Our social media marketers keep themselves updated for the latest social media trends for running a successful campaign. We are one of the leading social media marketing companies in Kolkata.</p>

                                       </div> 

                                       <div class="clearfix"></div> 

                                    </span>

                                  </div>

                                </div>
                            </div>
                            <!-- Feature Block -->
                            <div class="clearfix"></div>
                      </div>
                   </div>
                   <div class="container">
                              <div class="row">
                                <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_03.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">CONTENT MARKETING</a></h3>

                                                   <p>Content marketing is all about distribution and marketing of content about your business. Our content marketing services shows the excellence of your brand and creates a positive image of your brand in front of consumers. </p>

                                                  

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_05.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">INFLUNCE MARKETING</a></h3>

                                                   <p>With the emerging trend of social media, there arises the new type of marketing called the influence marketing. In this marketing we market your products and services through social media influencers who have millions of followers. </p>

                                                   

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_06.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">SEO</a></h3>

                                                   <p>We provide the most affordable, effective and scalable SEO services across the globe. With thousands of top ranking keywords, we target the most searched keywords for your business in order to get good position in SERPs.</p>

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <div class="clearfix"></div>
                              </div>
                   </div>
                   <div class="container">
                              <div class="row">
                                <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_03.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">AD COPYWRITING</a></h3>

                                                   <p>We also provide copywriting services. It is essential to provide good copy for the ad in order to attract the consumers. We are the agency that helps you to provide the best kind of ad copywriting for your business.</p>

                                                  

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_05.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">INFO GRAPHICS</a></h3>

                                                   <p>Infographic is the way to provide engaging content in the most innovative way to your potential customers. We have creative graphic designers who put the content and design effectively in order to provide the enchanting Infographic for marketing.</p>

                                                   

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_06.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">EMAIL MARKETING</a></h3>

                                                   <p>We target you clients through their inboxes. There are many Internet users who regularly check their email accounts. We create a nicely crafted email newsletter and send it in bulk in order to target your customers.</p>

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <div class="clearfix"></div>
                              </div>
                   </div>
                   <div class="container">
                              <div class="row">
                                <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                             <img src="<?php echo base_url('assets/images/icons/service_03.png');?>" alt="pic">
                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">MOBILE MARKETING</a></h3>

                                                   <p>Mobile is the most important device in everyone’s life and majority of the people spent lots of hours on their mobile. Mobile marketing is the new trend in the digital world and we are effectively providing them as the best marketing strategy.</p>

                                                  

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_05.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">PAID TRAFFIC</a></h3>

                                                   <p>We also provide different types of paid traffic on different search engines like Google, Bing. Right from PPC to Pay per impression, we are here to help you through the paid advertisement on different platforms including social media.</p>

                                                   

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <!-- Feature Block -->
                                    <div class=" col-md-4 col-sm-6 col-xs-12">

                                        <div class="box botry">

                                          <div class="btn-6">

                                            <span>

                                               <div class="lt_box">

                                                   <div class="icon-box">

                                                        <i class="flaticon-target-2">

                                                            <img src="<?php echo base_url('assets/images/icons/service_06.png');?>" alt="pic">

                                                        </i>

                                                    </div>

                                               </div> 

                                               <div class="rt_box">

                                                   <h3><a href="">WEB ANALYTICS</a></h3>

                                                   <p>We provide accurate analytics for your marketing projects. You can expect a regular analysis of your website and its performance on different marketing channels from our company. Our detailed report includes all the necessary statistics that will help to create next marketing strategy.</p>

                                               </div> 

                                               <div class="clearfix"></div> 

                                            </span>

                                          </div>

                                        </div>
                                    </div>
                                    <!-- Feature Block -->
                                    <div class="clearfix"></div>
                              </div>
                   </div>

                </div>

            </section>

            <!-- Feature Section -->

            <!-- Fact counter -->

            <section class="fun-fact-section marcating_funsection">

                <div class="auto-container">

                    <div class="row clearfix">

                        <!-- Count box -->

                        <div class="count-box col-md-3 col-sm-6 col-xs-12">

                            <div class="content-box">

                                <div class="icon-box"><span class="flaticon-deal"><img src="<?php echo base_url('assets/images/icons/fact1.png');?>" alt="pic" ></span></div>

                                <div class="count-outer">

                                    <span class="count-text" data-speed="5000" data-stop="3000">0</span>

                                </div>

                                <div class="counter-title">Client Base</div>

                            </div>

                        </div>

                        <!-- Count box -->

                        <div class="count-box col-md-3 col-sm-6 col-xs-12">

                            <div class="content-box">

                                <div class="icon-box"><span class="flaticon-deal"><img src="<?php echo base_url('assets/images/icons/fact2.png');?>" alt="pic" ></span></div>

                                <div class="count-outer">

                                    <span class="count-text" data-speed="2000" data-stop="100">0</span>

                                </div>

                                <div class="counter-title">Team Size</div>

                            </div>

                        </div>

                        <!-- Count box -->

                        <div class="count-box col-md-3 col-sm-6 col-xs-12">

                            <div class="content-box">

                                <div class="icon-box"><span class="flaticon-folder-2"><img src="<?php echo base_url('assets/images/icons/fact3.png');?>" alt="pic" ></span></div>

                                <div class="count-outer">

                                    <span class="count-text" data-speed="2000" data-stop="9000">0</span>

                                </div>

                                <div class="counter-title">Project Done</div>

                            </div>

                        </div>

                        <!-- Count box -->

                        <div class="count-box col-md-3 col-sm-6 col-xs-12">

                            <div class="content-box">

                                <div class="icon-box"><span class="flaticon-maintenance"><img src="<?php echo base_url('assets/images/icons/fact4.png');?>" alt="pic" ></span></div>

                                <div class="count-outer">

                                    <span class="count-text" data-speed="2000" data-stop="10">0</span>

                                </div>

                                <div class="counter-title">Professional Experiance</div>

                            </div>

                        </div>

                    </div>

                </div>

            </section>

            <!-- End Fact counter -->

            <!-- ---------------------------Our Working Process--- -->

            <section class="section">

                <div class="elimonitar_work">

                    <div class="auto-container">

                        <div class="body_workpro">

                            <!-- headding section -->

                            <div class="sec-title text-center">

                                <span class="title color-text">EASY STEPS</span>

                                <h2>Our Working Process</h2>

                            </div>

                            <!-- End headding section -->

                            <div class="row">

                                <!-- First Section -->

                                <div class="col-md-3 text-center">

                                    <div class="tw-case-working-box">

                                        <div class="working-icon-wrapper">

                                            <div class="working-icon">

                                                <img src="<?php echo base_url('assets/images/process1.png');?>" alt="pic">

                                                <span class="case-process-number">1</span>

                                            </div>

                                        </div>

                                        <h3>01. Research Project</h3>

                                    </div>

                                </div>

                                <!--End First Section -->

                                <!-- second Section -->

                                <div class="col-md-3 text-center">

                                    <div class="tw-case-working-box">

                                        <div class="working-icon-wrapper">

                                            <div class="working-icon">

                                                <img src="<?php echo base_url('assets/images/process2.png');?>" alt="pic">

                                                <span class="case-process-number">2</span>

                                            </div>

                                        </div>

                                        <h3>02. Find Ideas</h3>

                                    </div>

                                </div>

                                <!--End second Section -->

                                <!-- Third Section -->

                                <div class="col-md-3 text-center">

                                    <div class="tw-case-working-box">

                                        <div class="working-icon-wrapper">

                                            <div class="working-icon">

                                                <img src="<?php echo base_url('assets/images/process3.png');?>" alt="pic">

                                                <span class="case-process-number">3</span>

                                            </div>

                                        </div>

                                        <h3>03. Start Optimize</h3>

                                    </div>

                                </div>

                                <!--End Third Section -->

                                <!-- Fourth Section -->

                                <div class="col-md-3 text-center">

                                    <div class="tw-case-working-box">

                                        <div class="working-icon-wrapper">

                                            <div class="working-icon">

                                                <img src="<?php echo base_url('assets/images/process4.png');?>" alt="pic">

                                                <span class="case-process-number">4</span>

                                            </div>

                                        </div>

                                        <h3>04. Reach Target</h3>

                                    </div>

                                </div>

                                <!--End Fourth Section -->

                            </div>

                        </div>

                    </div>

                </div>

            </section>

            <!-- Our Working Process end--------------------- -->

            <!-- Pricing Section -->

              <section class="pricing-section services-section pa_dding">

                  

                  <!--End Pricing Section -->

                  <!-- contact section -->

                  <section id="contact" class="contact color-bg text-center ask_expart pa_dding">

                      <div class="container">

                          <div class="get_touch">

                              <h2>Ask and Expart</h2>

                          </div>

                          <p>Out believe has request not how comfort evident. Up delight cousins we feeling minutes.

                          <br> Genius has looked end piqued spring.</p>

                          <div class="form-group">

                              <button type="btn" class="theme-btn btn-style-one" href="contact.php">More Info<i class="flaticon-play"></i></button>

                          </div>

                      </div>

                      <!-- contact section start-->

                  </section>

                  <!-- clients logo start -->

                  <?php 

                      //clients logo

                     // include_once("template-part/clients-logo.php");

                       $this->load->view('template-part/clients-logo');

                      ?>

                      <!-- clients logo end -->

              </section>

              <?php

              // include_once("template-part/contact-part.php"); 

                $this->load->view('template-part/contact-part');


               ?>

            </section>       

        <?php 

//footer

//include("include/footer.php");

?>