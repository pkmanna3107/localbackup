<?php 



//header



//include_once("include/header.php");



?>

    <!--Main Banner Section-->

    <section class="main-banner-section">

        <span class="left-curve"></span>

        <span class="top-icon"></span>

        <span class="icon-four"></span>

        <span class="icon-five"></span>

        <div class="auto-container">

            <div class="inner-container" style="background-image:url(assets/images/background/2.jpg)">

                <div class="circle-one"></div>

                <div class="icon-one"></div>

                <div class="icon-two"></div>

                <div class="icon-three"></div>

                <div class="icon-six"></div>

                <div class="icon-seven"></div>

                <div class="icon-eight"></div>

                <div class="icon-nine"></div>

                <div class="icon-ten"></div>

                <div class="icon-eleven"></div>

                <h2>Creative People</h2>

                <div class="text">Turn your ideas into scalable business with our<br> Top web design and web development solutions </div>

                <div class="scroll scroll-to-target" data-target=".about-section">Scroll</div>

                <div class="side-image"><img src="<?php echo base_url('assets/images/resource/banner-image.png');?>" alt="pic" /></div>

                <!-- <ul class="social-icon-one">

                    <li><a href="#"><span class="fa fa-facebook"></span></a></li>

                    <li><a href="#"><span class="fa fa-twitter"></span></a></li>

                    <li><a href="#"><span class="fa fa-google-plus"></span></a></li>

                    <li><a href="#"><span class="fa fa-pinterest"></span></a></li>

                    <li><a href="#"><span class="fa fa-dribbble"></span></a></li>

                </ul> -->

            </div>

        </div>

    </section>

    <!--End Main Banner Section-->

    <!--About Section-->

<div class="page-wrapper bg-lines social-icon-left">

    <section class="about-section">

      <div class="sec-title text-center mt-top">
          <h2>Turn Your Thoughts into Reality!</h2>
          <p>We enhance your business opportunity with cutting-edge web solutions. We are best website design company in Kolkata India.</p>
      </div>
          <div class="container">
              <!-- Feature Block -->
              <div class="row">
                  <div class=" col-md-4 col-sm-6 col-xs-12">
                      <div class="box botry">

                        <div class="btn-6">

                          <span>

                             <div class="lt_box">

                                 <div class="icon-box">

                                      <i class="flaticon-target-2">

                                          <img src="<?php echo base_url('assets/images/icons/service_01.png');?>" alt="pic" />

                                      </i>

                                  </div>

                             </div> 

                             <div class="rt_box">

                                 <h3><a href="">Corporate Web Design</a></h3>

                                 <p>Our team of web designers works on a project and leads it towards a successful website design. Web design is the most embellishing part of the website and therefore we create the entire site with an aim to make it compelling and communicable. </p>

                             </div> 

                             <div class="clearfix"></div> 

                          </span>

                        </div>
                      </div>
                  </div>
              <!-- Feature Block -->
              <!-- Feature Block -->
                  <div class=" col-md-4 col-sm-6 col-xs-12">

                      <div class="box botry">

                        <div class="btn-6">

                          <span>

                             <div class="lt_box">

                                 <div class="icon-box">

                                      <i class="flaticon-target-2">

                                          <img src="<?php echo base_url('assets/images/icons/service_02.png');?>" alt="pic" />

                                      </i>

                                  </div>

                             </div> 

                             <div class="rt_box">

                                 <h3><a href="">Landing pages</a></h3>

                                 <p>We not only work to make your websites appealing, but we also aim to get increased visibility of your websites through landing pages. We create engaging and customized landing pages in order to maximum your businesses reach towards maximum number of customers.</p>

                             </div> 

                             <div class="clearfix"></div> 

                          </span>

                        </div>

                      </div>
                  </div>
              <!-- Feature Block -->
              <!-- Feature Block -->
                  <div class=" col-md-4 col-sm-6 col-xs-12">
                      <div class="box botry">

                        <div class="btn-6">

                          <span>

                             <div class="lt_box">

                                 <div class="icon-box">

                                      <i class="flaticon-target-2">

                                          <img src="<?php echo base_url('assets/images/icons/service_03.png');?>" alt="pic" />

                                      </i>

                                  </div>

                             </div> 

                             <div class="rt_box">

                                 <h3><a href="">e-Commerce websites</a></h3>

                                 <p>We deliver aspiring and world-class ecommerce websites. We have a team of talented ecommerce developers who thinks out of the box like an online shopping freak. We work on the best ecommerce platforms including Magneto, Woo commerce, Shopify and many others.</p>

                             </div> 

                             <div class="clearfix"></div> 

                          </span>

                        </div>

                      </div>
                  </div>
                <div class="clearfix"></div>
            </div>
        </div>
        <div class="container">
            <div class="row">
              <!-- Feature Block -->
                  <div class=" col-md-4 col-sm-6 col-xs-12">

                      <div class="box botry">

                        <div class="btn-6">

                          <span>

                             <div class="lt_box">

                                 <div class="icon-box">

                                      <i class="flaticon-target-2">

                                          <img src="<?php echo base_url('assets/images/icons/service_04.png');?>" alt="pic" />

                                      </i>

                                  </div>

                             </div> 

                             <div class="rt_box">

                                 <h3><a href="">Custom Web Development</a></h3>

                                 <p>We are the leader in delivering conversion services to acquire uniqueness in your business. We ultimately exceed your expectations, as we always keep pace with the latest technology and trends and include them our projects to achieve desired and even better output.</p>

                                

                             </div> 

                             <div class="clearfix"></div> 

                          </span>

                        </div>

                      </div>
                  </div>
                  <!-- Feature Block -->
                  <!-- Feature Block -->
                  <div class=" col-md-4 col-sm-6 col-xs-12">

                      <div class="box botry">

                        <div class="btn-6">

                          <span>

                             <div class="lt_box">

                                 <div class="icon-box">

                                      <i class="flaticon-target-2">

                                          <img src="<?php echo base_url('assets/images/icons/service_05.png');?>" alt="pic" />

                                      </i>

                                  </div>

                             </div> 

                             <div class="rt_box">

                                 <h3><a href="">Mobile App development</a></h3>

                                 <p>We empower your business with our outstanding mobile application development. With the immense experience, we build over hundreds of applications which are highly scalable and efficient. Our highly automated and feature pack mobile app is the way towards a successful business.</p>

                                 

                             </div> 

                             <div class="clearfix"></div> 

                          </span>

                        </div>

                      </div>
                  </div>
                  <!-- Feature Block -->
                  <!-- Feature Block -->
                  <div class=" col-md-4 col-sm-6 col-xs-12">

                      <div class="box botry">

                        <div class="btn-6">

                          <span>

                             <div class="lt_box">

                                 <div class="icon-box">

                                      <i class="flaticon-target-2">

                                          <img src="<?php echo base_url('assets/images/icons/service_06.png');?>" alt="pic" />

                                      </i>

                                  </div>

                             </div> 

                             <div class="rt_box">

                                 <h3><a href="">Wireframe And Mockup</a></h3>

                                 <p>Wireframe or mockup is one of the key components of planning for a website or an application. We create a static mockup or wireframe for a full working process of website in order to get a complete idea of your website.</p>

                             </div> 

                             <div class="clearfix"></div> 

                          </span>

                        </div>

                      </div>
                  </div>
                  <!-- Feature Block -->
                  <div class="clearfix"></div>
            </div>
        </div>
    <!--End About Section-->
    <section class="web-services">
        <div class="container">
            <div class="sec-title text-center">

                <h2 class="one-color">One Stop Solutions for Everything.</h2>

            </div>

            <div class="row">

                <div class="mege-webmenu">

                    <div class="col-md-4">

                        <div class="wt-100">

                            <div class="ServicesTitle">

                                <h4>Web</h4>

                            </div>

                            <ul>

                                <li>JavaScript Development</li>

                                <li class="ssub-title">

                                    <a href="">AngularJS</a>

                                    <a href="">ReactJS</a>

                                    <a href="">NodeJS</a>

                                    <a href=""> VueJS</a>

                                    <a href="">MeteorJS</a>

                                </li>

                            </ul>

                        </div>

                    </div>

                    <div class="col-md-4">

                        <div class="wt-100">

                            <div class="ServicesTitle">

                                <h4>Mobile</h4>

                            </div>

                            <ul>

                                <li>Mobile Development</li>

                                <li class="ssub-title">

                                    <a href="">iOS</a>

                                    <a href="">Android</a>

                                    <a href="">React Native</a>

                                    <a href=""> Hybrid</a>

                                </li>

                            </ul>

                        </div>

                    </div>

                    <div class="col-md-4">

                        <div class="wt-100">

                            <div class="ServicesTitle">

                                <h4>Cloud</h4>

                            </div>

                            <ul>

                                <li>JavaScript Development</li>

                                <li class="ssub-title">

                                    <a href="">AWS</a>

                                    <a href="">Google Cloud</a>

                                    <a href="">VPS</a>

                                    <a href="">Linux</a>

                                </li>

                            </ul>

                        </div>

                    </div>

                </div>

            </div>

            <!-- 2nd line -->

            <div class="row">

                <div class="mege-webmenu">

                    <div class="col-md-4">

                        <div class="wt-100">

                            <div class="ServicesTitle">

                                <h4>Web Development</h4>

                            </div>

                            <ul>

                                <li class="ssub-title bon">

                                    <a href="">PHP</a>

                                    <a href="">Laravel</a>

                                    <a href="">Codeigniter</a>

                                    <a href="">Python</a>

                                </li>

                            </ul>

                        </div>

                    </div>

                    <div class="col-md-4">

                        <div class="wt-100">

                            <div class="ServicesTitle">

                                <h4>Concept/Design</h4>

                            </div>

                            <ul>

                                <li>Wireframes/Prototyping</li>

                                <li class="ssub-title">

                                    <a href="">UI </a>

                                    <a href="">DesignResponsive</a>

                                    <a href="">Design</a>

                                    <a href=""> VueJS</a>

                                    <a href="">MeteorJS</a>

                                    <a href="">Bootstrap / css</a>

                                </li>

                            </ul>

                        </div> 

                    </div>

                    <div class="col-md-4">

                        <div class="wt-100">

                            <div class="ServicesTitle">

                                <h4>Trending</h4>

                            </div>

                            <ul>

                                <li>JavaScript Development</li>

                                <li class="ssub-title">

                                    <a href="">LoT</a>

                                    <a href="">Chatbot</a>

                                    <a href="">NodeJS</a>

                                    <a href=""> VueJS</a>

                                    <a href="">MeteorJS</a>

                                </li>

                            </ul>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <!-- How to work -->

<div class="clear"></div>

<section class="fw-main-row">

    <div class="container">

        <div class="sec-title text-center now-in-view">

            <h2 class="one-color">How We Work</h2>

        </div>

        <div class="fw-theme-steps">

            <!-- row start -->

            <div class="row">

                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2">

                        <h2 class="step-title ">Project initiation<span>01</span></h2>

                    </div>

                </div>

                <div class="col-md-4">

                    <div class="fw-step-right-part2">

                        <img src="<?php echo base_url('assets/images/gallery/38.jpg');?>" alt="pic" />

                    </div>

                </div>

                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2">

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>

                             Resource Allocation

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                             Documentation

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            Basecamp Account

                         </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>  

                            Project Mange

                        </p>

                    </div>

                </div>

            </div>

            <!-- row-end -->



                        <!-- row start -->

            <div class="row bottom1">

                <div class="fw-step-mean-wrap">

                <div class="col-md-4 pull">

                    <div class="fw-step-right-part right-part2">

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>

                             Visualization

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                             Research &amp; Analysis

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            Schema

                         </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>  

                            Wireframe

                        </p>

                    </div>

                </div>

                <div class="col-md-4 pu1">

                    <div class="fw-step-right-part2 fw-step-left-part2">

                        <img src="<?php echo base_url('assets/images/gallery/39.jpg');?>" alt="pic" />

                    </div>

                </div>

                <div class="col-md-4 pull1">

                    <div class="fw-step-left-part right-part2">

                        <h2 class="step-title color1">Conceptualization <span>02</span></h2>

                    </div>

                </div>

            </div>

        </div>

            <!-- row-end -->



         <!-- row start -->

        <div class="row">

                <div class="fw-step-mean-wrap">

                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2">

                        <h2 class="step-title">Designing<span class="color-3">03</span></h2>

                    </div>

                </div>



                <div class="col-md-4">

                    <div class="fw-step-right-part2">

                        <img src="<?php echo base_url('assets/images/gallery/40.jpg');?>" alt="pic" />

                    </div>



                </div>





                <div class="col-md-4">



                    <div class="fw-step-right-part right-part2 pd_dding">

                         <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>

                            Art Work/PSD

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                             Client Approval

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            HTML/Front End Development

                         </p>

                    </div>





                </div>

            </div>

        </div>

        <!-- row-end -->



       <!-- row start -->

        <div class="row">

                <div class="fw-step-mean-wrap">

                <div class="col-md-4 punt2">

                    <div class="fw-step-right-part right-part2 bort notrr">

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>

                            Coding

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                             CMS Development

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            Server Realization

                        </p>

                    </div>

                </div>

                <div class="col-md-4 punt">

                    <div class="fw-step-right-part2 fw-step-left-part2 last-fw-step dpd">

                        <img src="<?php echo base_url('assets/images/gallery/41.jpg');?>" alt="pic" />

                    </div>

                </div>

                <div class="col-md-4 punt1">

                    <div class="fw-step-left-part right-part2 top-bottom1">

                        <h2 class="step-title color1 development1">Development<span class="color-4">04</span></h2>

                    </div>

                </div>

            </div>

        </div>

        <!-- row-end -->

         <!-- row start -->

        <div class="row">

                <div class="fw-step-mean-wrap">

                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2 bt-top top-bottom">

                        <h2 class="step-title ">Beta Launch<span class="color-3">05</span></h2>

                    </div>

                </div>



                <div class="col-md-4">

                    <div class="fw-step-right-part2">

                        <img src="<?php echo base_url('assets/images/gallery/40.jpg');?>" alt="pic" />

                    </div>



                </div>



                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2 bto1">

                         <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>

                            Demo Deployment

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                             Client Acceptance

                        </p>

                    </div>





                </div>

            </div>

        </div>

        <!-- row-end -->  

         <!-- row start -->

        <div class="row">

                <div class="fw-step-mean-wrap">

                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2 nt-top1">

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>

                            Quality Check &amp; Control

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            Bug Removal

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            Browser Compatibility

                        </p>

                    </div>

                </div>



                <div class="col-md-4">

                    <div class="fw-step-right-part2 fw-step-left-part2 last-fw-step">

                        <img src="<?php echo base_url('assets/images/gallery/41.jpg');?>" alt="pic" />

                    </div>

                </div>





                <div class="col-md-4">

                    <div class="fw-step-left-part right-part2 bit-pad top-bottom2">

                        <h2 class="step-title color1">Testing <span class="color-4">06</span></h2>

                    </div>

                </div>

            </div>

        </div>

        <!-- row-end --> 

        <!-- row start -->

        <div class="row">

                <div class="fw-step-mean-wrap">

                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2 final">

                        <h2 class="step-title ">Final Launch<span class="color-3">07</span></h2>

                    </div>

                </div>



                <div class="col-md-4">

                    <div class="fw-step-right-part2">

                        <img src="<?php echo base_url('assets/images/gallery/40.jpg');?>" alt="pic" />

                    </div>



                </div>



                <div class="col-md-4">

                    <div class="fw-step-right-part right-part2">

                         <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span>

                            Final Deployment

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            Code Transfer

                        </p>

                        <p class="step-text">

                            <span><i class="fa fa-circle" aria-hidden="true"></i></span> 

                            90 Days Support

                        </p>

                    </div>





                </div>

            </div>

        </div>

        <!-- row-end --> 

    </div>

</div>

</section>









            <?php 



            //footer



         //   include_once("template-part/contact-part.php");







            ?>

<?php $this->load->view('template-part/contact-part'); ?>

</section>

</div>

           <?php 



            //footer



        //    include_once("include/footer.php");







            ?>



