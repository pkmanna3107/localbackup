<?php 

//header

include_once("include/header.php");



?>

    <!--Page Title-->

    <section class="page-title" style="background-image:url(images/background/1.jpg);">

        <div class="auto-container">

            <!-- Animated Icons -->

            <div class="anim-icons">

                <span class="icon-1"></span>

                <span class="icon-2"></span>

                <span class="icon-3"></span>

                <span class="icon-4"></span>

                <span class="icon-5"></span>

                <span class="icon-6"></span>

                <span class="icon-7"></span>

                <span class="icon-8"></span>

                <span class="icon-9"></span>

            </div>

            

            <h1>Project Fullwidth</h1>

            <ul class="bread-crumb">

                <li><a href="index.html">Home </a></li>

                <li>Project Fullwidth</li>

            </ul>

        </div>

    </section>

    <!--End Page Title-->



    <!-- Gallery Section -->

    <section class="project-section full-width">

        <div class="outer-container">

             <!--MixitUp Galery-->

            <div class="mixitup-gallery">

                <div class="inner-container clearfix">

                    <!--Filter-->

                    <div class="filters text-center clearfix">                     

                        <ul class="filter-tabs filter-btns clearfix">

                            <li class="filter active" data-role="button" data-filter="all">All</li>

                            <li class="filter" data-role="button" data-filter=".design">Design</li>

                            <li class="filter" data-role="button" data-filter=".marketing">Marketing</li>

                            <li class="filter" data-role="button" data-filter=".develpoing">Develpoing</li>

                            <li class="filter" data-role="button" data-filter=".branding">Branding</li>

                            <li class="filter" data-role="button" data-filter=".business">Business</li>

                        </ul>

                    </div>   

                </div>



                <div class="filter-list row clearfix">

                    <!-- Project Block -->

                    <div class="project-block mix all business branding col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/1.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all branding marketing col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/2.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all develpoing branding marketing business col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/3.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all branding marketing develpoing col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/4.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all business design business design col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/5.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all branding marketing develpoing col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/6.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all branding business marketing design col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/7.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all branding marketing develpoing col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/8.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all branding business marketing col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/9.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all develpoing branding marketing col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/10.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all business branding marketing design col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/11.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block mix all branding marketing develpoing business col-lg-3 col-md-4 col-sm-6 col-xs-12">

                        <div class="image-box">

                            <figure><img src="images/gallery/12.jpg" alt="pic"/></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>



            <!-- Btn box -->

            <div class="btn-box text-center">

                <a href="project-full-width.html" class="theme-btn btn-style-one">More work <i class="flaticon-play"></i></a>

            </div>

        </div>

    </section>

    <!-- Gallery Section -->



    <!-- Contact Section -->

    <section class="contact-section">

        <div class="auto-container">

            <div class="sec-title text-center">

                <span class="title">Contact Us</span>

                <h2>We can help your business with <br> our knoledge</h2>

            </div>



            <div class="row clearfix">

                <div class="form-column col-md-6 col-sm-12 col-xs-12">

                    <div class="contact-form">

                        <form method="post" action="http://t.commonsupport.com/timisoara/sendemail.php" id="contact-form">

                            <div class="form-group">

                                <input type="text" name="username" placeholder="Name" required="">

                            </div>

                            

                            <div class="form-group">

                                <input type="email" name="email" placeholder="Email" required="">

                            </div>



                            <div class="form-group">

                                <textarea name="message" placeholder="Your Message"></textarea>

                            </div>



                            <div class="form-group">

                                <button type="submit" class="theme-btn btn-style-one">Send Message <i class="flaticon-play"></i></button>

                            </div>

                        </form>

                    </div>

                </div>

                <!-- Contact Map -->

                <div class="map-column col-md-6 col-sm-12 col-xs-12">

                    <!--Map Outer-->

                    <div class="map-outer">

                        <!--Map Canvas-->

                        <div class="map-canvas"

                            data-zoom="1"

                            data-lat="-37.817085"

                            data-lng="144.955631"

                            data-type="roadmap"

                            data-hue="#ffc400"

                            data-title="Envato"

                            data-icon-path="images/icons/map-marker.png"

                            data-content="Melbourne VIC 3000, Australia<br><a href='mailto:info@youremail.com'>info@youremail.com</a>">

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <!--End Contact Section -->



            <?php 

            //footer

            include_once("include/footer.php");



            ?>

