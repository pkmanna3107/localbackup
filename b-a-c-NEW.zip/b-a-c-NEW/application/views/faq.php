
<?php 
//header
include_once("include/header.php");
?>


<section class="about-section-two1">
	<div class="text-center">
		<h2>BULK EMAIL MARKETING</h2>
	</div>
	<div class="container">


		<div class="row">
			<div class="col-md-6">
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
				    <div class="panel panel-default">
				      <div class="panel-heading" role="tab" id="headingOne">
				        <h4 class="panel-title">
				        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
				          Your Bulk Email service is used for what?
				        </a>
				      </h4>
				      </div>
				      <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
				        <div class="panel-body">
				          Good question. Do you need to send catchy email marketing campaigns, newsletters, special offers, event invitations, mass email and promotions via email? Then you are at the right place. Go on.
				        </div>
				      </div>
				    </div>
				    <div class="panel panel-default">
				      <div class="panel-heading" role="tab" id="headingTwo">
				        <h4 class="panel-title">
				        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
				          Tell me in short what is B.A.C.-Post?
				        </a>
				      </h4>
				      </div>
				      <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
				        <div class="panel-body">
				          It's a web-based, Do-It-Yourself, email marketing service that provides you with an advance email marketing software to design the emails and good mail servers to deliver it.
				        </div>
				      </div>
				    </div>
				    <div class="panel panel-default">
				      <div class="panel-heading" role="tab" id="headingThree">
				        <h4 class="panel-title">
				        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
				          Am I able to have different send from for each campaign?
				        </a>
				      </h4>
				      </div>
				      <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
				        <div class="panel-body">
				          Yes. Can use different from address for each campaign.
				        </div>
				      </div>
				    </div>
				    <div class="panel panel-default">
				      <div class="panel-heading" role="tab" id="headingThree1">
				        <h4 class="panel-title">
				        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree1" aria-expanded="false" aria-controls="collapseThree1">
				          Do I need to download and install your B.A.C. software on my PC?
				        </a>
				      </h4>
				      </div>
				      <div id="collapseThree1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree1">
				        <div class="panel-body">
				          Well, there is no software to download, its web-based software, means you can use it from an Internet browser (like Internet Explorer, Firefox) on any computer with an Internet connection.We know the age of 56K dialup connection is gone, so cheer.!
				        </div>
				      </div>
				    </div>
				    <div class="panel panel-default">
				      <div class="panel-heading" role="tab" id="headingThree2">
				        <h4 class="panel-title">
				        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree2" aria-expanded="false" aria-controls="collapseThree2">
				          Will my account get suspended after high bounce back? How does that work with you?
				        </a>
				      </h4>
				      </div>
				      <div id="collapseThree2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree2">
				        <div class="panel-body">
				          We do not have very strict bounce rate policy. However it is better to maintain low bounce for good delivery.
				        </div>
				      </div>
				    </div>
	  			</div>
			</div>
			<div class="col-md-6">
				<div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
				    <div class="panel panel-default">
				      <div class="panel-heading" role="tab" id="headingOne3">
				        <h4 class="panel-title">
				        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne3" aria-expanded="true" aria-controls="collapseOne3">
				          Your Bulk Email service is used for what?
				        </a>
				      </h4>
				      </div>
				      <div id="collapseOne3" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne3">
				        <div class="panel-body">
				          Good question. Do you need to send catchy email marketing campaigns, newsletters, special offers, event invitations, mass email and promotions via email? Then you are at the right place. Go on.
				        </div>
				      </div>
				    </div>
				    <!-- <div class="panel panel-default">
				      <div class="panel-heading" role="tab" id="headingThree2">
				        <h4 class="panel-title">
				        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree2" aria-expanded="false" aria-controls="collapseThree2">
				          Will my account get suspended after high bounce back? How does that work with you?
				        </a>
				      </h4>
				      </div>
				      <div id="collapseThree2" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree2">
				        <div class="panel-body">
				          We do not have very strict bounce rate policy. However it is better to maintain low bounce for good delivery.
				        </div>
				      </div>
				    </div> -->
	  			</div>
			</div>
		</div>
	  	<!-- <div class="panel-group" id="accordion" role="tablist" aria-multiselectable="true">
		    <div class="panel panel-default">
		      <div class="panel-heading" role="tab" id="headingOne">
		        <h4 class="panel-title">
		        <a role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
		          Collapsible Group Item #1
		        </a>
		      </h4>
		      </div>
		      <div id="collapseOne" class="panel-collapse collapse in" role="tabpanel" aria-labelledby="headingOne">
		        <div class="panel-body">
		          Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird
		          on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table,
		          raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
		        </div>
		      </div>
		    </div>
		    <div class="panel panel-default">
		      <div class="panel-heading" role="tab" id="headingTwo">
		        <h4 class="panel-title">
		        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
		          Collapsible Group Item #2
		        </a>
		      </h4>
		      </div>
		      <div id="collapseTwo" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingTwo">
		        <div class="panel-body">
		          Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird
		          on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table,
		          raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
		        </div>
		      </div>
		    </div>
		    <div class="panel panel-default">
		      <div class="panel-heading" role="tab" id="headingThree">
		        <h4 class="panel-title">
		        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
		          Collapsible Group Item #3
		        </a>
		      </h4>
		      </div>
		      <div id="collapseThree" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree">
		        <div class="panel-body">
		          Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird
		          on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table,
		          raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
		        </div>
		      </div>
		    </div>
		    <div class="panel panel-default">
		      <div class="panel-heading" role="tab" id="headingThree1">
		        <h4 class="panel-title">
		        <a class="collapsed" role="button" data-toggle="collapse" data-parent="#accordion" href="#collapseThree1" aria-expanded="false" aria-controls="collapseThree1">
		          Collapsible Group Item #4
		        </a>
		      </h4>
		      </div>
		      <div id="collapseThree1" class="panel-collapse collapse" role="tabpanel" aria-labelledby="headingThree1">
		        <div class="panel-body">
		          Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird
		          on it squid single-origin coffee nulla assumenda shoreditch et. Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table,
		          raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.
		        </div>
		      </div>
		    </div>
	  	</div> -->


	</div>

</section>


<?php 
	//footer
	include_once("include/footer.php")
?>