<?php 
//header
//include_once("include/header.php");
?>
<section class="about-section-two1">
   <div class="box1">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <img src="<?php echo base_url('assets/images/frontend.png');?>" alt="Sudip">
            </div>
            <div class="col-md-6 pd_bor">
              <h3>MISSION & VALUES</h3>
              <p>
                If you want to prepare your website to grow your business with optimum conversion, then you are at the right place. Business Alphabets is a prominent responsive web design, web development and digital marketing agency in Kolkata India which combine simplicity, excellence and usability to create a user-friendly web solution for your business.  If you have a goal to increase brand awareness or you want to sell your products or services, then we set a proven business processes to offer a smooth walk away with captivating user interfaces. Our user interface and user experience ensure uniform experience across multiple browser and hand held devices. More than creating a beautiful website, we concentrate on blending unique website development strategy that effectively turns your visitors into potential customers. 
              </p>
            </div>
          </div>
        </div>
   </div>
</section>
<section class="about-section-two1">
  <div class="container">
       <h2 class="project-name">OUR SPECIALIZATIONS</h2>
      <div id="timeline">
          <div class="timeline-item">
              <div class="timeline-icon">
                  <img src="<?php echo base_url('assets/images/icon.jpg');?>" alt="pic"/>
              </div>
              <div class="timeline-content">
                  <h2>HIGH END CODING</h2>
                  <p>We eat codes. We have some of the top class web developers who are passionate about developing innovative websites. Our front-end and back-end developers are here to build any kind of website. </p>
                  <a href="" class="btn">learn more</a>
              </div>
          </div>
          <div class="timeline-item">
              <div class="timeline-icon">
                <img src="<?php echo base_url('assets/images/icon1.jpg');?>" alt="pic"/>
              </div>
              <div class="timeline-content right">
                  <h2 class="lorsum">HASSLE-FREE SOLUTIONS</h2>
                  <p>Right from creating websites to market them we provide all sorts of digital solutions in the most hassle free manner. You will be habituated with our uninterrupted, flawless and scalable business solutions. </p>  
                  <a href="" class="btn">learn more</a>

              </div>
          </div>
          <div class="timeline-item">
              <div class="timeline-icon">
                  <img src="<?php echo base_url('assets/images/icon2.jpg');?>" alt="pic"/>
              </div>
              <div class="timeline-content">
                  <h2>RESPONSIVE DESIGN & TEMPLATES</h2>
                  <p>We target every customer on different digital platforms including the mobile devices. All our websites and applications are responsive to be fit perfectly on different mobile devices. Use our Responsive Web Design Services to redesign your existing site. </p> 
                  <a href="" class="btn">learn more</a>
              </div>
          </div>
          <div class="timeline-item">
              <div class="timeline-icon">
                <img src="<?php echo base_url('assets/images/icon3.jpg');?>" alt="pic"/>
              </div>
              <div class="timeline-content right">
                  <h2 class="lorsum">ONLINE PROMOTION</h2>
                  <p>We promote your products or services to reach maximum visibility. We create strong and continuous market strategies to get maximum attention from your customers and this will ultimately enhance your business revenue. </p>  
                  <a href="" class="btn">learn more</a>

              </div>
          </div>
          <div class="timeline-item">
              <div class="timeline-icon">
                  <img src="<?php echo base_url('assets/images/icon4.jpg');?>" alt="pic"/>
              </div>
              <div class="timeline-content">
                  <h2>ADVANCE REPORTING SYSTEM</h2>
                  <p>There are no smoke and mirror in our industry. We always follow the rule of transparency and provide up to date reports to our clients. We make customized reports for every project to provide a good insight for your business. </p> 
                  <a href="" class="btn">learn more</a>
              </div>
          </div>
      </div>
  </div>
</section>

<?php 
//footer
//include_once("include/footer.php");
?>

