<?php 

//header

include_once("include/header.php");



?>

<style>header nav ul li a{color: #252a37 !important;}</style>

    <!-- Error Page Section -->

    <section class="error-page-section full-height" style="background-image: url(images/background/3.jpg);">

        <div class="auto-container">

            <span class="icon-1 drop-icon"></span>

            <span class="icon-2 drop-icon-2"></span>

            <div class="content-box">

                <h1>404</h1>

                <p><strong>Oops!</strong> The page you are looking for does not exist. It might have been <br> moved or deleted.</p>

                <a href="https://www.businessalphabets.com" class="theme-btn btn-style-one"><span>Go to Home</span></a>

            </div>

        </div>

    </section>

    <!-- Error Page Section -->



    <!-- Fixed icon Left -->

    <div class="fixed-icon">

        <ul>

           <li><a href="#"><i class="fa fa-facebook"></i></a></li> 

           <li><a href="#"><i class="fa fa-twitter"></i></a></li> 

           <li><a href="#"><i class="fa fa-google-plus"></i></a></li> 

           <li><a href="#"><i class="fa fa-pinterest"></i></a></li> 

           <li><a href="#"><i class="fa fa-dribbble"></i></a></li> 

        </ul>

    </div>

    <!-- End Fixed icon Left -->



</div>

<!--End pagewrapper-->





             <?php 

            //footer

            include_once("include/footer.php");



            ?>

