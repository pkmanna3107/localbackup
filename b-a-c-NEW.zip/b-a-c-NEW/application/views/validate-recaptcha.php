<?php
if (empty($_POST['recaptcha'])) {
	exit('Please set recaptcha variable');
}else{
// validate recaptcha
$response = $_POST['recaptcha'];
$post = http_build_query(
 	array (
 		'response' => $response,
 		'secret' => '6Lfxl50UAAAAADmrG889Sgkur_n9m1GFhYNJ9nkN',
 		'remoteip' => $_SERVER['REMOTE_ADDR']
 	)
);
$opts = array('http' => 
	array (
		'method' => 'POST',
		'header' => 'application/x-www-form-urlencoded',
		'content' => $post
	)
);
$context = stream_context_create($opts);
$serverResponse = @file_get_contents('https://www.google.com/recaptcha/api/siteverify', false, $context);
if (!$serverResponse) {
	exit('Failed to validate Recaptcha');
}
$result = json_decode($serverResponse);
if (!$result -> success) {
	exit('Invalid Recaptcha');
}
exit('Recaptcha Validated');



        if(isset($_POST['first_name'])){
        echo  $first_name=$_POST['first_name'];
        }
        if(isset($_POST['last_name'])){
        echo  $last_name=$_POST['last_name'];
        }
        if(isset($_POST['email'])){
        echo  $email=$_POST['email'];
        }
        if(isset($_POST['phone'])){
        echo  $phone=$_POST['phone'];
        }
        if(isset($_POST['message'])){
        echo  $message=$_POST['message'];
        }



}


?>








