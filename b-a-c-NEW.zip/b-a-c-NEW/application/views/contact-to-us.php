
<?php 

//header

//include_once("include/header.php");

?>

<div class="page-wrapper social-icon-left">  
    <!--Page Title-->
    <section class="page-title style-two bitheigt" style="background-image:url(assets/images/background/2.jpg);">
        <div class="auto-container">
            <h1><span class="light">Contact</span> Us</h1>
            <span class="drop-icon"></span>
            <span class="drop-icon-small"></span>
        </div>
    </section>
    <!--End Page Title-->
<section class="quality-section">
    <div class="container">
        <div class="row">
            <div class="col-md-7">
      <!---gouranga-big_box-start-13.3.19--->
              <div class="big_box">
               
                   
                      <div class="col-md-12 frist_1">
                        <div class="touch_lt">
                          <h4>Get In Touch</h4>
                          <p>Looking for an innovative IT solution, then we are happy to help you. Drop us a line or fill this form to discuss your project. Our sales representative will revert as soon as possible. BAC is one of the best web development company in Kolkata.</p>
                          <br>
                          <div class="row back-chang">
                            <?php


                            // include("template-part/contact.php")

                            $this->load->view('template-part/contact');  

                             ?>
                          </div>
                          </div>
                      </div>
                
              </div>
            </div>
            <div class="col-md-5">
                <div class="contct-us-add">
                    <h3>Sales</h3>
                        <p>Say Hello.</p>
                    <div class="email_contact_phone">
                        <ul>
                            <li><span><i class="fa fa-envelope" aria-hidden="true"></i></span> &nbsp; &nbsp;hello@bacpost.com</li>
                            <li><span><i class="fa fa-phone-square" aria-hidden="true"></i></span> &nbsp; &nbsp;IND +91 9681 998 877</li>
                            <li><span><i class="fa fa-phone-square" aria-hidden="true"></i></span> &nbsp; &nbsp;USA +1 866 740 4855</li>
                            <li><span><i class="fa fa-phone-square" aria-hidden="true"></i></span> &nbsp; &nbsp;AUS +61 180 077 1924</li>
                            
                            <!-- <li>Here are the frequently asked questions</li> -->
                        </ul>
                    </div>
                </div>
                <div class="contct-us-add">
                    <h3>Support</h3>
                        <p>We’d love to help you.</p>
                    <div class="email_contact_phone">
                        <ul>
                            <li><span><i class="fa fa-envelope" aria-hidden="true"></i></span> &nbsp; &nbsp;support@bacpost.com</li>
                            <li><span><i class="fa fa-phone-square" aria-hidden="true"></i></span> &nbsp; &nbsp;IND +91 9681 998 877</li>
                            <li><span><i class="fa fa-phone-square" aria-hidden="true"></i></span> &nbsp; &nbsp;USA +1-866-740-4855</li>
                            <li>Here are the frequently asked questions</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>
<!--end contact form-->
<!--  start office address-->
    <section class="quality-section">
        <div  class="container">
            <div class="row">
                <div class="office_address">
                    <h1>OFFICES</h1>
                </div>
            </div>
            <div class="row">
                <div class="col-md-4">
                    <div class="country_cdeatils">
                        <ul>
                            <li>
                                <h2>Usa</h2>
                                <h3>Austin</h3>
                            </li>
                            <li>
                                <ul class="address_deatails2">
                                    <li>Business Alphabets Corporation</li>
                                    <li>3190 Q, IH 39, </li>
                                    <li>  Suite 100 Austin, </li>
                                    <li>Texas 78704,</li>
                                    <li>Call : +1-866-740-4855 </li>
                                </ul>
                            </li>
                            <em></em>
                            
                        </ul>
                    </div>
                </div>

<!--2nd part coutry deatils-->
                <div class="col-md-4">
                    <div class="country_cdeatils">
                        <ul>
                            <li>
                                <h2>INDIA</h2>
                                <h3>Kolkata</h3>
                            </li>
                            <li>
                                <ul class="address_deatails2">
                                    <li>Business Alphabets Corporation </li>
                                    <li> Victoria Park, # 9TH Floor, </li>
                                    <li>Plot No. GN 37/2,Sector-V, Salt Lake, </li>
                                    <li>Kolkata 700091, INDIA,</li>
                                    <li>Call : +91-9681-998877 </li>
                                   
                                </ul>
                            </li>
                            <em></em>
                            <li>
                                <h3>New Town- Rajarhat</h3>
                            </li>
                            <li>
                                <ul class="address_deatails2">
                                    
                                    <li>304, 3rd Floor, PsIXL Building </li>
                                    <li>Chinarpark, Rajarhat, </li>
                                    <li>Kolkata 700136, INDIA</li>
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
<!--2nd part coutry deatils-->
                <div class="col-md-4">
                    <div class="country_cdeatils">
                        <ul>
                            <li>
                                <h2>AUSTRALIA</h2>
                                <h3>Sydney</h3>
                            </li>
                            <li>
                                <ul class="address_deatails2">
                                    <li>Chifley Tower </li>
                                    <li> Level 29, Chifley Tower, </li>
                                    <li>2 Chifley Square, </li>
                                    <li>Sydney, NSW 2000 </li>
                                    <li>Call : +61-180-077-1924 </li>
                                </ul>
                            </li>
                            <li>
                          <h2>CANADA</h2>
                                <h3>Quebec City</h3>
                            </li>
                            <li>
                                <ul class="address_deatails2">
                                    
                                    <li> 1020 Bouvier Street, Suite 400, </li>
                                    <li>Quebec City, Quebec, </li>
                                    <li>G2K 0K9, CANADA</li>
                                    <li>Call: +1-866-662-0749</li>
                                  
                                </ul>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </section>
    
            <?php 

                //footer
//
  //              include_once("include/footer.php")
            ?>

