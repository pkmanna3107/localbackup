<?php 
//header
//include_once("include/header.php");
?>
<section class="about-section-two2">
   <div class="box2">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="text-center">
                <h2>BACPOST TERMS OF USE</h2>
              </div>
            </div>
            <div class="col-md-12">
              <div class="text-left">
                <p>This agreement sets out the legally binding terms of your use of the services provided by Business Alphabets Corporation (hereinafter referred to as "BACpost" or "Services") to you (hereinafter referred to as "End User," "You" or "Your"), and may be modified by BACpost from time to time, such modifications to be effective upon posting of the modified agreement. </p>
                <p>By accessing, using and/or registering for the services provided by BACpost, you agree that you have read and understand this End User Terms of Service and all of its contents (hereinafter referred to as this "Agreement"), intend this Agreement to be the legal equivalent of a signed, written contract and equally binding, and that you will be subject to all of the terms and conditions set forth herein. You agree to review the Agreement periodically to be aware of any such modifications, additions, deletions or other changes, and your continued access, registration and/or use of the Services shall be deemed your acceptance of the modified agreement.</p>
                <h3>OVERALL AND GENERAL TERMS</h3>
                <p>BACpost (also, "we" or "us") provides services, related offerings, software, websites and sub-websites all offering features and functionalities ("Cloud based Product" or "Cloud based Products"). These Products are each subject to these Terms of Use. BACpost may revise these Terms as well as any operating policies that we may post on this website or sub-sites. Such rules and guidelines are specifically incorporated into these Terms of Use by reference (collectively, "The Agreement"). BACpost may revise this Agreement for any commercially reasonable purpose. </p>
                <p>Future performance by BACpost under this Agreement constitutes legal consideration for such revisions. These revisions take effect when BACpost notifies you of them, either through e-mail or website announcement, and you should stop using BACpost's Products and cancel your account if you do not agree to these revisions. When you check the box and click the "Agree" button, when you log into your BACpost account, or when you access any BACpost product, including this website and sub-sites, you accept this Agreement for yourself and any organization that you represent (collectively, "You"). Do not attempt to amend this Agreement through further communication (including but not limited to invoices, purchase orders, etc.), as these attempts will specifically be null and void.</p>
                <h3>DESCRIPTION OF SERVICES for EMAIL</h3>
                <p>BACpost: The monthly renewing service provided by BACpost Email enables the End User to send electronic messages containing rich media content, including, but not limited to, images, videos, music, sound clips and other audiovisual and/or interactive features. Any new feature, enhancement, addition, change or upgrade to the current Service shall be subject to the terms and conditions set forth in the Agreement herein. BACpost Events: The service provided by BACpost Events enables the End User to create an Event page and related social media and email marketing promotional materials for the purposes of managing, tracking and collecting Event registration fees. You acknowledge that BACpost reserves the right to modify or discontinue any of its services in whole or in part with or without notice.</p>
                <h3>DESCRIPTION OF SERVICES for SMS Service is subject to TRAI Regulation</h3>
                <p>As you may already be aware, the Telecom Regulatory Authority of India (TRAI) and the Department of Telecommunications(DOT) have released a new regulation which states that all promotional messages submitted will be charged an extra termination charge @ 5ps + taxes effective 1800 hrs IST 25th October 2011.</p>
                <p>To comply with the new regulation, we are left with not many options but to pass on the same to our valuable customers. Therefore we are introducing a new CREDIT SYSTEM in our panel named Termination Credits, the cost of which would be 5 ps+ taxes per credit. The existing credits can be used only if you have adequate Termination credits in your account. You will also have the privilege to transfer the existing credits to Termination credits by matching the applicable rates by deducting credits equivalent to 5 ps + tax from your existing credit.If this sounds a bit confusing for you, please get in touch with your account managers who will be more than happy to guide you through the entire process. As you might be aware by now, Telecom Regulatory Authority of India (TRAI) has issued a new regulation which after multiple delays and updates, is due to go into effect on September 27, 2011. These regulations are designed to put an end to unsolicited commercial communications (UCC) to subscribers of National Do Not Call (NDNC) register, now enhanced and renamed as National Customer Preference Register (NCPR). Although the regulation is aimed to significantly curb UCC, it brings a positive change to the industry by allowing full access to the NCPR/DND database to registered telemarketers and easy registration/deregistration process etc. Having said that, I would like to bring your attention to a few things which will change the way we have been doing business until now. Bulk Messaging has been divided into two categories, namely Transactional and Promotional.</p>
                <h3>Definition of Transactional Messages</h3>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Information pertaining to the account of its customer sent to the customer by a licensee or Bank or financial institution or insurance company or credit card company or depositories registered with Securities and Exchange Board of India or Direct to Home Operators.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Information given by Airlines or Indian Railways or its authorized agencies to its passengers regarding travel schedules, ticket booking and reservation.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Information from a registered educational institution to its students or their parents or guardians.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Any message transmitted by or on the directions of the Central Government or State Government, TRAI or any agency authorized by TRAI, or on the directions of bodies established under the Constitution. Only messages with the above nature will qualify as transactional message.
                </p>
                <h3>Definition of Promotional Messages</h3>
                <p>Messages which do not qualify as transactional messages are Promotional, until TRAI appends the existing Transactional List with further categories.</p>
                <h3>DND Scrubbing</h3>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Promotional Messages will be DND Scrubbed i.e. messages will not terminate on DND numbers except for NCPR (based on customers preference)
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Transactional Messages will NOT be DND Scrubbed i.e. messages will be terminated on DND numbers.
                </p>
                <h3>Timing</h3>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Promotional Messages will be delivered from 0900 hrs to 2100 hrs only.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Transactional Messages will be delivered 24 x 7.
                </p>
                <h3>Sender ID</h3>
                <p><b>Promotional Messages will have Unique sender IDs based on the categories as listed in NCPR. Categories are as follows:</b></p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Banking/Insurance/Financial products/credit cards</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Real Estate</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Education</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Health</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Consumer goods and automobiles</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Communication/Broadcasting/Entertainment/IT</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Tourism and Leisure</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>Banking/Insurance/Financial products/credit cards</b>
                </p>
                <p>
                  <span><i class="fa fa-play" aria-hidden="true"></i></span>
                  <b>None of the above categories</b>
                </p>
                <p>Promotional Sender IDs will be in the format of XY-1ZZZZZ where XY stands for Operator Code with Area Code, eg. TD, BL, LM etc; 1 stands for the category as listed in NCPR; and ZZZZZ stands for the 5 digit code provided to the telemarketer by the Access Provider. No other types of sender IDs will be used including dynamic sender ID, Numeric Sender ID etc. Our customers will be privileged to use the multiple sender IDs that has been allotted to Us by different operators. Transactional Sender IDs will be in the format of XY-ABCDE where XY Stands for the operator code with area code and ABCDE stands for a 5 digit Alpha-Numerical code as desired by the customer.</p>
                <h3>Penalization</h3>
                <p>Violation of the above regulation will attract incrementing penalties starting from Rs. 25,000 to Rs. 2,50,000 and blacklisting for a period of 2 years thereafter. The above regulations are welcomed by Us and it gives us immense pleasure to let you all know that we are all geared up to go ahead with the regulations as all the required amendments have been made at our end and we have successfully tested the same. Customers will be given the privilege of selecting the category at their end and initially a verification will be made at our end to ensure that the same falls in the right category. For the time being, considering the huge risk that revolves around terminating messages to DND/NCPR, we have opted to completely avoid sending messages to DND regardless of the NCPR. Transactional messages, however, will be terminated on DND numbers. Real time DND scrubbing will be done at our end and real care will be taken regarding the time window, which means peace of mind for our customers. Our feature rich - future ready panel will continue providing the best service in the industry, with complete adherence to the present regulation and/or any future regulations to come. Please get in touch with your account manager or our Support team for further clarifications that you might need regarding this. Thanking you once again for your esteemed patronage with Us.</p>
                <h3>COMMUNICATION WITH USERS</h3>
                <p>BACpost is permitted to inform you of changes to this website and/or sub-sites, its Products, this Agreement or its Fee Schedule. It is likewise permitted to inform you of breaches of this Agreement and any actions taken regarding your privilege to access the Products. However, it shall not be obligated to send notice if the Agreement does not require it. </p>
                <p>BACpost shall also have the authority to monitor and/or record its phone conversations and text chats with you for quality control, for training purposes, and for its own legal protection. You warrant that anyone who has authorization to use your account likewise consents to such monitoring and/or recording. You agree that none of this obligates BACpost to record any communication from you, and you acknowledge that some communications will not be recorded or be available to be retrieved. BACpost may contact you to discuss its Products; you may still opt out of telephone contact by emailing a request to info@bacpost.com. However, even after opting out, you agree that BACpost may still contact you by phone at your specific request. </p>
                <p>As part of this agreement, you acknowledge that we may occasionally provide best practice tips and frequently asked questions on complying with any applicable laws, including any sample offer terms or our customer privacy policy. With this agreement, you agree that this information is given to you as a convenience, and that this information does not constitute legal advice. As such, no attorney-client relationship will be built or formed, and we do not guarantee or warrant that compliance with this info will be enough to comply with third party rights or applicable law.</p>
                <h3>INTELLECTUAL PROPERTY</h3>
                <p>BACpost solely and exclusively owns all intellectual property and other rights, title and interest in and to the BACpost services and all content and materials provided to you through the Services, including, but not limited to, text, software, music, sound, video, photographs, graphics and animation (hereinafter referred to as the "Content"). All such content provided by BACpost and its licensors through the Services is the sole and exclusive property of BACpost, and any unauthorized use of the content may violate United States federal copyright laws, patent laws, moral rights laws, trade secret laws, confidential information laws, trademark laws, unfair competition laws or other similar rights.</p>
                <h3>END USER OBLIGATIONS</h3>
                <p>By accessing, using and/or registering for the Services, you agree to: a) provide true, accurate, complete and current user information as requested by BACpost at any time; b) promptly and regularly update your user information to maintain its accuracy and completeness; c) provide for your own access to the Internet and pay any fees or costs relative to such access that is required to access the Services; d) provide all necessary equipment and/or materials necessary for you to make such connection to the Internet in order to access, use and/or register for the Services. By providing any user information that is untrue, inaccurate, incomplete and/or not current, BACpost reserves the right to suspend or terminate your account and refuse any and all current or future use of the Services, in whole or in part, by you. On occasion, we may ask you to sign an affidavit verifying the fact that your list is truly permission based. When requested, you agree to provide current, complete and truthful information about yourself and/or your organization. You agree to update any such information when it changes.</p>
                <h3>END USER PRIVACY</h3>
                <p>BACpostwill not monitor, edit, review or disclose the contents of any Messages composed and/or sent by an End User to a third-party recipient without End User's prior permission, unless: a) as required by law; b) in compliance with legal authorities or during any legal proceeding; c) to enforce this Agreement; d) to respond to any good faith belief or claim that such Message, or any of its contents, violates the rights or interests of any third party or violates this Agreement; and/or e) to protect the rights and/or property f) end of the agreement. </p>
                <p>As an End User composing and/or sending such Messages, you acknowledge and agree that technical processing of the Messages is required in order to send and receive such Message, to conform to the technical requirements of connecting networks, to conform to the limitations of the Services and their equipment, to conform to other similar technical requirements, or as otherwise noted in the BACpost Privacy Policy.</p>
                <h3>MONITORING</h3>
                <p>Despite not having any obligation to do so, we reserve the right to monitor any content that you've provided by using our site, services, community or marketplace. We reserve the right to block or delete any campaigns or messages, delete content including registration for events, promotions, deals, or social campaigns, if we feel it violates our Terms of Use or applicable laws. In no case will our monitoring or related actions make BACpost liable or responsible for compliance with applicable obligations or laws, for which you alone are solely liable or responsible.</p>
                <h3>FAIR USE</h3>
                <p>Whenever BACpost uses the word Unlimited with regard to image storage on our site, the fair usage of that is not to exceed 10 gigabyte of storage. Unlimited in this context of Image Storage shall not exceed 10 gigabyte of storage.</p>
                <h3>The use of this website is subject to the following terms of use:</h3>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  The content of the pages of this website is for your general information and use only. It is subject to change without notice.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Your use of any information or materials on this website is entirely at your own risk, for which we shall not be liable. It shall be your own responsibility to ensure that any products, services or information available through this website meet your specific requirements.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  This website contains material which is owned by or licensed to us. This material includes, but is not limited to, the design, layout, look, appearance and graphics. Reproduction is prohibited other than in accordance with the copyright notice, which forms part of these terms and conditions.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Unauthorised use of this website may give rise to a claim for damages and/or be a criminal offence.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  From time to time this website may also include links to other websites. These links are provided for your convenience to provide further information. They do not signify that we endorse the website(s). We have no responsibility for the content of the linked website(s).
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  You may not create a link to this website from another website or document without BACPost A project by Business Alphabets Corporation. prior written consent.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Your use of this website and any dispute arising out of such use of the website is subject to the laws of India or other regulatory authority.
                </p>
                <p>
                  <span><i class="fa fa-long-arrow-right" aria-hidden="true"></i></span>
                  Every effort is made to keep the website up and running smoothly. However, BAC Post a project by Business Alphabets Corporation. takes no responsibility for, and will not be liable for, the website being temporarily unavailable due to technical issues beyond our control.
                </p>
              </div>
            </div>
          </div>
        </div>
   </div>
</section>

<?php 
//footer
//include_once("include/footer.php");
?>