<?php 

//header

//include_once("include/header.php");

?>
    <!--Main Banner-->
    <section class="main-banner" style="background-image:url(assets/images/background/image-2.jpg);">
      <div class="auto-container">
          <div class="row clearfix">
              <!--Text Column-->
                <div class="text-column col-md-6 col-sm-12 col-xs-12">
                  <div class="inner">
                      <h2>Get all-in-one SEO services with us</h2>
                        <div class="text">We provide all kinds of search engine optimization which helps to improve website visibility. The No 1 SEO Services in Kolkata India</div>
                    </div>
                </div>
                <!--Image Column-->
                <div class="image-column col-md-6 col-sm-12 col-xs-12">
                  <div class="inner">
                      <figure class="content-image"><img src="<?php echo base_url('assets/images/resource/banner-image.jpg');?>" alt="pic" /></figure>
                    </div>
                </div>
            </div>
        </div>
    </section>
    <!-- Work Section -->
    <!--  Services We Provide Most -->
    <!--  Services We Provide Most -->
  <div class="page-wrapper bg-lines social-icon-left">
      <section class="about-section">
              <div class="sec-title text-center mt-top">
                  <h2>Our demanding SEO services </h2>
                </div>
                  <div class="auto-container ">
                      <!-- Feature Block -->
                        <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                            <div class="box">
                                <div class="btn-6">
                                    <span>
                                       <div class="lt_box">
                                           <div class="icon-box">
                                                <i class="flaticon-target-2 center1">
                                                  <img src="<?php echo base_url('assets/images/icons/service_07.png');?>" alt="pic" />
                                                </i>
                                            </div>
                                       </div> 
                                       <div class="rt_box">
                                           <h3><a href="">Keyword Reserch</a></h3>
                                           <p>We start the SEO with searching and targeting the right word. We also research the keywords that are targeted by your competitors in order to give you the best ranking in SERPs. </p>
                                       </div> 
                                       <div class="clearfix"></div> 
                                    </span>
                                </div>
                            </div>
                        </div>
                        <!-- Feature Block -->
                        <!-- Feature Block -->
                        <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                          <div class="box">
                              <div class="btn-6">
                                  <span>
                                     <div class="lt_box">
                                         <div class="icon-box">
                                              <i class="flaticon-target-2 center1">
                                                  <img src="<?php echo base_url('assets/images/icons/service_08.png');?>" alt="pic" />
                                              </i>
                                          </div>
                                     </div> 
                                     <div class="rt_box">
                                         <h3><a href="">On Page SEO</a></h3>
                                         <p>We cater all the elements that are necessary for your on-page. We optimize elements including the content, the Alter tag, the headers and the Meta tag in order to give the accurate on-page optimization.</p>
                                     </div> 
                                     <div class="clearfix"></div> 
                                  </span>
                              </div>
                          </div>
                        </div>
                        <!-- Feature Block -->
                        <!-- Feature Block -->
                        <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                          <div class="box">
                              <div class="btn-6">
                                  <span>
                                     <div class="lt_box">
                                         <div class="icon-box">
                                              <i class="flaticon-target-2 center1">
                                                  <img src="<?php echo base_url('assets/images/icons/service_09.png');?>" alt="pic" />
                                              </i>
                                          </div>
                                     </div> 
                                     <div class="rt_box">
                                         <h3><a href="">Off Page SEO</a></h3>
                                         <p>Along with on-page SEO, we also cover all the needs that are required for the off page optimization. Right from the back-end editing to Meta description, we provide all the off page services. </p>
                                     </div> 
                                     <div class="clearfix"></div> 
                                  </span>
                              </div>
                          </div>
                        </div>
                        <!-- Feature Block -->
                      <!-- -----------Secound part -->
                      <div class="row body_provide_mean2">
                          <div class="">
                              <!-- Feature Block -->
                              <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                                  <div class="box">
                                      <div class="btn-6">
                                          <span>
                                             <div class="lt_box">
                                                 <div class="icon-box">
                                                      <i class="flaticon-target-2">
                                                          <img src="<?php echo base_url('assets/images/icons/service_10.png');?>" alt="pic" />
                                                      </i>
                                                  </div>
                                             </div> 
                                             <div class="rt_box">
                                                 <h3><a href="">Link Building</a></h3>
                                                 <p>We build links on high domain authority sites which create credibility for your business. Through our creative writing, we post it on good DA sites in order to enhance the visibility of your website.</p>
                                             </div> 
                                             <div class="clearfix"></div> 
                                          </span>
                                      </div>
                                  </div>
                              </div>
                              <!-- Feature Block -->
                              <!-- Feature Block -->
                              <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                                  <div class="box">
                                      <div class="btn-6">
                                          <span>
                                             <div class="lt_box">
                                                 <div class="icon-box">
                                                      <i class="flaticon-target-2">
                                                          <img src="<?php echo base_url('assets/images/icons/service_11.png');?>" alt="pic" />
                                                      </i>
                                                  </div>
                                             </div> 
                                             <div class="rt_box">
                                                 <h3><a href="">Content Writing</a></h3>
                                                 <p>Along with prominent SEO services, we provide effective content writing which takes your business to a new horizon. Our content is enough engaging to generate the leads. </p>
                                             </div> 
                                             <div class="clearfix"></div> 
                                          </span>
                                      </div>
                                  </div>
                              </div>
                              <!-- Feature Block -->
                              <!-- Feature Block -->
                              <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                                  <div class="box">
                                      <div class="btn-6">
                                          <span>
                                             <div class="lt_box">
                                                 <div class="icon-box">
                                                      <i class="flaticon-target-2">
                                                          <img src="<?php echo base_url('assets/images/icons/service_12.png');?>" alt="pic" />
                                                      </i>
                                                  </div>
                                             </div> 
                                             <div class="rt_box">
                                                 <h3><a href="">Social Medial Optimization</a></h3>
                                                 <p>We promote your business brand on different social media channels in order to get the maximum number of reach. We publish different posts on Facebook, Instagram, Twitter etc.</p>
                                             </div> 
                                             <div class="clearfix"></div> 
                                          </span>
                                      </div>
                                  </div>
                              </div>
                              <!-- Feature Block -->
                              <!-- Feature Block -->
                              <!-- Feature Block -->
                          </div>
                      </div>  
                      <div class="row body_provide_mean">
                          <div class="">
                              <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                                  <div class="box">
                                      <div class="btn-6">
                                          <span>
                                             <div class="lt_box">
                                                 <div class="icon-box">
                                                      <i class="flaticon-target-2">
                                                          <img src="<?php echo base_url('assets/images/icons/service_13.png');?>" alt="pic" />
                                                      </i>
                                                  </div>
                                             </div> 
                                             <div class="rt_box">
                                                 <h3><a href="">Ecommerce SEO</a></h3>
                                                 <p>It is necessary to enhance the visibility of an ecommerce site. In order to increase the reach, we target paid search for your ecommerce SEO. </p>
                                             </div> 
                                             <div class="clearfix"></div> 
                                          </span>
                                      </div>
                                  </div>
                              </div>
                              <!-- Feature Block -->
                              <!-- Feature Block -->
                              <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                                  <div class="box">
                                      <div class="btn-6">
                                          <span>
                                             <div class="lt_box">
                                                 <div class="icon-box">
                                                      <i class="flaticon-target-2">
                                                          <img src="<?php echo base_url('assets/images/icons/service_14.png');?>" alt="pic" />
                                                      </i>
                                                  </div>
                                             </div> 
                                             <div class="rt_box">
                                                 <h3><a href="">App Store SEO</a></h3>
                                                 <p>In case you have an app, then we also provide you an app store SEO service. Our services include accurate optimization of your applications in different app stores like Google Play, Apple Store etc. </p>
                                             </div> 
                                             <div class="clearfix"></div> 
                                          </span>
                                      </div>
                                  </div>
                              </div>
                              <!-- Feature Block -->
                              <!-- Feature Block -->
                              <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                                  <div class="box">
                                      <div class="btn-6">
                                          <span>
                                             <div class="lt_box">
                                                 <div class="icon-box">
                                                      <i class="flaticon-target-2">
                                                          <img src="<?php echo base_url('assets/images/icons/service_14.png');?>" alt="pic" />
                                                      </i>
                                                  </div>
                                             </div> 
                                             <div class="rt_box">
                                                 <h3><a href="">Youtube Optimization</a></h3>
                                                 <p>We also optimize your videos on YouTube in order to increase the views. Besides, we help you to manage your positive images by managing the comment sections for your YouTube channels. </p>
                                             </div> 
                                             <div class="clearfix"></div> 
                                          </span>
                                      </div>
                                  </div>
                              </div>
                              <!-- Feature Block -->
                          </div>
                      </div>
                      <!-- End secound part -->
                  </div>
    <!--Fluid Section One-->
    <section class="fluid-section-one top_50 bottom_50">
        <div class="outer-container clearfix">
            <div class="image-column wow fadeInLeft" style="background-image:url(assets/images/resource/image-1.png);">
                <figure class="image-box">
                  <img src="<?php echo base_url('assets/images/resource/image-1.png');?>" alt="pic"/></figure>
            </div> 
            <div class="content-column">
                <div class="inner-column">
                    <div class="sec-title">
                        <span class="title">What we do ?</span>
                        <h2>You may <br>ask what SEO is <br>and why do you need it?</h2>
                    </div>
                    <div class="content">
                        <p>SEO services in Kolkata are a great way to get highly targeted and relevant audience to your online business at an ROI which is much less than your traditional marketing activities. We offer full spectrum of SEO services to help organizations work better and get maximum number of customers to their website in order to get good business revenue. Our SEO expert provide the best SEO services in Kolkata and use best techniques for organic SEO including the keyword analysis, link building, on page optimization, back-link and other relevant techniques.</p>
                        <ul class="services-list">
                            <li>
                                <div class="icon-box"><span class="flaticon-global">
                                  <img src="<?php echo base_url('assets/images/icons/sct_1.png');?>" alt="pic"/></span></div>
                                <h4><a href="">Qualified SEO experts:</a></h4>
                                <p>Our SEO experts are constantly updated with the latest Google Algorithm in order to provide you the best SEO service.</p>
                            </li>
                            <li>
                                <div class="icon-box"><span class="flaticon-mail-2">
                                  <img src="<?php echo base_url('assets/images/icons/sct_2.png');?>" alt="pic"/></span></div>
                                <h4><a href="">Long term effect:</a></h4>
                                <p>SEO is not a cup of tea, we use the most effective and result oriented techniques which will help your site to rank on top for the long term in SERPs.</p>
                            </li>
                        </ul>
                    </div>
                </div>
            </div> 
        </div>
    </section>
    <!-- End Fluid Section -->
    <!-- Work Section -->
    <section class="work-section services-section">
        <div class="auto-container">
            <div class="sec-title text-center">
                <span class="title">Our Work</span>
                <h2>What is really seo & how <br> can I use it?</h2>
            </div>
            <div class="row">
                <!-- First Section -->
                <div class="col-md-3 text-center">

                    <div class="tw-case-working-box">

                        <div class="working-icon-wrapper">

                            <div class="working-icon">

                                <img src="<?php echo base_url('assets/images/process1.png');?>" alt="pic"/>

                                <span class="case-process-number">1</span>

                            </div>

                        </div>

                        <h3>01 Market Research</h3>

                    </div>
                </div>
                <!--End First Section -->
                <!-- second Section -->
                <div class="col-md-3 text-center">
                    <div class="tw-case-working-box">
                        <div class="working-icon-wrapper">
                            <div class="working-icon">
                                <img src="<?php echo base_url('assets/images/process2.png');?>" alt="pic"/>
                                <span class="case-process-number">2</span>
                            </div>
                        </div>
                        <h3>02. Find Ideas</h3>
                    </div>
                </div>
                <!--End second Section -->
                <!-- Third Section -->
                <div class="col-md-3 text-center">
                    <div class="tw-case-working-box">
                        <div class="working-icon-wrapper">
                            <div class="working-icon">
                                <img src="<?php echo base_url('assets/images/process3.png');?>" alt="pic"/>
                                <span class="case-process-number">3</span>
                            </div>
                        </div>
                        <h3>03. Start Optimize</h3>
                    </div>
                </div>
                <!--End Third Section -->
                <!-- Fourth Section -->
                <div class="col-md-3 text-center">
                    <div class="tw-case-working-box">
                        <div class="working-icon-wrapper">
                            <div class="working-icon">
                                <img src="<?php echo base_url('assets/images/process4.png');?>" alt="pic"/>
                                <span class="case-process-number">4</span>
                            </div>
                        </div>
                        <h3>04. Reach Target</h3>
                    </div>
                </div>
                <!--End Fourth Section -->
            </div>
        </div>
    </section>
        <!-- clients logo start -->
        <?php

         //include_once("template-part/clients-logo.php"); 

          $this->load->view('template-part/clients-logo');
        ?>
            <!-- clients logo end -->
        <?php

          $this->load->view('template-part/contact-part');

        // include_once("template-part/contact-part.php"); 

         ?>
</section>
</div>

    <?php 
            //footer
           // include_once("include/footer.php");
            ?>