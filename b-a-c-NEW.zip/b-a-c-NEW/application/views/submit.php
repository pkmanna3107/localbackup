<!--   <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.13.3/sweetalert2.min.css'>
    <script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.13.3/sweetalert2.min.js'></script> -->

<?php


if(isset($_POST['submit']) ? $_POST['submit'] : '') {


 $first_name = $_POST['first_name'];

 $last_name = $_POST['last_name'];

 $email = $_POST['email'];

 $code = $_POST['code'];

 $mobile = $_POST['phone'];

 $message = $_POST['message'];



if($code == '+91'){
 
    $msg = "Hi ".$first_name." ".$last_name."\nThank you for showing your interest, We will get in touch with you sortly\nThanks\nwww.bacpost.com\nCall: 8622817015";
    
    $msg2 = "BAC - \n".$first_name." ".$last_name."\n".$email."\n".$mobile.". \n".$message."\nThanks";
    

    
    $cSession = curl_init(); 
    curl_setopt($cSession,CURLOPT_URL,'http://139.59.0.192/http-api.php?username=bisalp&password=124578&senderid=BACPST&route=1&number='.$mobile.'&message='.urlencode($msg));
    curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($cSession,CURLOPT_HEADER, false); 
    curl_exec($cSession);
    curl_close($cSession);
    
        $cSession2 = curl_init(); 
    curl_setopt($cSession2,CURLOPT_URL,'http://139.59.0.192/http-api.php?username=bisalp&password=124578&senderid=BACPST&route=1&number=8622817015,9903325447&message='.urlencode($msg2));
    curl_setopt($cSession2,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($cSession2,CURLOPT_HEADER, false); 
    curl_exec($cSession2);
    curl_close($cSession2);  
  
  
//echo '<script>alert("Success!");window.location.href = "https://b-a-c.co/";</script>'; 
?>    
<html>


</html> 
<script type="text/javascript"> 
  
document.onload =  swal({
    
   //icon: "success",
  type: "success",
  title: "Your request is under review!",
  text: "Please wait, our Team will contact you shortly.",
  showConfirmButton: true,
  confirmButtonText: "ok",
  closeOnConfirm: false
  
}). then(function(result){
  window.location = "https://businessalphabets.com/";
             });
</script>
 
   
<?php    
}else{
       $msg2 = "BAC - \n".$first_name." ".$last_name."\n".$email."\n".$mobile.". \n".$message."\nThanks"; 
        $cSession2 = curl_init(); 
    curl_setopt($cSession2,CURLOPT_URL,'http://139.59.0.192/http-api.php?username=bisalp&password=124578&senderid=BACPST&route=1&number=8622817015,9903325447&message='.urlencode($msg2));
    curl_setopt($cSession2,CURLOPT_RETURNTRANSFER,true);
    curl_setopt($cSession2,CURLOPT_HEADER, false); 
    curl_exec($cSession2);
    curl_close($cSession2);      
    
 //echo '<script>alert("Success!");window.location.href = "https://b-a-c.co/";</script>';    
?>    
<html>


</html> 

<script type="text/javascript">
  
document.onload =  swal({
    
   //icon: "success",
  type: "success",
  title: "Your request is under review!",
  text: "Please wait, our Team will contact you shortly.",
  showConfirmButton: true,
  confirmButtonText: "ok",
  closeOnConfirm: false
  
}). then(function(result){
  window.location = "https://businessalphabets.com/";
             });
</script>



<?php    
    }
}

 ?>



<?php
//  $user_ip = getenv('REMOTE_ADDR');
//  $geo = json_decode(file_get_contents("http://extreme-ip-lookup.com/json/$user_ip"));
//  $country = $geo->country;
//  $city = $geo->city;
//  $ipType = $geo->ipType;
//  $businessName = $geo->businessName;
//  $businessWebsite = $geo->businessWebsite;
//  $countryCode = $geo->countryCode;

//  echo $countryCode;
?>



















