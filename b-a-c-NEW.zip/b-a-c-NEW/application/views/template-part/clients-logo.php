        <section class="clients-section top_50 bottom_30">
                    <div class="auto-container">
                        <div class="sec-title text-center">
                            <span class="title">Our Clients</span>
                            <h2>Trusted By Thousands Of Customers Like You !</h2>
                        </div>

            <!--Sponsors Carousel-->

            <ul class="sponsors-carousel owl-carousel owl-theme">

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/1.png');?>" alt="pic"/></a></figure></li>

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/2.png');?>" alt="pic"/></a></figure></li>

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/3.png');?>" alt="pic"/></a></figure></li>

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/4.png');?>" alt="pic"/></a></figure></li>

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/1.png');?>" alt="pic"/></a></figure></li>

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/2.png');?>" alt="pic"/></a></figure></li>

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/3.png');?>" alt="pic"/></a></figure></li>

                <li class="slide-item"><figure class="image-box"><a href="#"><img src="<?php echo base_url('assets/images/clients/4.png');?>" alt="pic"/></a></figure></li>

            </ul>

        </div>

    </section>