
        <!---gouranga-big_box-start-13.3.19--->


                  <div class="col-md-12 frist_1">
                    <div class="touch_lt">
                      <h4>Get In Touch</h4>
                      <div class="row back-chang">
                         <form action="submit" method="post" id="myform" onsubmit="return submitUserForm();">
                         <!--<form action="submit" method="post" id="myform">-->
                        <div class="col-md-12">
                          <textarea name="message" placeholder="Describe Your Requirement*" required></textarea>
                        </div>
                        <div class="col-md-6">
                          <input type="text" name="first_name" placeholder="First Name *" required/>
                        </div>
                        <div class="col-md-6">
                          <input type="text" name="last_name" placeholder="Last Name *" required/>
                        </div>
                        <div class="col-md-6">
                         <input type="email" name="email" placeholder="E-mail Address *" required/>
                        </div>
                        <div class="col-md-6">
                          <div class="boxt">
                            <div class="l-block">
                              <select class="selectpicker buton1" data-width="fit" name="code">
                                 <option  data-content='<span class="flag-icon flag-icon-in"></span> +91' value="+91">
                                 </option>
                                 <option data-content='<span class="flag-icon flag-icon-us"></span> +1' value="+1">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-au"></span> +61' value="+61">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-gb"></span> +44' value="+44">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-ca"></span> +1' value="+1">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-sg"></span> +65' value="+65">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-ae"></span> +971' value="+971">
                                 </option>
                              </select>
                            </div>
                            <br>
                            <div class="r-block">
                              <input type="tel" name="phone" placeholder="Phone Number *" required/>
                            </div>
                            <div class="clearfix"></div>
                          </div>
                        </div>
                    
                        <!--<div class="files">-->
                        <!--  <input type="file"  class="filepond" name="filepond" multiple data-max-file-size="3MB" data-max-files="3" required/>-->
                        <!--</div>-->
                        <div class="lock">
                          <h5><i class="fa fa-lock" aria-hidden="true"></i>
                          Safe and Secure
                          </h5>
                        </div>
                        <div class="clearfix"></div>
                        
                        
                        <script src="https://www.google.com/recaptcha/api.js" async defer></script>

                         <script>
                        function submitUserForm() {
                            var response = grecaptcha.getResponse();
                            if(response.length == 0) {
                                document.getElementById('g-recaptcha-error3').innerHTML = '<span style="color:red;">This field is required.</span>';
                                return false;
                            }
                            return true;
                        }
                         
                        function verifyCaptcha() {
                            document.getElementById('g-recaptcha-error3').innerHTML = '';
                        }
                        </script>


                         <div class="g-recaptcha n-rec" data-sitekey="6Lfxl50UAAAAABl2Kvp0RZ8oFzdLFForB2ofe_cJ">
                            
                         </div>

                         <div id="g-recaptcha-error3"></div>
                        
                        <div class="submit_button">
                          <input type="submit" id="submit" name="submit" value="Send your inquiry" class="inquery-btn">
                        </div>
                        <div class="clearfix"></div>
                      
                     </form>  
                      </div>
                      </div>
                  </div>





    <!--End About Us -->



<!-- CONTACT modal-->

<div class="modal" tabindex="-1" role="dialog" id="exampleModalCenter">

  <div class="modal-dialog" role="document">

    <div class="modal-content">

      <div class="modal-header">

        <h2>Contact Us</h2>

            <p>Have Questions?</p>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <div class="modal-body">

    <div class="container">

        <div class="row">

            <div class="col-md-6 ">

                <div class="contct-us-frm">

                                        

<form class="needs-validation" novalidate>

  <div class="form-row">

    <div class="col-md-6 mb-6">

      <label for="validationCustom01">Your name: *</label>

      <input type="text" class="form-control" id="validationCustom01" placeholder="Your name" value="Mark" required>

    </div>

    <div class="col-md-6 mb-6">

      <label for="validationCustom02">Last name</label>

      <input type="text" class="form-control" id="validationCustom02" placeholder="

 

Your email" value="Otto" required>



    </div>

  </div>

  <div class="form-row">

    <div class="col-md-6 mb-6 fform_roww">

      <label for="validationCustom03">Phone:</label>

      <input type="text" class="form-control" id="validationCustom03" placeholder="Phone:" required>



    </div>

    <div class="col-md-6 mb-6 fform_roww">

      <label for="validationCustom04">Business name:</label>

      <input type="text" class="form-control" id="validationCustom04" placeholder="State" required>



    </div>

  </div>



  <div class="form-group">

    <div class="form-check">

      <label class="form-check-label" for="invalidCheck">

      </label>

  

    </div>

  </div>

<!--</form>-->

        <div class="tabcontact_mean">

            <ul class="nav nav-tabs contac_navtab">

              <li class="active"><a href="#tab_1" data-toggle="tab">Sales</a></li>

              <li><a href="#tab_2" data-toggle="tab">Support</a></li>

              <li><a href="#tab_3" data-toggle="tab">Partnerships</a></li>

              <li><a href="#tab_4" data-toggle="tab">HR</a></li>

               <li><a href="#tab_5" data-toggle="tab">Other</a></li>

            </ul>

<div class="tab-content">

     <!-- /.tab-pane 1-->

    <div class="tab-pane active" id="tab_1">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>           

    </div>

<!-- /.tab-pane 2 -->

<div class="tab-pane" id="tab_2">

    <div class="sub_tabcontant">

        <div class="form-group">

            <label for="inputAddress">Address</label>

            <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">

          </div>

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>



</div>

<!-- /.tab-pane 3 -->

    <div class="tab-pane" id="tab_3">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>     

    </div>

<!-- /.tab-pane -->

    

    <!-- /.tab-pane 4-->

    <div class="tab-pane" id="tab_3">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>     

    </div>

<!-- /.tab-pane -->

        <!-- /.tab-pane 5-->

    <div class="tab-pane" id="tab_3">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>     

    </div>

<!-- /.tab-pane -->

</div>

<!-- /.tab-content -->

</div>

                  

<!--    -->

</form>

                    

</div>

</div>

</div>

</div>

      </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

      </div>

    </div>

  </div>

</div>







