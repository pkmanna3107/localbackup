
        <!---gouranga-big_box-start-13.3.19--->
          <div class="big_box">
            <div class="container">
                <div class="row">
                  <div class="col-md-8 frist_1">
                    <div class="touch_lt">
                      <h4>Get In Touch</h4>
                      <div class="row back-chang">
                          
                        <?php $this->load->view('template-part/contact');?>
                     

                     
                      </div>
                      </div>
                  </div>
                  <div class="col-md-4 last_1">
                    <div class="box_color">
                      <h4>Say Hi!</h4>
                      <div class="lt1_box">
                        <div class="email_box">
                          <p><i class="fa fa-envelope-o" aria-hidden="true"></i></p>
                        </div>
                        <div class="email_text">
                          <span><i class="fa fa-envelope-o" aria-hidden="true"></i></span>
                          <a href="mailto:hello@bacpost.com">hello@bacpost.com</a>
                        </div>
                        <div class="clearfix"></div>
                      </div>
                      <div class="lt1_box">
                        <div class="email_box">
                          <p><i class="fa fa-phone" aria-hidden="true"></i></p>
                        </div>
                        <div class="email_text">
                          <span><i class="fa fa-phone" aria-hidden="true"></i></span>
                          <a href="tel:+919681998877">+91 9681-99-88-77</a>
                        </div>
                        <div class="clearfix"></div>
                      </div>
                      <div class="lt1_box">
                        <div class="email_box">
                          <p><i class="fa fa-skype" aria-hidden="true"></i></p>
                        </div>
                        <div class="email_text">
                          <span><i class="fa fa-skype" aria-hidden="true"></i></span>
                          <a href="skype:bacpost?call">bacpost</a>
                        </div>
                        <div class="clearfix"></div>
                      </div>
                    <!--   <ul class="social">
                            <li><a class="f-child" href="https://facebook.com/businessalphabets"
                              target="_blank"><i class="fa fa-facebook" aria-hidden="true"></i></a></li>
                            <li><a class="f-child1" href="https://twitter.com/BAC_Asia"
                              target="_blank"><i class="fa fa-twitter" aria-hidden="true"></i></a></li>
                            <li>
                              <a href="https://www.linkedin.com/company/businessalphabets"
                              target="_blank">
                              <i class="fa fa-linkedin" aria-hidden="true"></i></a>
                            </li>
                            <li>
                              <a href="https://in.pinterest.com/bacpostofficial/" target="_blank">
                              <i class="fa fa-pinterest"></i></a>
                            </li>
                            <li>
                              <a href="https://www.instagram.com/bacpost/"
                                target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
                            </li>
                      </ul> -->
                    </div>
                  </div>
                </div>
            </div>
          </div>
        <!--gouranga-big_box-start-13.3.19---->
        <!-- contact section start-->




    <!--End About Us -->



<!-- CONTACT modal-->

<div class="modal" tabindex="-1" role="dialog" id="exampleModalCenter">

  <div class="modal-dialog" role="document">

    <div class="modal-content">

      <div class="modal-header">

        <h2>Contact Us</h2>

            <p>Have Questions?</p>

        <button type="button" class="close" data-dismiss="modal" aria-label="Close">

          <span aria-hidden="true">&times;</span>

        </button>

      </div>

      <div class="modal-body">

    <div class="container">

        <div class="row">

            <div class="col-md-6 ">

                <div class="contct-us-frm">

                                        

<form class="needs-validation" novalidate>

  <div class="form-row">

    <div class="col-md-6 mb-6">

      <label for="validationCustom01">Your name: *</label>

      <input type="text" class="form-control" id="validationCustom01" placeholder="Your name" value="Mark" required>

    </div>

    <div class="col-md-6 mb-6">

      <label for="validationCustom02">Last name</label>

      <input type="text" class="form-control" id="validationCustom02" placeholder="

 

Your email" value="Otto" required>



    </div>

  </div>

  <div class="form-row">

    <div class="col-md-6 mb-6 fform_roww">

      <label for="validationCustom03">Phone:</label>

      <input type="text" class="form-control" id="validationCustom03" placeholder="Phone:" required>



    </div>

    <div class="col-md-6 mb-6 fform_roww">

      <label for="validationCustom04">Business name:</label>

      <input type="text" class="form-control" id="validationCustom04" placeholder="State" required>



    </div>

  </div>



  <div class="form-group">

    <div class="form-check">

      <label class="form-check-label" for="invalidCheck">

      </label>

  

    </div>

  </div>

<!--</form>-->

        <div class="tabcontact_mean">

            <ul class="nav nav-tabs contac_navtab">

              <li class="active"><a href="#tab_1" data-toggle="tab">Sales</a></li>

              <li><a href="#tab_2" data-toggle="tab">Support</a></li>

              <li><a href="#tab_3" data-toggle="tab">Partnerships</a></li>

              <li><a href="#tab_4" data-toggle="tab">HR</a></li>

               <li><a href="#tab_5" data-toggle="tab">Other</a></li>

            </ul>

<div class="tab-content">

     <!-- /.tab-pane 1-->

    <div class="tab-pane active" id="tab_1">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>           

    </div>

<!-- /.tab-pane 2 -->

<div class="tab-pane" id="tab_2">

    <div class="sub_tabcontant">

        <div class="form-group">

            <label for="inputAddress">Address</label>

            <input type="text" class="form-control" id="inputAddress" placeholder="1234 Main St">

          </div>

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>



</div>

<!-- /.tab-pane 3 -->

    <div class="tab-pane" id="tab_3">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>     

    </div>

<!-- /.tab-pane -->

    

    <!-- /.tab-pane 4-->

    <div class="tab-pane" id="tab_3">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>     

    </div>

<!-- /.tab-pane -->

        <!-- /.tab-pane 5-->

    <div class="tab-pane" id="tab_3">

        <div class="sub_tabcontant">

            <div class="form-group">

                <label for="exampleFormControlTextarea1">Example textarea</label>

                <textarea class="form-control" id="exampleFormControlTextarea1" rows="4"></textarea>

            </div>

        <button type="submit" class="btn btn-primary">Sign in</button>

      </div>     

    </div>

<!-- /.tab-pane -->

</div>

<!-- /.tab-content -->

</div>

                  

<!--    -->

</form>

                    

</div>

</div>

</div>

</div>

      </div>

      <div class="modal-footer">

        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>

      </div>

    </div>

  </div>

</div>







