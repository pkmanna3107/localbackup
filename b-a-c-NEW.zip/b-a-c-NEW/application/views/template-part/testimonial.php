
<div class="auto-container">

            <div class="row clearfix">
                <div class="title-column pull-right col-md-6 col-sm-12 col-xs-12">
              <div class="carousel-container carousel-vertical-3d">
                    <div class="sec-title notr">
                        <span class="title">

                         <div class="googlefirms">
                        <script type="text/javascript" src="https://goodfirms.co/js/widget.js"></script>

                    <!--     <div class="goodfirm-widget"data-widget-type="goodfirms-widget-t8" data-widget-pattern="customer-basic" data-height="60" data-company-id="19502"></div> -->

                    <iframe id="iframe-0.3235769766062926" frameborder="0" width="100%" height="130px" scrolling="no" src="http://goodfirms.co/widgets/get/19502/goodfirms-widget-t8/customer-basic" style="display: block;"></iframe>
                    </div></span>


                        <h3>Our work speaks for itself. Check out some of the positive reviews that helped our clients to make their business scalable and efficient. </h3>

                   
                    </div> 
                    
                    <div class="carousel-items">
                        <div class="carousel-item is-active">
                            <div class="testimonial testimonial-whole-filled testimonial-whole-shadowed text-left testimonial-details-sm testimonial-avatar-sm">
                                <div class="testimonial-quote">
                                    <blockquote>
                                        <p class="font-size-16 lh-185">
                                        Thanks to BAC - The Leading Website Designing and Development Company in India for creating a awesome corporate website. We appreciate your efforts and skills.
                                    </p>
                                    </blockquote>
                                </div>
                                <div class="testimonial-details">
                                    <figure class="avatar ">
                                        <img src="<?php echo base_url('assets/images/testi3.png');?>" alt="pic"/>
                                    </figure>
                                    <div class="testimonial-info">
                                        <h5>Niranjan Kumar</h5>
                                        <h6 class="font-weight-normal">Libra Honda</h6>
                                    </div>
                                    
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="testimonial testimonial-whole-filled testimonial-whole-shadowed text-left testimonial-details-sm testimonial-avatar-sm">
                                <div class="testimonial-quote">
                                    <blockquote>
                                        <p class="font-size-16 lh-185">
                                        Incorporating BAC’s comprehensive, cohesive technology has definitely eased our daily operations. Apart from that, the technology has also immensely reduced the CTC.</p>
                                    </blockquote>
                                </div>
                                <div class="testimonial-details">
                                    <figure class="avatar ">
                                        <img src="<?php echo base_url('assets/images/testi4.png');?>" alt="pic"/>
                                    </figure>
                                    <div class="testimonial-info">
                                        <h5>Sudipta Sarkar</h5>
                                        <h6 class="font-weight-normal">S & Associates</h6>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                        <div class="carousel-item">
                            <div class="testimonial testimonial-whole-filled testimonial-whole-shadowed text-left testimonial-details-sm testimonial-avatar-sm">
                                <div class="testimonial-quote">
                                    <blockquote>
                                        <p class="font-size-16 lh-185">
                                             It was awesome to deal with BAC. Marketing Capmaign is now easy and hassle free for us </p>
                         
                                    </blockquote>
                                </div>
                                <div class="testimonial-details">
                                    <figure class="avatar">
                                        <img src="<?php echo base_url('assets/images/testi5.png');?>" alt="pic"/>
                                    </figure>
                                    <div class="testimonial-info">
                                        <h5>Asit Kr. Mukherjee</h5>
                                        <h6 class="font-weight-normal">Pinnacle Honda - Asansol</h6>
                                    </div>
                                  
                                </div>
                            </div>
                        </div>
                    </div>
              </div>
                </div> 

                <div class="image-column col-md-6 col-sm-12 col-xs-12">

                    <div class="inner-column">

                        <figure class="image-box wow slideInLeft">

                            <img src="<?php echo base_url('assets/images/resource/images1.png');?>" alt="pic"/>

                            <a href="https://www.youtube.com/watch?v=NzCHodhpYg8" class="play-now" data-fancybox="gallery" data-caption="">

                                <i class="icon fa fa-play" aria-hidden="true"></i>

                                <span class="ripple"></span>

                            </a>

                        </figure>

                    </div>
                </div>
            </div>
        </div>
