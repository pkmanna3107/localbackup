 


     <!-- <form action="submit" method="post" id="myform" onsubmit="return submitUserFormn();"> -->


    <form role="form" id="myform" action="<?php echo base_url(); ?>contact" method="post" enctype="multipart/form-data">  

                        <div class="col-md-6">
                          <input type="text" name="first_name" placeholder="First Name *" required/>
                        </div>
                        <div class="col-md-6">
                          <input type="text" name="last_name" placeholder="Last Name *" required/>
                        </div>
                        <div class="col-md-6">
                         <input type="email" name="email" placeholder="E-mail Address *" required/>
                        </div>
                        <div class="col-md-6">
                          <div class="boxt">
                            <div class="l-block">
                              <select class="selectpicker buton1" data-width="fit" name="code">
                                 <option  data-content='<span class="flag-icon flag-icon-in"></span> +91' value="+91">
                                 </option>
                                 <option data-content='<span class="flag-icon flag-icon-us"></span> +1' value="+1">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-au"></span> +61' value="+61">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-gb"></span> +44' value="+44">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-ca"></span> +1' value="+1">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-sg"></span> +65' value="+65">
                                 </option>
                                 <option  data-content='<span class="flag-icon flag-icon-ae"></span> +971' value="+971">
                                 </option>
                              </select>
                            </div>
                            <br>
                            <div class="r-block">
                              <input type="tel" name="phone" placeholder="Phone Number *" required/>
                            </div>
                            <div class="clearfix"></div>
                          </div>
                        </div>
                        <div class="col-md-12">
                          <textarea name="message" placeholder="Message *" required></textarea>
                        </div>
                        
                        <div class="lock">
                          <h5><i class="fa fa-lock" aria-hidden="true"></i>
                          Safe and Secure
                          </h5>
                        </div>
                        <div class="clearfix"></div>
                        
<!--                         <script>
                        function submitUserFormn() {
                            var response = grecaptcha.getResponse();
                            if(response.length == 0) {
                                document.getElementById('g-recaptcha-error2').innerHTML = '<span style="color:red;">This field is required.</span>';
                                return false;
                            }
                            return true;
                        }
                         
                        function verifyCaptcha() {
                            document.getElementById('g-recaptcha-error2').innerHTML = '';
                        }
                        </script>


                        <div class="g-recaptcha n-rec" data-sitekey="6Lfxl50UAAAAABl2Kvp0RZ8oFzdLFForB2ofe_cJ">
                            
                        </div>

                        <div id="g-recaptcha-error2"></div> -->


                        <div class="submit_button">
                          <input type="submit" id="submit" name="submit" value="Send your inquiry" class="inquery-btn">
                        </div>
                        <div class="clearfix"></div>
              
    </form> 