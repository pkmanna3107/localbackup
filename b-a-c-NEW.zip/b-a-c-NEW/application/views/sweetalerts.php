
  
  <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.13.3/sweetalert2.min.css'>


<html>


</html>



  <script src='https://cdnjs.cloudflare.com/ajax/libs/limonte-sweetalert2/7.13.3/sweetalert2.min.js'></script>

<script type="text/javascript">
  
//document.onload = swal('Your request is under review!', 'Please wait, our Team will contact you shortly.', 'success');



document.onload =  swal({
    
  type: "success",
  title: "Your request is under review!",
  text: "Please wait, our Team will contact you shortly.",
  showConfirmButton: true,
  confirmButtonText: "ok",
  closeOnConfirm: true
  
}). then(function(result){
  window.location = "https://bacpost.com/";
             });
</script>

