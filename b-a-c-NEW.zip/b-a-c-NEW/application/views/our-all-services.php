<?php 

//header

//include_once("include/header.php");



?>

    

   



 <!DOCTYPE html>

<html lang="en">






<body class="multi-scroll">



<div class="page-wrapper">



    <!--Header Span-->

    <div class="header-span"></div>

    

   



    <!-- Hidden Navigation Bar -->

  

    <!-- End / Hidden Bar -->



    <!--Portfolio Section-->

    <section class="portfolio-section no-pd">

        

    	<!--Scroll Container-->

        <div id="scroll-container" class="scroller-section">

        	<!--Left-->

        	<div class="ms-left">

                <div class="ms-section" id="left1" style="background-image:url(assets/images/gallery/7-1.jpg);">

                </div>

        

                <div class="ms-section" id="left2">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Concept /Designing</span>

                            <h2><del>Attract</del> your users<br>with our elegant <del>UI/UX designs.</del></h2>

                            <a href="website-design-and-app-development-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>

                

                <div class="ms-section" id="left3" style="background-image:url(assets/images/gallery/7-3.jpg);">

                    

                </div>

                

                <div class="ms-section" id="left4">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Web Development</span>

                            <h2>We help you to build <br>your<del>digital</del>presence<br> and dominate the <del>digital</del> world</h2>

                            <a href="<?php echo base_url(); ?>website-design-and-app-development-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>

                

                <div class="ms-section" id="left5" style="background-image:url(assets/images/gallery/7-5.jpg);">


                </div>

                

                <div class="ms-section" id="left6">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Digital Marketing</span>

                            <h2> As the marketer says-<br>“Be there where your customers are”</h2>

                            <a href="<?php echo base_url(); ?>digital-marketing-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>

                <div class="ms-section" id="left7" style="background-image:url(assets/images/gallery/7-7.jpg);">

                    

                </div>

                <div class="ms-section" id="left8">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Social Media Marketing</span>

                            <h2> We set Social Media <br> <del>Marketing strategy</del> to grow your business </h2>

                            <a href="<?php echo base_url(); ?>digital-marketing-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>


                <div class="ms-section" id="left9" style="background-image:url(assets/images/gallery/7-9.jpg);">

                    

                </div>

            <div class="ms-section" id="left10">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Email Marketing</span>

                            <h2> We provide powerful <br> email panel  With<br> high delivery and <del> less bounce.</del> <br>Transform Your <br> <del>Email Marketing</del></h2>


                            <a href="https://www.bacpost.com" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>

<div class="ms-section" id="left11" style="background-image:url(assets/images/gallery/7-11.jpg);">


                </div>


            <div class="ms-section" id="left12">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Domain Name</span>

                            <h2> We provide all  <br> <del>types</del> of domain <br>With <del>theft </del>protection</h2>


                            <a href="" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>
                

            </div>

            

            <!--Right-->

        	<div class="ms-right">

                <div class="ms-section" id="right1">

                	<div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Web Services</span>

                            <h2>We create <br> <del>solutions</del> that are <br>bold and <del>forward-looking</del></h2>

                            <a href="<?php echo base_url(); ?>website-design-and-app-development-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>

        

                <div class="ms-section" id="right2" style="background-image:url(assets/images/gallery/7-2.jpg);">


                </div>

        

                <div class="ms-section" id="right3">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">App & Bots Development</span>

                            <h2><del>Get automated</del> <br>mobile apps that <br>accelerate your <br>business growth.<br>Intelligent <br> <del>bots for Exceptional </del> <br>User Experience</h2>

                            <a href="<?php echo base_url(); ?>website-design-and-app-development-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>

                

                <div class="ms-section" id="right4" style="background-image:url(assets/images/gallery/7-4.jpg);">


                </div>

                

                <div class="ms-section" id="right5">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Deployment/Hosting</span>

                            <h2>We provide scalable, <br>secure and  <del>cost-efficient </del> cloud infrastructure<del> and</del> <br>hosting servers 
                            </h2>

                            <a href="<?php echo base_url(); ?>website-design-and-app-development-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>

                </div>

                

                <div class="ms-section" id="right6" style="background-image:url(assets/images/gallery/7-6.jpg);">

                    

                </div>

                <div class="ms-section" id="right7">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">S.E.O.</span>

                            <h2>We offer an <br> affordable yet <br> the most effective<br><del>search engine</del> <br> optimization services<br>  in the globe and <del> beyond </del></h2>

                            <a href="<?php echo base_url(); ?>search-engine-optimization-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>
                </div>

                 <div class="ms-section" id="right8" style="background-image:url(assets/images/gallery/7-8.jpg);">

                    

                </div>

                <div class="ms-section" id="right9">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">Adwords</span>

                            <h2>We analyze the most<br><del>powerful</del> <br>keywords<br>that can gives<br> to maximum <br> <del>visitors.</del></h2>

                            <a href="<?php echo base_url(); ?>digital-marketing-services" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>
                </div>

                <div class="ms-section" id="right10" style="background-image:url(assets/images/gallery/7-10.jpg);">

                    

                </div>

                <div class="ms-section" id="right11">

                    <div class="content-column">

                        <div class="inner-column">                        

                            <span class="tag">SMS Marketing</span>

                            <h2>SMS services are <br> best <del>way to</del> <br>help you communicate<br> No need of<br> <del>any installation</del></h2>

                            <a href="https://www.bacpost.com/bulksms" class="theme-btn btn-style-one"><span>View More</span></a>

                        </div>

                    </div>
                </div>




                <div class="ms-section" id="right12" style="background-image:url(assets/images/gallery/7-12.jpg);">

                    
                </div>

            </div>

            

        </div>

       

    </section>

    <!--Portfolio Section-->





</div>

<!--End pagewrapper-->



<!--Scroll to top-->

<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>



<script src="<?php echo base_url('assets/js/jquery.js');?>"></script>

<script src="<?php echo base_url('assets/js/jquery-ui.js');?>"></script>

<script src="<?php //echo base_url('assets/js/bootstrap.min.js');?>"></script>

<script src="<?php echo base_url('assets/js/jquery.mCustomScrollbar.concat.min.js');?>"></script>

<script src="<?php echo base_url('assets/js/owl.js');?>"></script>

<script src="<?php echo base_url('assets/js/wow.js');?>"></script>

<script src="<?php echo base_url('assets/js/appear.js');?>"></script>

<script src="<?php echo base_url('assets/js/jquery.fancybox.js');?>"></script>

<script src="<?php echo base_url('assets/js/easing.js');?>"></script>

<script src="<?php echo base_url('assets/js/multi-scroll.js');?>"></script>

<script src="<?php echo base_url('assets/js/element-in-view.js');?>"></script>

<script src="<?php echo base_url('assets/js/script.js');?>"></script>

</body>





</html>