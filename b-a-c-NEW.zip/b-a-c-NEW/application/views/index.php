<?php //include_once("include/header.php"); ?>

    <!--Main Slider-->

<?php //include_once("include/homebanner.php"); ?>

        <!--Main Slider end-->

        <!-- About Us -->

        <section class="about-us">

            <div class="auto-container">

                <div class="row clearfix">

                    <div class="title col-md-6 col-sm-12 col-xs-12">

                        <div class="title-box">
                            <h1>Best website<br> <span> and </span> mobile app<br> development<span> company</span></h1></div>

                        </div>
                    <div class="text col-md-6 col-sm-12 col-xs-12">

                        <div class="text-box">
                            <p>Business Alphabet is a passionate and result oriented website and mobile app development agency based in Kolkata India. Right from delivery high-end website design to executing scalable digital marketing campaigns, we are here to provide solutions to all your business needs. Our well-versed strategy based on insights and statistics which is combined with our expertise ensure the success of clients that we deal with.</p>
                        </div>

                    </div>

                </div>

                <div class="down-arrow"><span class="icon angle-down"></span></div>

            </div>
        </section>

        <!-- End About Us -->

        <!-- Work Section -->

        <section class="work-section">

            <div class="auto-container">

                <div class="sec-title text-center">

                    <span class="title">Our Services</span>

                    <h2>Your best choice is here</h2>

                </div>

                <div class="work-blocks">

                    <div class="row clearfix">

                        <!-- Work Block -->

                        <div class="work-block col-md-4 col-sm-6 col-xs-12">

                            <div class="inner-box">

                                <div class="icon-box wow rollIn">
                                    <img src="<?php echo base_url('assets/images/resource/work-1.png');?>" alt="pic"/></div>

                                <h3><a href="<?php echo base_url('');?>digital-marketing-services">Digital Marketing</a></h3>
                                <p>Enhance your reach to thousands of potential customers that boost up the revenue with our well-planned and strategized marketing solutions.</p>

                            </div>

                        </div>

                        <!-- Work Block -->

                        <div class="work-block col-md-4 col-sm-6 col-xs-12">

                            <div class="inner-box">

                                <div class="icon-box wow rollIn">
                                    <img src="<?php echo base_url('assets/images/resource/work-2.png');?>" alt="pic"/></div>

                                <h3><a href="<?php echo base_url('');?>website-design-and-app-development-services">Designing</a></h3>

                                <p>We have creative website design solutions which provide a strong image of your business on different digital platforms with instant connection with your customers. </p>

                            </div>

                        </div>

                        <!-- Work Block -->

                        <div class="work-block col-md-4 col-sm-6 col-xs-12">

                            <div class="inner-box">

                                <div class="icon-box wow rollIn">
                                    <img src="<?php echo base_url('assets/images/resource/work-3.png');?>" alt="pic"/></div>

                                <h3><a href="<?php echo base_url('');?>website-design-and-app-development-services"> Web Development</a></h3>

                                <p>With our web development services you can get a high performing website which is effective, fully functional as well as scalable to boost up business revenue.</p>

                            </div>

                        </div>

                    </div>

                </div>

                <div class="work-blocks">

                    <div class="row clearfix">

                        <!-- Work Block -->

                        <div class="work-block col-md-4 col-sm-6 col-xs-12">

                            <div class="inner-box">

                                <div class="icon-box wow rollIn">
                                    <img src="<?php echo base_url('assets/images/resource/work-4.png');?>" alt="pic"/></div>

                                <h3><a href="<?php echo base_url('');?>website-design-and-app-development-services"> App Development</a></h3>

                                <p>We create user-friendly mobile app which helps your business reach to millions of users that are using the Internet through mobile devices. </p>

                            </div>

                        </div>

                        <!-- Work Block -->

                        <div class="work-block col-md-4 col-sm-6 col-xs-12">

                            <div class="inner-box">

                                <div class="icon-box wow rollIn">
                                    <img src="<?php echo base_url('assets/images/resource/work-5.png');?>" alt="pic"/></div>

                                <h3><a href="<?php echo base_url('');?>website-design-and-app-development-services">Cloud Deployment</a></h3>

                                <p>With the fast Internet connection, you can create a cloud where you can store all your files without filling your hard disk store. </p>

                            </div>

                        </div>

                        <!-- Work Block -->

                        <div class="work-block col-md-4 col-sm-6 col-xs-12">

                            <div class="inner-box">

                                <div class="icon-box wow rollIn">
                                    <img src="<?php echo base_url('assets/images/resource/work-6.png');?>" alt="pic"/></div>

                                <h3><a href="<?php echo base_url('');?>digital-marketing-services">Branding</a></h3>

                                <p>We create positive brand image of your company and market it through different digital channels in order to enhance your business presence.</p>

                            </div>

                        </div>

                    </div>

                </div>

            </div>


        </section>

        <!--End Work Section -->

        <!--PORTFOLIO-->

        <!-- About Us -->

        <section class="about-us style-two">

            <!-- testimonial -->

            <?php 

            //footer

          //  include_once("template-part/testimonial.php");

            ?>

            <?php $this->load->view('template-part/testimonial'); //echo base_url('home/testimonial');?>

                <!-- testimonial end -->
                <section class="portfolio text-center" id="portfolio">
                    <div class="container outter">
                        <div class="sec-title text-center pa_nopadd black">
                            <span class="title">PORTFOLIO</span>
                            <h3>Check out our cutting-edge website and mobile app development solutions<br> for different industrial sectors. </h3>

                            <div class="row hid">
                                <div class="col-md-3"></div>
                                <div class="col-md-6">
                                    <div class="protfolio_tabdd pad">
                                        <ul class="nav nav-tabs">
                                            <li class="active"><a href="#tab_proto-1" data-toggle="tab"> Website</a></li>
                                            <li><a href="#tab_proto-2" data-toggle="tab">Website Layout</a></li>
                                            <li><a href="#tab_proto-3" data-toggle="tab">Logo Design</a></li>
                                        </ul>
                                    </div>
                                </div>
                                <div class="col-md-3"></div>
                            </div>
                        </div>
                        <!--Portfolio Items-->
                        <div class="tab-content hid">
                            <div class="tab-pane active" id="tab_proto-1">
                                <div class="container">
                                    <div class="catbox">
                                        <div class="row">
                                            <!-- 1 No row tab start -->
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/bag1.jpg');?>" alt="pic"/>
                                                    </div>
                                                    <div class="content">
                                                        <h2>Recycling</h2>
                                                        <p><a href="<?php echo base_url('');?>our-work-and-portfolio">View Demo</a></p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/bag13.jpg');?>" alt="pic"/>
                                                    </div>
                                                    <div class="content">
                                                        <h2>Educational</h2>
                                                        <p>
                                                            <a href="<?php echo base_url('');?>our-work-and-portfolio" target="_blank">View Demo</a>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/bag14.jpg');?>" alt="pic"/>
                                                    </div>
                                                    <div class="content">
                                                        <h2>Madical</h2>
                                                        <p>
                                                            <a href="<?php echo base_url('');?>our-work-and-portfolio" target="_blank"> View Demo</a>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/bag18.jpg');?>" alt="pic"/>
                                                    </div>
                                                    <div class="content">
                                                        <h2>Bike App</h2>
                                                        <p>
                                                            <a href="<?php echo base_url('');?>our-work-and-portfolio" target="_blank">View Demo </a>
                                                        </p>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- /.tab-pane 2-->
                            <div class="tab-pane" id="tab_proto-2">
                                <div class="container">
                                    <div class="catbox catbox2_nomargin">
                                        <!-- 5 No row tab start -->
                                        <div class="col-md-3 col-sm-6 col-sx-12">
                                            <div class="box">
                                                <div class="imgBox">
                                                    <img src="<?php echo base_url('assets/images/bag19.jpg');?>" alt="pic"/>
                                                </div>
                                                <div class="content">
                                                    <h2>News Portal</h2>
                                                    <p><a href="<?php echo base_url('');?>our-work-and-portfolio" target="_blank">
                                    View Demo
                                 </a></p>
                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-6 col-sx-12">
                                            <div class="box">
                                                <div class="imgBox">
                                                    <img src="<?php echo base_url('assets/images/bag2.jpg');?>" alt="pic"/>
                                                </div>
                                                <div class="content">
                                                    <h2> Tour and Travel</h2>
                                                    <p><a href="<?php echo base_url('');?>our-work-and-portfolio" target="_blank">
                                    View Demo
                                </a></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-6 col-sx-12">
                                            <div class="box">
                                                <div class="imgBox">
                                                    <img src="<?php echo base_url('assets/images/bag20.jpg');?>" alt="pic"/>
                                                </div>
                                                <div class="content">
                                                    <h2> Clinical</h2>
                                                    <p><a href="<?php echo base_url('');?>our-work-and-portfolio" target="_blank">
                                    View Demo
                                </a></p>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-md-3 col-sm-6 col-sx-12">
                                            <div class="box">
                                                <div class="imgBox">
                                                    <img src="<?php echo base_url('assets/images/bag23.jpg');?>" alt="pic"/>
                                                </div>
                                                <div class="content">
                                                    <h2> Photography Websites</h2>
                                                    <p><a href="<?php echo base_url('');?>our-work-and-portfolio" target="_blank">
                                    View Demo
                                </a></p>
                                                </div>
                                            </div>
                                        </div>
                                        <!-- 5No row tab End -->
                                    </div>
                                </div>
                            </div>
                            <!-- /.tab-pane -->
                            <div class="tab-pane" id="tab_proto-3">
                                <div class="container">
                                    <div class="catbox catbox2_nomargin">
                                        <div class="row">
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/clients/7.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/clients/6.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/websitelogo17.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/websitelogo2.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <br/>
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/websitelogo3.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <br/>
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/websitelogo4.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <br/>
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/websitelogo5.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                            <div class="col-md-3 col-sm-6 col-sx-12">
                                                <br/>
                                                <div class="box1">
                                                    <div class="imgBox">
                                                        <img src="<?php echo base_url('assets/images/websitelogo6.png');?>" alt="pic"/>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!--Portfolio Items-->
                        <!-- owl-carousel start -->
                        <div class="fadeOut owl-carousel owl-theme hhedin">
                            <div class="item bxa">
                                <a href="https://bit.ly/2v5qXbw" target="_blank">
                                    <img src="<?php echo base_url('assets/images/bag1.jpg');?>" alt="pic"/>
                                </a>
                            </div>
                            <div class="item bxa">
                                <a href="https://bit.ly/2DgcKgC" target="_blank">
                                    <img src="<?php echo base_url('assets/images/bag13.jpg');?>" alt="pic"/>
                                </a>
                            </div>
                            <div class="item bxa">
                              <a href="https://bit.ly/2KIw8J1" target="_blank">
                                <img src="<?php echo base_url('assets/images/bag14.jpg');?>" alt="pic"/>
                              </a>
                            </div>
                            <div class="item bxa">
                                <a href="https://bit.ly/2DhGmtJ" target="_blank">
                                    <img src="<?php echo base_url('assets/images/bag18.jpg');?>" alt="pic"/>
                                </a>
                            </div>
                            <div class="item bxa">
                                <a href="https://bit.ly/2v5jskL" target="_blank">
                                    <img src="<?php echo base_url('assets/images/bag19.jpg');?>" alt="pic"/>
                                </a>
                            </div>
                            <div class="item bxa">
                                <a href="#" target="_blank">
                                    <img src="<?php echo base_url('assets/images/bag2.jpg');?>" alt="pic"/>
                                </a>
                            </div>
                            <div class="item bxa">
                                <a href="#" target="_blank">
                                    <img src="<?php echo base_url('assets/images/bag20.jpg');?>" alt="pic"/>
                                </a>
                            </div>
                            <div class="item bxa">
                                <a href="#" target="_blank">
                                    <img src="<?php echo base_url('assets/images/bag23.jpg');?>" alt="pic"/>
                                </a>
                            </div>
                        </div>
                        <!-- owl-carousel end -->
                        <div class="protofoliow_btn">
                            <a class="site-btn top_30" href="our-work-and-portfolio">View Portfolio</a>
                        </div>

                    </div>
                </section>

                <!-- clients logo start -->
                




                <section class="clients-section top_50 bottom_30">
                    <div class="auto-container">
                        <div class="sec-title text-center">
                            <span class="title">Our Clients</span>
                            <h2>Trusted By Thousands Of Customers Like You !</h2>
                        </div>
                      <!--Sponsors Carousel-->
                        <ul class="sponsors-carousel owl-carousel owl-theme bnot">
                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/1.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/13.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/3.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/4.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/12.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/6.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/7.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/8.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/9.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/10.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/11.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/2.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/14.png');?>" alt="pic"></a>
                                </figure>
                            </li>

                            <li class="slide-item">
                                <figure class="image-box1">
                                    <a href="#"><img src="<?php echo base_url('assets/images/clients/15.png');?>" alt="pic"></a>
                                </figure>
                            </li>
                        </ul>
                    </div>
                </section>
                <!-- clients logo end -->
                <?php //include_once("template-part/contact-part.php");?>

                <?php $this->load->view('template-part/contact-part'); ?>

        </section>

        <?php 

            //footer

           //include_once("include/footer.php");

            ?>