<?php 
//header
include_once("include/header.php");
?>

<section class="about-section-two2">
   <div class="box2">
        <div class="container">
          <div class="row">
            <div class="col-md-12">
              <div class="text-center">
                <h2>Refund Policy</h2>
              </div>
            </div>
            <div class="col-md-12">
              <div class="text-left text-center">
                <p>When you buy our services, your purchase is covered by our 30-day money-back guarantee. If you are, for any reason, not entirely happy with your purchase, we will cheerfully issue 50% refund on pro-data basis& account uses.
				In case for Web-designing for Software/ Application-development 95% of money on total contract value will be refundable before the front-end designing approval. After the approval of front end 75% of money will be refundable on total contract value. During the back-end development 40% money will be refundable on total contract value, after approval of back-end development No money will be refundable. Govt. Tax will be applicable on cancellation amount.
				We develop and sell software that we use ourselves every day and have thousands of satisfied customers worldwide, and our support is second to none. That is why we can afford to back our products with this special guarantee. To request a refund, simply contact us with your purchase details within thirty (30) days of your purchase. Please include your order number (sent to you via email after ordering) and optionally tell us why you’re requesting a refund – we take customer feedback very seriously and use it to constantly improve our quality of service. Refunds are not being provided for installation service and provided knowledge base hosting service or in-case you used the full limit of the service account such as Bulk SMS Credit or Bulk Email Credit. Refunds are being processed within 21 working days period after receiving your refund request.
				</p>
              </div>
            </div>
          </div>
        </div>
   </div>
</section>

<?php 
//footer
include_once("include/footer.php");
?>