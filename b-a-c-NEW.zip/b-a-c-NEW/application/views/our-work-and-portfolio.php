<?php 
//header
//include_once("include/header.php");
?>
    <section class="about-section-two">
        <section class="page-title protfolio_ptitle">
            <div class="icon-one"></div>
            <div class="icon-two"></div>
            <div class="auto-container">
                <div class="icon-three"></div>
                <div class="icon-six"></div>
                <div class="icon-five"></div>
                <div class="icon-four"></div>
                <div class="icon-fifteen"></div>
                <h2><span class="icon-fourten"></span> <span class="white-color">Port</span>folio</h2>
            </div>
        </section>
        <!--End Page Title-->
        <!-- tab------------------------------->
        <!-- Custom Tabs (Pulled to the right) -->
        <div class="nav-tabs-custom">
            <div class="container">
                <div class="row">
                    <div class="col-md-6 col-md-offset-3">
                        <div class="protfolio_tabdd tabdd-bottom">
                            <ul class="nav nav-tabs">
                                <li class="active"><a href="#tab_proto-1" data-toggle="tab">All</a></li>
                                <li><a href="#tab_proto-2" data-toggle="tab">Graphic Design</a></li>
                                <li><a href="#tab_proto-4" data-toggle="tab">Logo Design</a></li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="tab-content">
                <div class="tab-pane active" id="tab_proto-1">
                    <div class="container">
                        <div class="catbox">
                            <div class="row">
                                <!-- 1 No row tab start -->
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-18.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Recycling</h2>
                                            <p><a href="https://greensoldiers.in/" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-1.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Educational</h2>
                                            <p>
                                                <a href="https://bit.ly/2DgcKgC" target="_blank">View Demo</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-16.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Madical</h2>
                                            <p>
                                                <a href="https://bit.ly/2KIw8J1" target="_blank"> View Demo</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-20.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Bike App</h2>
                                            <p>
                                                <a href="https://bit.ly/2DhGmtJ" target="_blank">View Demo </a>
                                            </p>
                                        </div>
                                    </div>
                                </div>

                                <!-- 1 No row tab End -->
                                <!-- 2 No row tab start -->
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-5.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Electronics</h2>
                                            <p>
                                                <a href="https://bit.ly/2XzyV8U" target="_blank"> View Demo</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-11.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Consultancy</h2>
                                            <p>
                                                <a href="https://bit.ly/2VlikIF" target="_blank">View Demo</a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-7.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Tour and Travel</h2>
                                            <p>
                                                <a href="https://bit.ly/2UFxPHa" target="_blank">View Demo </a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-2.jpg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Natural</h2>
                                            <p>
                                                <a href="https://bit.ly/2VkN1hg" target="_blank">View Demo </a>
                                            </p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 2 No row tab end -->
                            </div>
                        </div>
                    </div>
                    <div class="container">
                        <div class="catbox catbox2_nomargin">
                            <div class="row">
                                <!-- 3 No row tab start -->
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-19.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Education</h2>
                                            <p><a href="https://bit.ly/2UT08GN" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-3.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Picnic Spot</h2>
                                            <p><a href="https://bit.ly/2IEXH46" target="_blank"> View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-8.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Personal</h2>
                                            <p><a href="https://bit.ly/2vsmGzj" target="_blank">View Demo </a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-12.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Blog Lifestyle</h2>
                                            <p>
                                                <a href="https://bit.ly/2VmSdku" target="_blank"> View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 3 No row tab End -->
                                <!-- 4 No row tab start -->
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-13.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>News Portal</h2>
                                            <p><a href="https://bit.ly/2ZuQbOD" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-17.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Educational</h2>
                                            <p><a href="https://bit.ly/2ZwQ4Cc" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-14.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>Clinical</h2>
                                            <p><a href="https://bit.ly/2IETTzO" target="_blank">View Demo </a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-4.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>eCommerce</h2>
                                            <p><a href="https://bit.ly/2IJfAz5" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 4 No row tab End -->
                                <!-- 5 No row tab start -->
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-9.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2>News Portal</h2>
                                            <p><a href="https://bit.ly/2v5jskL" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-10.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2> Tour and Travel</h2>
                                            <p><a href="https://bit.ly/2DrmXGL" target="_blank">View Demo </a></p>
                                        </div>
                                    </div>
                                </div>

                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-6.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2> Clinical</h2>
                                            <p><a href="https://bit.ly/2ZuQrx1" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/clients/a-15.jpeg');?>" alt="pic"/>
                                        </div>
                                        <div class="content">
                                            <h2> Photography Websites</h2>
                                            <p><a href="https://bit.ly/2DpTQDZ" target="_blank">View Demo</a></p>
                                        </div>
                                    </div>
                                </div>
                                <!-- 5No row tab End -->
                            </div>
                        </div>
                    </div>
                </div>
                <!-- /.tab-pane 2-->

                <div class="tab-pane" id="tab_proto-2">
                    <div class="container">
                        <div class="catbox catbox2_nomargin">
                            <!-- 5 No row tab start -->
                            <div class="col-md-3 col-sm-6 col-sx-12">
                                <div class="box">
                                    <div class="imgBox">
                                        <img src="<?php echo base_url('assets/images/clients/a-9.jpeg');?>" alt="pic"/>
                                    </div>
                                    <div class="content">
                                        <h2>News Portal</h2>
                                        <p><a href="https://www.ghatalnews.com/" target="_blank">
                                    View Demo
                                </a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-sx-12">
                                <div class="box">
                                    <div class="imgBox">
                                        <img src="<?php echo base_url('assets/images/clients/a-10.jpeg');?>" alt="pic"/>
                                    </div>
                                    <div class="content">
                                        <h2> Tour and Travel</h2>
                                        <p><a href="https://server1.bacpost.com/mypachmarhi/" target="_blank">
                                    View Demo
                                </a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-sx-12">
                                <div class="box">
                                    <div class="imgBox">
                                        <img src="<?php echo base_url('assets/images/clients/a-6.jpeg');?>" alt="pic"/>
                                    </div>
                                    <div class="content">
                                        <h2> Clinical</h2>
                                        <p><a href="https://healinclinical.com/" target="_blank">
                                    View Demo
                                </a></p>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-3 col-sm-6 col-sx-12">
                                <div class="box">
                                    <div class="imgBox">
                                        <img src="<?php echo base_url('assets/images/clients/a-15.jpeg');?>" alt="pic"/>
                                    </div>
                                    <div class="content">
                                        <h2> Photography Websites</h2>
                                        <p><a href="https://server1.bacpost.com/parlour/" target="_blank">
                                    View Demo
                                </a></p>
                                    </div>
                                </div>
                            </div>
                            <!-- 5No row tab End -->
                        </div>
                    </div>
                </div>
                <!--===== =====/.tab-pane ====================-->
                <div class="tab-pane" id="tab_proto-4">
                    <div class="container">
                        <div class="catbox catbox2_nomargin">
                            <div class="row">
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo1.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo2.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo3.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo4.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo5.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo6.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo7.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo8.png');?>" alt="pic"/>
                                        </div>
                                        
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo9.png');?>" alt="pic"/>
                                        </div>
                                        
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo10.png');?>" alt="pic"/>
                                        </div>
                                    
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo11.png');?>" alt="pic"/>
                                        </div>
                                        
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo12.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo13.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo14.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo15.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo16.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo17.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo18.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo19.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo20.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo21.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo22.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>  
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo23.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div> 
                                <br>
                                <div class="col-md-3 col-sm-6 col-sx-12">
                                    <div class="box1">
                                        <div class="imgBox">
                                            <img src="<?php echo base_url('assets/images/websitelogo24.png');?>" alt="pic"/>
                                        </div>
                                    </div>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.tab-content -->
        </div>
        <!-- tab end------------------------------->
        <!-- nav-tabs-custom -->
        <!-- About Section Two -->
        <section class="about-section-two">
            <div class="auto-container">
                <div class="row clearfix">
                    <div class="content-column col-md-4 col-sm-12 col-xs-12">
                        <div class="inner-column">
                            <h2>WHO WE<br/>ARE</h2>
                            <div class="text">
                                <p>We are a team of creative thinkers and tech-savvy developers with the perspective of digital advancement. With our innovative approach, we have helped many small as well as large scale enterprises to achieve their desired business goals. Our digital marketing experts have resolved many barriers of hundreds of businesses in order to experience an uninterrupted way towards success. </p>
                                <p>We thrive to achieve Excellency with our work and thus enhance your business portfolio.  We have helped many businesses to achieve their financial and administrative goals. There are hundreds of businesses that are relying on our website design, Web and mobile application work, and digital marketing services. </p>
                            </div>
                        </div>
                    </div>
                    <div class="image-column col-md-8 col-sm-12 col-xs-12">
                        <div class="inner-column">
                            <figure><img src="<?php echo base_url('assets/images/resource/about-image.jpg');?>" alt="pic"/></figure>
                        </div>
                    </div>
                </div>
            </div>
            <!-- About Section Two -->
            <!--Gallery Single Section-->
            <section class="gallery-single-section">
                <div class="auto-container">
                    <img src="<?php echo base_url('assets/images/portfolio-1.svg');?>" alt="pic"/>
                </div>
            </section>
            <!--End Gallery Single Section-->
        </section> 
        <!--End pagewrapper-->
        <?php 
            //footer
           // include_once("include/footer.php");
            ?>