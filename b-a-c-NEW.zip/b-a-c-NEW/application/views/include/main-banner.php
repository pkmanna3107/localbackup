 <section class="main-slider">

        <div class="rev_slider_wrapper fullwidthbanner-container"  id="rev_slider_one_wrapper" data-source="gallery">

            <div class="rev_slider fullwidthabanner" id="rev_slider_one" data-version="5.4.1">

                <ul>   

                	

                    <!-- Slide Two -->

                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1689" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-1.jpg" alt="pic" data-title="Slide Title" data-transition="parallaxvertical">

                        <img alt="pic" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/main-slider/image-5.jpg"> 

                        

                        <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme big-ipad-hidden rs-parallaxlevel-3" 

                        

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="auto"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['250','250','200','200']"

                        data-voffset="['0','0','0','0']"

                        data-x="['left','left','left','left']"

                        data-y="['bottom','bottom','bottom','bottom']"

                        data-frames='[{"from":"x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/content-img-2.png" alt="pic"></figure>

                        </div>



                        <div class="tp-caption tp-resizeme rs-parallaxlevel-3 ipad-hidden" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="none"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['-10','15','15','15']"

                        data-voffset="['70','70','70','70']"

                        data-x="['right','right','right','right']"

                        data-y="['top','top','top','top']"

                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/circle-1.png" alt="pic"></figure>

                        </div>

                        

                        <div class="tp-caption tp-resizeme rs-parallaxlevel-6 ipad-hidden" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="none"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['-60','60','60','60']"

                        data-voffset="['100','100','100','100']"

                        data-x="['right','right','right','right']"

                        data-y="['top','top','top','top']"

                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/circle-2.png" alt="pic"></figure>

                        </div>

                        

                        <div class="tp-caption tp-resizeme rs-parallaxlevel-7 ipad-hidden" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="none"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['170','170','100','100']"

                        data-voffset="['100','100','100','100']"

                        data-x="['left','left','left','left']"

                        data-y="['top','top','top','top']"

                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/content-img-3.png" alt="pic"></figure>

                        </div>



                        <div class="tp-caption tp-resizeme rs-parallaxlevel-5 ipad-hidden" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="none"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['-100','-100','-100','-100']"

                        data-voffset="['30','30','30','30']"

                        data-x="['right','right','right','right']"

                        data-y="['bottom','bottom','bottom','bottom']"

                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/drop-3.png" alt="pic"></figure>

                        </div>



                        <div class="tp-caption rs-parallaxlevel-2" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="text"

                        data-height="none"

                        data-width="['1000','1000','700','400']"

                        data-whitespace="normal"

                        data-hoffset="['-60','15','15','15']"

                        data-voffset="['-25','-25','-25','-45']"

                        data-x="['left','left','left','left']"

                        data-y="['middle','middle','middle','middle']"

                        data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <h1 class="alternate">Success <br><span class="theme_color">be</span><span class="light">yond boundaries.</span></h1>

                        </div>



                        <div class="tp-caption rs-parallaxlevel-4" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="text"

                        data-height="none"

                        data-whitespace="nowrap"

                        data-hoffset="['-60','15','15','15']"

                        data-voffset="['250','250','100','120']"

                        data-x="['left','left','left','left']"

                        data-y="['middle','middle','middle','middle']"

                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <a href="about.html" class="theme-btn btn-style-one"><span>Get Started</span></a>

                        </div>



                       

                    </li> 

                    

                    <!-- Slide One -->

                    <li data-description="Slide Description" data-easein="default" data-easeout="default" data-fsmasterspeed="1500" data-fsslotamount="7" data-fstransition="fade" data-hideafterloop="0" data-hideslideonmobile="off" data-index="rs-1688" data-masterspeed="default" data-param1="" data-param10="" data-param2="" data-param3="" data-param4="" data-param5="" data-param6="" data-param7="" data-param8="" data-param9="" data-rotate="0" data-saveperformance="off" data-slotamount="default" data-thumb="images/main-slider/image-1.jpg" alt="pic" data-title="Slide Title" data-transition="parallaxvertical">

                        <img alt="pic" class="rev-slidebg" data-bgfit="cover" data-bgparallax="10" data-bgposition="center center" data-bgrepeat="no-repeat" data-no-retina="" src="images/main-slider/image-1.jpg"> 

                        



                        <div class="tp-caption rs-parallaxlevel-1" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="text"

                        data-height="none"

                        data-width="['560','800','800','580']"

                        data-whitespace="normal"

                        data-hoffset="['-50','15','15','15']"

                        data-voffset="['-205','-205','-120','-120']"

                        data-x="['left','left','left','left']"

                        data-y="['middle','middle','middle','middle']"

                        data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>
                                
                            <h3>Turning <span class="theme_color">your</span></h3>

                        </div>



                        <div class="tp-caption rs-parallaxlevel-2" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="text"

                        data-height="none"

                        data-width="['1000','1000','700','400']"

                        data-whitespace="normal"

                        data-hoffset="['-60','15','15','15']"

                        data-voffset="['-25','-25','-25','-25']"

                        data-x="['left','left','left','left']"

                        data-y="['middle','middle','middle','middle']"

                        data-frames='[{"from":"y:[-100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <h1><span class="light">ideas into </span> reality!</h1>

                        </div>



                        <div class="tp-caption rs-parallaxlevel-4" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="text"

                        data-height="none"

                        data-whitespace="nowrap"

                        data-hoffset="['-50','15','15','15']"

                        data-voffset="['185','185','100','100']"

                        data-x="['left','left','left','left']"

                        data-y="['middle','middle','middle','middle']"

                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <a href="about.html" class="theme-btn btn-style-one"><span>Get Started</span></a>

                        </div>



                        <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme big-ipad-hidden rs-parallaxlevel-3" 

                        

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="auto"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['600','600','600','600']"

                        data-voffset="['0','0','0','0']"

                        data-x="['left','left','left','left']"

                        data-y="['bottom','bottom','bottom','bottom']"

                        data-frames='[{"from":"x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/content-img-1.png" alt="pic"></figure>

                        </div>



                        <div class="tp-caption tp-shape tp-shapewrapper tp-resizeme rs-parallaxlevel-6"

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="auto"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['730','730','730','730']"

                        data-voffset="['30','30','30','30']"

                        data-x="['left','left','left','left']"

                        data-y="['bottom','bottom','bottom','bottom']"

                        data-frames='[{"from":"x:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":1000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":1000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/leaf.png" alt="pic"></figure>

                        </div>



                        <div class="tp-caption tp-resizeme rs-parallaxlevel-5 ipad-hidden" 

                        data-paddingbottom="[0,0,0,0]"

                        data-paddingleft="[0,0,0,0]"

                        data-paddingright="[0,0,0,0]"

                        data-paddingtop="[0,0,0,0]"

                        data-responsive_offset="on"

                        data-type="shape"

                        data-height="none"

                        data-whitespace="nowrap"

                        data-width="none"

                        data-hoffset="['250','15','15','15']"

                        data-voffset="['-270','0','0','0']"

                        data-x="['center','center','center','center']"

                        data-y="['middle','middle','middle','middle']"

                        data-frames='[{"from":"y:[100%];z:0;rX:0deg;rY:0;rZ:0;sX:1;sY:1;skX:0;skY:0;","mask":"x:0px;y:0px;s:inherit;e:inherit;","speed":1500,"to":"o:1;","delay":2000,"ease":"Power3.easeInOut"},{"delay":"wait","speed":3000,"to":"auto:auto;","mask":"x:0;y:0;s:inherit;e:inherit;","ease":"Power3.easeInOut"}]'>

                            <figure><img src="images/main-slider/drop.png" alt="pic"></figure>

                        </div>

                    </li> 

                    

                </ul>

            </div>

        </div>

    </section>

    <!--End Main Slider-->