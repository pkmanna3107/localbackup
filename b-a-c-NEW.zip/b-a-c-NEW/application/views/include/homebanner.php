<div class="welcome-image-area version particle-bg" data-stellar-background-ratio="0.6">
    <div id="particles-js"></div>
    <div class="display-table">
        <div class="display-table-cell">
            <div class="container">
                <div class="row">
                    <div class="col-md-12">
                        <div class="header-text text-center">
                            <h2 class="cd-headline clip is-full-width">
                                <span class="cd-words-wrapper">
                                <b class="is-visible">Turning Your Thougts <span class="di_ing">into Reality</span> </b>
                                <b>Success Beyond <span class="di_ing">Boundaries</span> </b>
                            </span>
                            </h2>
                            <p>We are a creative web design agency who makes beautiful websites for thousands of peoples.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
  <div class="bo1">
        <img src="<?php echo base_url('assets/images/logo1.png');?>" itemprop="logo" alt="Bacpost Technologies Pvt. Ltd." class="logo-white">
    </div>
</div>
