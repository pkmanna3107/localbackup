</div> 
    <!--Bottom Parallax-->
   <!--Bottom Parallax-->
   <div class="bottom-parallax">
		<!--Main Footer-->
		<footer class="main-footer">
			<!--Upper-->
			<div class="footer-upper "></div>
			<div class="footer-button boot">
				<div class="auto-container">
					<div class="row clearfix">
						<div class="footer-column col-md-3 col-sm-3 col-xs-12">
						
						</div>
						<div class="footer-column col-md-6 col-sm-6 col-xs-12 f-btn">
							<div class="inner-column in-bor">
								<a href="<?php echo base_url('');?>">
									<img src="<?php echo base_url('assets/images/logo1.png');?>" alt="pic">
									
								</a>

									<ul class="social-links">
										<br/>
										<li>
											<a href="https://facebook.com/businessalphabets"
											target="_blank"><i class="fa fa-facebook"></i></a>
										</li>
										<li>
											<a href="https://twitter.com/BAC_Asia"
											target="_blank">
												<i class="fa fa-twitter"></i>
											</a>
										</li>
										<li>
										<a href="https://www.linkedin.com/company/businessalphabets"
										target="_blank">
											<i class="fa fa-linkedin" aria-hidden="true"></i></a>
										</li>
										<li>
											<a href="https://in.pinterest.com/bacpostofficial/" target="_blank">
											<i class="fa fa-pinterest"></i></a>
										</li>

										<li>
											<a href="https://www.instagram.com/bacpost/"
											target="_blank"><i class="fa fa-instagram" aria-hidden="true"></i></a>
										</li>
									</ul>
									<p>© 2019 All rights reserved | Powered by Business Alphabet Corporation</p>
							</div>
						</div>
						<div class="footer-column col-md-3 col-sm-3 col-xs-12">
							
						</div>
					</div>
				</div>
			<div class="footer-bootom">
				<div class="auto-container">
					<div class="row">
						<div class="col-sm-4">
							<h3>Product</h3>
							<ul class="f-btn1">
								<li><a href="https://www.bacpost.com">Email Marketing</a></li>
								<li><a href="https://bacpost.com/bulksms">SMS Service</a></li>
								<li><a href="">Cab Booking</a></li>
								<li><a href="our-all-services">More</a></li>
							</ul>
						</div>
						<div class="col-sm-4">
							<h3>The Company</h3>
							<ul class="f-btn1">
								<li><a href="<?php echo base_url('');?>about-the-bac">About Us</a></li>
								<li><a href="https://blog.businessalphabets.com/">Blog</a></li>
								<li><a href="<?php echo base_url('');?>terms-and-conditions">Terms of Use</a></li>
								<li><a href="<?php echo base_url('');?>privacy-policy">Privacy Policy</a></li>
<!-- 								<li><a href="<?php //echo base_url('');?>refund-policy">Refund Policy</a></li> -->
							</ul>
						</div>
						<div class="col-sm-4">
							<h3>Help</h3>
							<ul class="f-btn1">
								<li><a href="<?php echo base_url('');?>contact-to-us">Contact Us</a></li>
								<li><a href="https://support.bacpost.com/portal/home">Support</a></li>
								<li><a href="<?php echo base_url('');?>start-your-career-with-us">Career</a></li>
								<li><a href="https://support.bacpost.com/portal/kb">Knowledge Base</a></li>
							</ul>
						</div>
					</div>
				</div>
			</div>
			</div>
			
		</footer>
		<!-- End Footer -->
	</div>
	<!--End Bottom Parallax-->
	<!--End Bottom Parallax-->
	



<div class="scroll-to-top scroll-to-target" data-target="html"><span class="fa fa-angle-double-up"></span></div>

<!--End pagewrapper-->

<script src="<?php echo base_url('assets/js/jquery-3.4.0.min.js');?>"></script>

<script src='https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.6.2/js/bootstrap-select.min.js'></script> 

<script src="<?php echo base_url('assets/js/popper.min.js');?>"></script>
<!--Revolution Slider-->
<script src="<?php echo base_url('assets/plugins/revolution/js/jquery.themepunch.revolution.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/jquery.themepunch.tools.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.actions.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.carousel.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.kenburn.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.layeranimation.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.migration.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.navigation.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.parallax.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.slideanims.min.js');?>"></script>
<script src="<?php echo base_url('assets/plugins/revolution/js/extensions/revolution.extension.video.min.js');?>"></script>
<script src="<?php echo base_url('assets/js/main-slider-script.js');?>"></script> 
<!--End Revolution Slider-->


<script src="<?php echo base_url('assets/js/owl.js');?>"></script>
<script src="<?php echo base_url('assets/js/wow.js');?>"></script>
<script src="<?php echo base_url('assets/js/appear.js');?>"></script>
<script src="<?php echo base_url('assets/js/jquery.fancybox.js');?>"></script>
<script src="<?php echo base_url('assets/js/jquery-ui.js');?>"></script>
<script src="<?php echo base_url('assets/js/isotope.js');?>"></script>
<script src="<?php echo base_url('assets/js/element-in-view.js');?>"></script>
<script src="<?php echo base_url('assets/js/script.js');?>"></script>
<script src="<?php echo base_url('assets/js/isotope.pkgd.min.js');?>"></script>
<!--Google Map APi Key-->
<script src="<?php echo base_url('assets/js/map-script.js');?>"></script>
<script src="<?php echo base_url('assets/js/multi-scroll.js');?>"></script>
<!--End Google Map APi-->
<script src="<?php echo base_url('assets/js/classie.js');?>"></script>
<script src="<?php echo base_url('assets/js/edit.js');?>"></script>
<!--recaptcha/js/13.3.19-->



<!-- navigation -->
<script src="<?php echo base_url('assets/js/common.js');?>"></script>
<script src="<?php echo base_url('assets/js/aos.js');?>"></script>
<script src="<?php echo base_url('assets/js/slick.js');?>"></script>
<script src="<?php echo base_url('assets/js/responsive-tabs.js');?>"></script>


<!-- testimonial js -->

<script src="<?php echo base_url('assets/js/theme-vendors.js');?>"></script>
<script src="<?php echo base_url('assets/js/theme.min.js');?>"></script>
<!-- testimonial js -->

<!---homebannerslider-js-13/04/19---->
<script src="<?php echo base_url('assets/js/animated-text.js');?>"></script>
<script src="<?php echo base_url('assets/js/app.js');?>"></script>
<script src="<?php echo base_url('assets/js/particles.min.js');?>"></script>

<!----owl.carousel.js---start------->
<script src="<?php echo base_url('assets/js/owl.carousel.js');?>"></script>
<script>
   	var owl = $('.owl-carousel');
	    owl.owlCarousel({
		    items:1,
		    loop:true,
		    autoplay:true,
		    dots: true,
		    autoplayTimeout:2000,
		    autoplayHoverPause:true,
		});
</script>
<!-----owl.carousel.js---start------->
<!----smoooth scroll jquyer-start------>
<script>
	$(".first").click(function() {
	    $('html,body').animate({
	        scrollTop: $(".second").offset().top},
	        'slow');
	});
</script>
<!----smoooth scroll jquyer-end------>
</body>
</html>