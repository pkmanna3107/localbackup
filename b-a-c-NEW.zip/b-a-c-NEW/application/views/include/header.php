<!DOCTYPE html> 
<html lang="en">
<meta http-equiv="content-type" content="text/html;charset=UTF-8" />
<head>



<!--    <script src="https://www.google.com/recaptcha/api.js" async defer></script> -->
   
   <!--Google Structured Data-->
<!--    <script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Business Alphabets Corporation",
"legalName" : "BACPOST Technologies Pvt. Ltd.",
  "url": "https://www.businessalphabets.com",
  "logo": "https://www.businessalphabets.com/images/logo1.png",
 "contactPoint": {
 "@type": "ContactPoint",
 "contactType": "customer support",
 "telephone": "[+91-9681-998877]",
 "email": "support@businessalphabets.com"
},
  "sameAs": [
    "http://www.facebook.com/your-profile",
    "https://www.instagram.com/bacpost",
    "http://www.linkedin.com/in/yourprofile",
    "http://plus.google.com/your_profile"
  ]
  }
</script> -->

<!-- Notification alert-->
<!-- <script src="https://cdn.onesignal.com/sdks/OneSignalSDK.js" async=""></script>
<script>
  var OneSignal = window.OneSignal || [];
  OneSignal.push(function() {
    OneSignal.init({
      appId: "758dda26-2516-4b42-b07c-bea0c7f9cfdd",
    });
  });
</script> -->

<!-- Facebook Pixel Code -->
<!-- <script>
  !function(f,b,e,v,n,t,s)
  {if(f.fbq)return;n=f.fbq=function(){n.callMethod?
  n.callMethod.apply(n,arguments):n.queue.push(arguments)};
  if(!f._fbq)f._fbq=n;n.push=n;n.loaded=!0;n.version='2.0';
  n.queue=[];t=b.createElement(e);t.async=!0;
  t.src=v;s=b.getElementsByTagName(e)[0];
  s.parentNode.insertBefore(t,s)}(window, document,'script',
  'https://connect.facebook.net/en_US/fbevents.js');
  fbq('init', '594947264352569');
  fbq('track', 'PageView');
</script>
<noscript><img height="1" width="1" style="display:none"
  src="https://www.facebook.com/tr?id=594947264352569&ev=PageView&noscript=1"
/></noscript> -->
<!-- End Facebook Pixel Code -->


<?php

        $page_url = $_SERVER['REQUEST_URI'];
        
       
       // echo "<script type='text/javascript'>alert('$page_url')</script>";

        
        if($page_url == '/bussinessalphabets/website-design-and-app-development-services'){
            
        echo "<title>Best Website Design and Development Company | BAC</title>";    
        echo "<meta name='description' content='We are the best website design company in Kolkata, India. A part from web designing we provide Web Development, Android app development, IOS development & Digital Marketing solution'>";
        }
        elseif($page_url == '/bussinessalphabets/search-engine-optimization-services'){
            
        echo "<title>Best SEO Service Kolkata | SEO Company India | BAC</title>";
        echo "<meta name='description' content='Business Alphabets Corporation one of the Best SEO Service provider in Kolkata, India.BAC is Best SEO Company in India which offers best organic search engine optimization services in India at affordable price. '>";
        
            
        }
        elseif($page_url == '/bussinessalphabets/digital-marketing-services'){
            
        echo "<title>Best Digital Marketing Company | Digital Agency India | BAC</title>";    
        echo "<meta name='description' content='BAC is Fastest Growing Company Digital Marketing Company in India from Kolkata, offering Digital Marketing Services like SEO, SEM, PPC and SMO.Try our Digital Marketing Services today!!'>";
        
            
        }
        elseif($page_url == '/bussinessalphabets/our-all-services'){
        echo "<title>BAC|Responsive Web Design Services Kolkata</title>";    
        echo "<meta name='BAC is one of the leading Web Development and Design Company in India that offers IT Solutions like Responsive Web Design, android ios app, online POS development, SEO, Digital Marketing etc'>";
        }
        elseif($page_url == '/bussinessalphabets/our-work-and-portfolio'){
            
        echo "<title>Best Web Development and Mobile Application Portfolio</title>";    
        echo "<meta name='description' content='Browse our developed Website & Mobile app that gets a complete idea on how we have turned a simple and raw idea into a successful Website and Mobile Apps. Hers is our Web Development and mobile Application Portfolio.'>";
        
        }
        elseif($page_url == '/bussinessalphabets/about-the-bac'){
        echo "<title>About us BAC - Responsive Web Design Services Kolkata</title>";    
        echo "<style>header nav ul li a{color: #fff !important;}</style>";    
        echo "<style>header.inner-pg nav ul li a, .white-bg header nav ul li a {color: #252a37 !important;}.bor1 {color: #fff ! important;text-transform: inherit ! important;}</style>";              
        echo "<meta name='description' content='BAC is one of the leading Web Development and Design Company in India that offers IT Solutions like Responsive Web Design, android ios app, online POS development, SEO, Digital Marketing etc'>";
        
            
        }
        elseif($page_url == '/bussinessalphabets/contact-to-us'){
        echo "<title>Contact Best Web Development Company in Kolkata</title>";    
        echo "<meta name='description' content='Contact BAC for the Best Web Development Company in Kolkata. Business Alphabets Corporation having offices in USA, AUSTRALIA & Canada and Development Center at Kolkata in India.'>";
       
        }
        elseif($page_url == '/bussinessalphabets/start-your-career-with-us'){          
        echo "<title>Career at Creative web Development Company Kolkata | BAC</title>";    
        echo "<meta name='description' content='we give all benefits to our employees at Creative Website Design & Development Company Kolkata - Business Alphabets Corporation. Just call and confirm your interview timing and venue before interview.'>";
        
            
        }
        elseif($page_url == '/bussinessalphabets/terms-and-conditions'){
        echo "<title>Terms & Conditions of BAC - Think Creative</title>"; 
        echo "<style>header nav ul li a{color: #fff !important;}</style>";    
        echo "<style>header.inner-pg nav ul li a, .white-bg header nav ul li a {color: #252a37 !important;}.bor1 {color: #fff ! important;text-transform: inherit ! important;}</style>";             
        echo "<meta name='description' content='Business Alphabets Corporation Reserved all copyright. We are knows as BAC-Think Creative, BACPOST Technologies Private Limited. We have a corporate terms and conditions. For any issues write us on compaint@businessalphabets.com'>";  
        
            
        }
        elseif($page_url == '/bussinessalphabets/privacy-policy'){
        echo "<style>header nav ul li a{color: #fff !important;}</style>"; 
        echo "<style>header.inner-pg nav ul li a, .white-bg header nav ul li a {color: #252a37 !important;}.bor1{color: #fff ! important;text-transform: inherit ! important;}</style>";  
        echo "<title>Privacy Policy | BAC - Think Creative</title>";    
        echo "<meta name='description' content='Business Alphabets Corporation Reserved all copyright. We are knows as BAC-Think Creative, BACPOST Technologies Private Limited. We have a Privacy Policy. For any issues write us on compaint@businessalphabets.com'>"; 
        
        }
        elseif($page_url == '/bussinessalphabets/404-error'){
        echo "<title>Opps! Page Not Found - 404 | BAC - Think Creative</title>";    
        echo "<meta name='description' content='Sorry the page you are looking for is not exist or removed or temporary down. Please try again after sometime or contact '>"; 
       
        }
        elseif($page_url == '/bussinessalphabets/refund-policy'){
        echo "<style>header nav ul li a{color: #fff !important;}</style>"; 
        echo "<style>header.inner-pg nav ul li a, .white-bg header nav ul li a {color: #252a37 !important;}</style>";  
        echo "<title>Refund Policy | BAC - Think Creative </title>";    
        echo "<meta name='description' content='Business Alphabets Corporation Reserved all copyright. We are knows as BAC-Think Creative, BACPOST Technologies Private Limited. We have a Refund and Cancellation Policy. For any issues write us on compaint@businessalphabets.com'>"; 
        }
        
        else{
        echo "<title>Best website and Mobile App Development Company India | BAC</title>"; 
        echo "<style>header nav ul li a{color: #fff !important;}</style>";    
        echo "<style>header.inner-pg nav ul li a, .white-bg header nav ul li a {color: #252a37 !important;}.bor1 {color: #fff ! important;text-transform: inherit ! important;}</style>";    
        echo "<meta name='keywords' content='Best website and mobile app development company'>";
        echo "<meta name='description' content='BAC Leading website designing and mobile app Development Company in Kolkata, India offers ERP, android ios app, online POS development, SEO, Digital Marketing etc '>";
        }
        


?>   
   
   
  
    <!-- Stylesheets -->
    <!-- <link href="css/bootstrap.css" rel="stylesheet"> -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/bootstrap.css');?>">
     <link rel="stylesheet" href="<?php //echo base_url('assets/css/widget.css');?>">

    <link rel="stylesheet" href="<?php echo base_url('assets/plugins/revolution/css/settings.css');?>">

<!--     <link href="https://www.businessalphabets.com/plugins/revolution/css/settings.css" rel="stylesheet" type="text/css"> -->
    <!-- REVOLUTION SETTINGS STYLES -->
<!--     <link href="https://www.businessalphabets.com/plugins/revolution/css/layers.css" rel="stylesheet" type="text/css"> -->

    <link rel="stylesheet" href="<?php echo base_url('assets/plugins/revolution/css/layers.css');?>">
    <!-- REVOLUTION LAYERS STYLES -->
<!--     <link href="https://www.businessalphabets.com/plugins/revolution/css/navigation.css" rel="stylesheet" type="text/css"> -->
    <link rel="stylesheet" href="<?php echo base_url('assets/plugins/revolution/css/navigation.css');?>">
    <!-- REVOLUTION NAVIGATION STYLES -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style2.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/responsive.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/style_menu.css');?>">

<!--     <link href="css/style.css" rel="stylesheet">
    <link href="css/style2.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet"> 
    <link href="css/style_menu.css" rel="stylesheet">  -->
<!-- flag country -->
<!--     <link rel='stylesheet' href='https://www.businessalphabets.com/css/select.min.css' /> -->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/select.min.css');?>">
    
    <link rel='stylesheet' href='https://cdnjs.cloudflare.com/ajax/libs/flag-icon-css/0.8.2/css/flag-icon.min.css'/> 

    <!----homebannerslider-start--13-04-19-->
    <link rel="stylesheet" href="<?php echo base_url('assets/css/animated-text.css');?>">
    <link rel="stylesheet" href="<?php echo base_url('assets/css/mine.css');?>">



<!--     <link rel="stylesheet" href="css/animated-text.css" type="text/css" />
    <link rel="stylesheet" href="css/mine.css" type="text/css" /> -->
    <!----homebannerslider------->

    <!--Favicon-->
    <link rel="shortcut icon" href="<?php echo base_url('assets/images/favicon1.png');?>" type="image/x-icon"/>
    <link rel="icon" href="<?php echo base_url('assets/images/favicon1.png');?>" type="image/x-icon"/>

    <link media="all" rel="stylesheet" href="<?php echo base_url('assets/css/countrySelect.css');?>">
    <link media="all" rel="stylesheet" href="<?php echo base_url('assets/css/intlTelInput.css');?>">

<!--     <link media="all" type="text/css" rel="stylesheet" href="css/countrySelect.css">
    <link media="all" type="text/css" rel="stylesheet" href="css/intlTelInput.css"> -->
    <!-- Responsive -->
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
    <!-------owl.carousel.min.css-start----------->
    <link rel="stylesheet" type="text/css" href="<?php echo base_url('assets/css/owl.carousel.min.css');?>"/>
    <!-------owl.carousel.min.css-end----------->
  

</head>
<script>
    window.cf_country = 'IN';
</script>

<body>
    <!-- Load Facebook SDK for JavaScript -->
<!-- <div id="fb-root"></div>
<script>
  window.fbAsyncInit = function() {
    FB.init({
      xfbml            : true,
      version          : 'v3.2'
    });
  };

  (function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = 'https://connect.facebook.net/en_US/sdk/xfbml.customerchat.js';
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script> -->

<!-- Your customer chat code -->
<!-- <div class="fb-customerchat"
  attribution=setup_tool
  page_id="1250155178335102"
  theme_color="#fa3c4c">
</div> -->

<!-- Global site tag (gtag.js) - Google Analytics -->
<!-- <script async src="https://www.googletagmanager.com/gtag/js?id=UA-111557195-4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-111557195-4');
</script> -->

    <div class="page-wrapper bg-lines social-icon-left">
        <!-- Preloader -->
        <section class="wapper aos-all common-var " id="transcroller-body">
            <div class="request-quote">
                <div class="request-quote-inner-bg">
                    <div class="re-qu-header">
                        <div class="re-qu-header-logo">
                            <a href="<?php echo base_url('');?>">
                                <img src="<?php echo base_url('assets/images/logo1.png');?>" alt="Best Website and Mobile App Development Company" title="BAC Think Creative">
                            </a>
                        </div>
                        <div class="close-icon">
                           <span class="Close"><i class="fa fa-times" aria-hidden="true"></i></span>
                            <span>Close</span>
                        </div>
                    </div>
                    <div class="re-qu-title">
                        <div class="header-content">
                            <div class="container">
                                <div class="quote-titile">Get the Best Quote for Your Project!</div>
                                <p>Let us know about your requirements and we’ll get back to you within 24 hours</p>
                            </div>
                        </div>
                    </div>
                    <div class="error-container">
                    </div>
                    <div class="re-qu-input">
                        <div class="container">
                            
                  <div class="col-md-12 frist_1">
                    <div class="touch_lt">
                      
                      <div class="row back-chang">
                          
                          
                        <?php //include("template-part/contact.php")

                          $this->load->view('template-part/contact');

                        ?>
                     
                     
                      </div>
                      </div>
                  </div>


                             
                        </div>
                    </div>
                    <div class="re-qu-footer">
                        <div class="container">
                            <h3>Other Ways To Meet Us</h3>
                            <ul class="Information-sec">
                                <li>
                                  <a href="">
                                    <span class="noty"><i class="fa fa-envelope" aria-hidden="true"></i></span>
                                   hello@bacpost.com 
                                  </a>
                                </li>
                                <li>
                                <a href="">
                                  <span class="noty"><i class="fa fa-phone" aria-hidden="true"></i></span>
                                +91 9681-998877</a>
                              </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
            <div class="request-quote-bg"></div>
        </section>

        <header class="">
            <div class="nav-part nav-bar">
                <div class="nav-bar-wt">
                    <div class="nav-container">
                            <a class="logo" href="<?php echo base_url('');?>" itemprop="url">
                                <img src="<?php echo base_url('assets/images/logo1.png');?>" itemprop="logo" alt="Bac logo" class="logo-white">
                                <img src="<?php echo base_url('assets/images/logo1.png');?>" itemprop="logo" alt="Bac logo" class="logo-black">
                            </a>
                        <button id="toggle-navigation" class="nav-bar__toggle-navigation reset-button">
                            <div class="toggle-icon">
                                <span></span>
                                <span></span>
                                <span></span>
                            </div>
                        </button>
                    </div>
                </div>
                <nav id="navigation" class="navigation">
                    <div class="navigation-blocks"><span></span></div>
                    <ul id="navigation-list" class="navigation__list list-unstyled">
                        <li class="menu-listing"><a href="<?php echo base_url('');?>">HOME</a></li>
                        <li class="menu-listing">
                          <a href="<?php echo base_url(); ?>website-design-and-app-development-services">WEB</a></li>
                        <li class="menu-listing">
                          <a href="<?php echo base_url(); ?>search-engine-optimization-services">SEO</a>
                        </li>

                        <li class="menu-listing">
                          <a href="<?php echo base_url(); ?>digital-marketing-services">MARKETING</a>
                        </li>
                        <li class="menu-listing">
                          <a href="<?php echo base_url(); ?>our-all-services">SERVICES</a>
                        </li>
                        <li class="menu-listing">
                          <a href="<?php echo base_url(); ?>our-work-and-portfolio">PORTFOLIO</a>
                        </li>

                        <div class="menu-listing">
                          <div class="dropdown">

                         <a href="#" class="dropdown-toggle bor1" 
                           data-toggle="dropdown">MORE
                          <span class="caret"></span>
                          </a>

                          <ul class="dropdown-menu">
                          <li><a tabindex="-1" href="https://blog.businessalphabets.com/"><b>Blog</b></a></li>
                          <li><a tabindex="-1" href="<?php echo base_url('');?>start-your-career-with-us"><b>Career</b></a></li>
                          <li><a tabindex="-1" href="https://support.bacpost.com/portal/kb"><b>FAQ</b></a></li>
                          <li><a tabindex="-1" href="<?php echo base_url('');?>contact-to-us"><b>Contact Us</b></a></li>
                          </ul>
                          </div>
                        </div>


                        <li class="inquiry-now menu-listing"><a href="#transcroller-body"><span>Get a Quote</span></a></li>
                    </ul>
                </nav>
            </div>
        </header>
        
<div class="preloader"></div>



<?php

 $page_url = $_SERVER['REQUEST_URI'];
 
 
if($page_url == '/index'){
echo '<script type="text/javascript">
           window.location = "https://www.businessalphabets.com"
      </script>';
} 


?>

<script>
$(document).ready(function(){
  $('.dropdown a.test').on("click", function(e){
    $(this).next('ul').toggle();
    e.stopPropagation();
    e.preventDefault();
  });
});
</script>


<style type="text/css">
  
.btn {font-size: 15px ! important;}
.dropdown-menu>li>a{ color: #333 !important;}
.dropdown-menu{ min-width: 125px !important; border: 0px solid rgba(0,0,0,.15) !important; margin: 13px 0 0 !important;}
.btn-default {background-color: #fff0 ! important; }

.bor1{ font-size: 16px; color:#1c1c1c; font-weight: 600; }
.googlefirms{
 position: relative; margin-top: -42px; margin-left: 57px; }
.carousel-items{ margin-top:125px; }

@media only screen and (max-width:767px) {
 .open>.dropdown-menu{ position: relative; width: 100%; text-align: center; }
 .btn-default{ color: #333 !important; }
 .dropdown-menu{ 
     border: 1px solid #ccc; 
     border: 1px solid rgba(0,0,0,.15); 
     border-radius: 4px; 
     -webkit-box-shadow: 0 0px 0px rgba(0,0,0,.0); 
     box-shadow: 0 0px 0px rgba(0,0,0,.1); 
}
.bor1{ color: #1c1c1c !important;}
/*.googlefirms{ display: none; }*/
.work-section .work-block{ padding: 0; }

}


</style>