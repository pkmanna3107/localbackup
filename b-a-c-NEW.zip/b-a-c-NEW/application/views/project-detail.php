<?php 

//header

include_once("include/header.php");



?>



    <!--Page Title-->

    <section class="page-title" style="background-image:url(images/background/1.jpg);">

        <div class="auto-container">

            <!-- Animated Icons -->

            <div class="anim-icons">

                <span class="icon-1"></span>

                <span class="icon-2"></span>

                <span class="icon-3"></span>

                <span class="icon-4"></span>

                <span class="icon-5"></span>

                <span class="icon-6"></span>

                <span class="icon-7"></span>

                <span class="icon-8"></span>

                <span class="icon-9"></span>

            </div>

            

            <h1>Project Detail</h1>

            <ul class="bread-crumb">

                <li><a href="index.html">Home </a></li>

                <li>Project Detail</li>

            </ul>

        </div>

    </section>

    <!--End Page Title-->



    <!-- Gallery Section -->

    <section class="project-detail">

        <div class="details_pro_head">

            <h2>http://bacpost.com/</h2>

            <div class="auto-container">

            <div class="lower-content"> 

                <ul class="info">

                    <li><h4>Date</h4><span>26 Nov 2018</span></li>

                    <li><h4>Client Name</h4><span>Jhone Smith , USA- 02</span></li>

                    <li><h4>Project Type</h4><span>Search Engine Optimization</span></li>

                </ul>

            </div>

        </div>

        </div>

        <div class="auto-container">

            <div class="row">

        <div class="col-md-7">

            <div class="lower-content">

                <h5>Leverage agile frameworks to provide a robust synopsis for high level overviews. Iterative approaches to corporate strategy foster collaborative thinking to further the overall value proposition. Organically grow the holistic world view of disruptive innovation via workplace diversity and empowerment.</h5>

                <p>Bring to the table win-win survival strategies to ensure proactive domination. At the end of the day, going forward, a new normal that has evolved from generation X is on the runway heading towards a streamlined cloud solution. User generated content in real-time will have multiple touchpoints for offshoring.</p>

                <p>Capitalize on low hanging fruit to identify a ballpark value added activity to beta test. Override the digital divide with additional clickthroughs from DevOps. Nanotechnology immersion along the information highway will close the loop on focusing solely on the bottom line.</p>

            </div>

        </div>    

            <div class="col-md-5">

                <div class="image-box">

                    <figure><img src="images/clients/website13.jpg" alt="pic"></figure>



                    <h4>The best theme I’ve used so for<br> that has the best customer suppor</h4>

                </div>

            </div>

                

        </div>

            <div class="related-projects">

                <h3>Related Project</h3>

                <div class="project-carousel-two owl-carousel owl-theme">

                    <!-- Project Block -->

                    <div class="project-block">

                        <div class="image-box">

                            <figure><img src="images/gallery/13.jpg" alt="pic"></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block">

                        <div class="image-box">

                            <figure><img src="images/gallery/14.jpg" alt="pic"></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>



                    <!-- Project Block -->

                    <div class="project-block">

                        <div class="image-box">

                            <figure><img src="images/gallery/15.jpg" alt="pic"></figure>

                            <div class="overlay-box">

                                <div class="content">

                                    <span>Branding</span>

                                    <h4><a href="project-detail.html">Home Decoration</a></h4>

                                </div>

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </section>

    <!-- Gallery Section -->









<!--End pagewrapper-->



            <?php 

            //footer

            include_once("include/footer.php");



            ?>

