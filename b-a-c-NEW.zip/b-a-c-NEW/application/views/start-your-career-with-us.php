<?php 

//header

//include_once("include/header.php");
?>

<?php 

//carrer banner

//include_once("include/career-banner.php");


$this->load->view('include/career-banner');


?>
    <!-- About Section Two -->

    <section class="about-section-two second">

        <div class="auto-container">

            <div class="row clearfix">
<!--headding-->
        <div class="col-md-10 col-md-offset-1">

            <div class="mean_get_touch career_mean_gettouch">

                <div class="sec-title text-center get_touch">

                    <span class="title">THE COMPANY </span>

                    <h2>OUR STORY</h2>

                </div>
                <p class="tex_get_touch">Our inception brings a new perspective for different industrial sectors. Our innovative approach towards<br> web technologies helped many businesses to achieve their decided business goals. </p>
            
            </div>
        </div>
<!-- headdin end button -->

            <div class="features">
                <div class="row clearfix">

                    <!-- Feature Block -->

                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">

                        <div class="inner-box wow fadeInLeft">

                            <div class="icon-box"><i class="flaticon-target-2">
                                <img src="<?php echo base_url('assets/images/icons/carre_1.png');?>" alt="pic"/></i></div>

                            <h3>09 THOUSAND+</h3>

                            <h4>CUSTOMER BASE</h4>
                        </div>
                    </div>
                    <!-- Feature Block -->

                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">

                        <div class="inner-box wow fadeInUp">

                            <div class="icon-box"><i class="flaticon-browser-3">
                                <img src="<?php echo base_url('assets/images/icons/carre_2.png');?>" alt="pic"/></i></div>

                            <h3>200+</h3>

                            <h4>CITIES COVERED</h4>

                        </div>

                    </div>

                    <!-- Feature Block -->

                    <div class="feature-block col-md-4 col-sm-6 col-xs-12">

                        <div class="inner-box wow fadeInRight">

                            <div class="icon-box"><i class="flaticon-mail-1">
                                <img src="<?php echo base_url('assets/images/icons/carre_3.png');?>" alt="pic"/></i></div>

                            <h3>05+</h3>

                            <h4>BRANCHES</h4> 
                        </div>

                    </div>

                </div>

            </div>
<!-- features end row -->
            <div class="form-group text-center">
               <a href="about-the-bac" class="theme-btn btn-style-one" >Know More <i class="flaticon-play"></i></a>
            </div>
       </div>
    </div>
</section>

    <!-- About Section Two -->

   <!-- About Section Two -->

    <section class="about-section-two culure_career">

        <div class="auto-container">
<!--headding-->
        <div class="row clearfix">
        <div class="col-md-10 col-md-offset-1">

            <div class="mean_get_touch career_mean_gettouch">

                <div class="sec-title text-center get_touch">

                    <span class="title">THE CULTURE</span>

                    <p>We are a professional family helping each other to deliver an efficient and scalable project. </p>

                </div>
            </div>
        </div>
    </div>
    <!-- end row headding -->

    <div class="row">
        <div class="culture_career">

            <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                <img src="<?php echo base_url('assets/images/car-1.png');?>" alt="pic"/>
            </div>
            <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                <img src="<?php echo base_url('assets/images/car-2.png');?>" alt="pic"/>
            </div>
            <div class="feature-block col-md-4 col-sm-6 col-xs-12">
                <img src="<?php echo base_url('assets/images/car-3.png');?>" alt="pic"/>
            </div>
    </div>
</div>
<!-- features end row -->
            <div class="form-group text-center">
                <a href="about-the-bac" class="theme-btn btn-style-one" >Know More <i class="flaticon-play"></i></a>
            </div>
</div>

<section class="Section">
    <div class="the-roles">

            <div class="sec-title text-center">

                <span class="title">THE ROLES</span>

                    <h2>SEE WHERE YOU FIT IN</h2>

                    <p>COUFUSED WHERE TO START? SEARCH JOBS OR TEAM</p>

                    <span><img src="<?php echo base_url('assets/images/gallery/cuurr.png');?>" alt="pic"/></span>
            </div>
<div class="row">
    <div class="container">
        <div class="indeedjobs-widget current-sub" data-id="0c8664c9087ab083baad" data-theme="light" data-height="1200" style="padding: 50px"></div> <script> (function(d, id) { if (d.getElementById(id)) return; var js = d.createElement('script'); js.id = id; js.src = 'https://www.indeedjobs.com/widget.js'; d.head.appendChild(js); })(document, 'indeedjobs-js'); </script>
    </div>
</div>

</div>
</section>


</section>

<?php 

//footer

//include_once("include/footer.php");

?>
