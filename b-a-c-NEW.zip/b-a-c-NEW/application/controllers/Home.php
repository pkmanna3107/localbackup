<?php
header('Access-Control-Allow-Origin: *');
header("Access-Control-Allow-Methods: GET, POST, OPTIONS, PUT, DELETE");
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller {


    function __construct()
    {
        // Construct the parent class
        parent::__construct();
        //$this->output->cache(60); // Will expire in 60 minutes
    }

	public function index()
	{
		$this->load->view('include/header');
		$this->load->view('include/homebanner');
		$this->load->view('index');
		$this->load->view('include/footer');
	}


	public function web()
	{
		$this->load->view('include/header');
		$this->load->view('website-design-and-app-development-services');
		$this->load->view('include/footer');
	}

	public function seo()
	{
		$this->load->view('include/header');
		$this->load->view('search-engine-optimization-services');
		$this->load->view('include/footer');
	}	

	public function marketing()
	{
		$this->load->view('include/header');
		$this->load->view('digital-marketing-services'); 
		$this->load->view('include/footer');
	}

	public function services()
	{
		$this->load->view('include/header');
		$this->load->view('our-all-services');
		$this->load->view('include/footer');
	}

	public function portfolio()
	{
		$this->load->view('include/header');
		$this->load->view('our-work-and-portfolio');
		$this->load->view('include/footer');
	}	
	


	public function about()
	{
		$this->load->view('include/header');
		$this->load->view('about-the-bac');
		$this->load->view('include/footer');
	}	


	public function terms()
	{
		$this->load->view('include/header');
		$this->load->view('terms-and-conditions');
		$this->load->view('include/footer');
	}	


	public function privacy()
	{
		$this->load->view('include/header');
		$this->load->view('privacy-policy');
		$this->load->view('include/footer');
	}			
	

	public function contact()
	{
		$this->load->view('include/header');
		$this->load->view('contact-to-us');
		$this->load->view('include/footer');
	}	



	public function career()
	{
		$this->load->view('include/header');
		$this->load->view('start-your-career-with-us');
		$this->load->view('include/footer');
	}	


	public function sweetalerts()
	{

		$this->load->view('sweetalerts');

	}	



    public function addContact()
    {


        $data['first_name']             =$this->input->post('first_name');
        $data['last_name']              =$this->input->post('last_name');          
        $data['email']                  =$this->input->post('email');
        $data['code']                   =$this->input->post('code');
        $data['phone']                  =$this->input->post('phone');
        $data['message']                =$this->input->post('message');


		 $first_name = $data['first_name'] ;

		 $last_name = $data['last_name'] ; 

		 $email = $data['email']; 

		 $code = $data['code'];

		 $mobile = $data['phone'];

		 $message = $data['message'];



		if($code == '+91'){
		 
		    $msg = "Hi ".$first_name." ".$last_name."\nThank you for showing your interest, We will get in touch with you sortly\nThanks\nwww.bacpost.com\nCall: 8622817015";
		    
		    $msg2 = "BAC - \n".$first_name." ".$last_name."\n".$email."\n".$mobile.". \n".$message."\nThanks";
		    

		    
		    $cSession = curl_init(); 
		    curl_setopt($cSession,CURLOPT_URL,'http://139.59.0.192/http-api.php?username=bisalp&password=124578&senderid=BACPST&route=1&number='.$mobile.'&message='.urlencode($msg));
		    curl_setopt($cSession,CURLOPT_RETURNTRANSFER,true);
		    curl_setopt($cSession,CURLOPT_HEADER, false); 
		    curl_exec($cSession);
		    curl_close($cSession);
		    
		        $cSession2 = curl_init(); 
		    curl_setopt($cSession2,CURLOPT_URL,'http://139.59.0.192/http-api.php?username=bisalp&password=124578&senderid=BACPST&route=1&number=8622817015,9903325447&message='.urlencode($msg2));
		    curl_setopt($cSession2,CURLOPT_RETURNTRANSFER,true);
		    curl_setopt($cSession2,CURLOPT_HEADER, false); 
		    curl_exec($cSession2);
		    curl_close($cSession2);  

        $this->load->view('sweetalerts');

		}else{
		       $msg2 = "BAC - \n".$first_name." ".$last_name."\n".$email."\n".$mobile.". \n".$message."\nThanks"; 
		        $cSession2 = curl_init(); 
		    curl_setopt($cSession2,CURLOPT_URL,'http://139.59.0.192/http-api.php?username=bisalp&password=124578&senderid=BACPST&route=1&number=8622817015,9903325447&message='.urlencode($msg2));
		    curl_setopt($cSession2,CURLOPT_RETURNTRANSFER,true);
		    curl_setopt($cSession2,CURLOPT_HEADER, false); 
		    curl_exec($cSession2);
		    curl_close($cSession2); 
		$this->load->view('sweetalerts');
        
    	}


    }





 //    public function sendEmail()
 //    	{
 //        $data['name']           =$this->input->post('name');
 //        $data['email']          =$this->input->post('email');          
 //        $data['subject']        =$this->input->post('subject');
 //        $data['message']        =$this->input->post('message');

 //        $name                   =$data['name'];
 //        $fromemail              =$data['email'];
 //        $subject                =$data['subject'];
 //        $message                =$data['message'];
            
	// 	$config = Array(
	// 	'protocol' => 'smtp',
 //        'smtp_host' => '139.59.83.25',
 //        'smtp_port' => 25,
 //        'smtp_user' => 'info@goldedgevillage.com',
 //        'smtp_pass' => 'nM_2K5nLoi=f',
 //        'mailtype'  => 'html', 
 //        'charset' => 'utf-8',
 //        'wordwrap' => TRUE
 //    );
		
	// 	$this->load->library('email',$config);
	// 	$this->email->from($fromemail);
	// 	$this->email->to('info@goldedgevillage.com');

	// 	$this->email->subject($subject);
	// 	$this->email->message('Dear Sir,<br><br>'
	// 	.$message.
	// 	'<br><br>Thank You.<br><br>'
	// 	.$name
	// 	);
		
 //    	if ( ! $this->email->send())
 //    {
 //        echo $this->email->print_debugger();
 //    }   else{
  
 //        echo '<script>alert("Your message has been send successfully!");</script>';
 //        $url = 'home/contact';
 //        echo'
 //        <script>
 //        window.location.href = "'.base_url().$url.'";
 //        </script>
 //        ';           
        
         
 //    }
		
		
	// }            
            
            




}
