$(function(){
    $('.selectpicker').selectpicker();
});
