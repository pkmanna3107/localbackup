(function($) {

	

	"use strict";

	

	

	//Hide Loading Box (Preloader)

	function handlePreloader() {

		if($('.preloader').length){

			$('.preloader').delay(200).fadeOut(500);

		}

	}

	

	

	//Update Header Style and Scroll to Top

	function headerStyle() {

		if($('.main-header').length){

			var windowpos = $(window).scrollTop();

			var siteHeader = $('.main-header');

			var scrollLink = $('.scroll-to-top');

			if (windowpos >= 50) {

				siteHeader.addClass('fixed-header');

				scrollLink.fadeIn(300);

			} else {

				siteHeader.removeClass('fixed-header');

				scrollLink.fadeOut(300);

			}

		}

	}

	

	headerStyle();

	

	//Submenu Dropdown Toggle

	if($('.main-header li.dropdown ul').length){

		$('.main-header li.dropdown').append('<div class="dropdown-btn"><span class="fa fa-angle-down"></span></div>');

		

		//Dropdown Button

		$('.main-header li.dropdown .dropdown-btn').on('click', function() {

			$(this).prev('ul').slideToggle(500);

		});

		

		//Megamenu Toggle

		$('.main-header .main-menu li.dropdown .dropdown-btn').on('click', function() {

			$(this).prev('.mega-menu').slideToggle(500);

		});

		

		//Disable dropdown parent link

		$('.main-header .navigation li.dropdown > a,.hidden-bar .side-menu li.dropdown > a').on('click', function(e) {

			e.preventDefault();

		});

	}

	

	

	//Hidden Bar Menu Config

	function hiddenBarMenuConfig() {

		var menuWrap = $('.hidden-bar .side-menu');

		// hidding submenu 

		menuWrap.find('.dropdown').children('ul').hide();

		// toggling child ul

		menuWrap.find('li.dropdown > a').each(function () {

			$(this).on('click', function (e) {

				e.preventDefault();

				$(this).parent('li.dropdown').children('ul').slideToggle();

	

				// adding class to item container

				$(this).parent().toggleClass('open');

	

				return false;

	

			});

		});

	}

	

	hiddenBarMenuConfig();

	
// jQuery for page scrolling feature - requires jQuery Easing plugin
// $(function() {
//     $('a.page-scroll').bind('click', function(event) {
//         var $anchor = $(this);
//         $('html, body').stop().animate({
//             scrollTop: $($anchor.attr('href')).offset().top
//         }, 1500, 'easeInOutExpo');
//         event.preventDefault();
//     });
// });

// // Highlight the top nav as scrolling occurs
// $('body').scrollspy({
//     target: '.navbar-fixed-top'
// })

// // Closes the Responsive Menu on Menu Item Click
// $('.navbar-collapse ul li a').click(function() {
//     $('.navbar-toggle:visible').click();
// });
	

	//Hidden Sidebar

	if ($('.hidden-bar').length) {

		var hiddenBar = $('.hidden-bar');

		var hiddenBarOpener = $('.hidden-bar-opener');

		var hiddenBarCloser = $('.hidden-bar-closer');

		var navToggler = $('.nav-toggler');

		$('.hidden-bar-wrapper').mCustomScrollbar();

		

		//Show Sidebar

		hiddenBarOpener.on('click', function () {

			hiddenBar.toggleClass('visible-sidebar');

			navToggler.toggleClass('open');

		});

		

		//Hide Sidebar

		hiddenBarCloser.on('click', function () {

			hiddenBar.toggleClass('visible-sidebar');

			navToggler.toggleClass('open');

		});

		

	}



	//Masonary

	function enableMasonry() {

		if($('.masonry-items-container').length){

	

			var winDow = $(window);

			// Needed variables

			var $container=$('.masonry-items-container');

	

			$container.isotope({

				itemSelector: '.masonry-item',

				 masonry: {

					columnWidth : '.column-width'

				 },

				animationOptions:{

					duration:500,

					easing:'linear'

				}

			});

	

			winDow.on('resize', function(){



				$container.isotope({ 

					itemSelector: '.masonry-item',

					animationOptions: {

						duration: 500,

						easing	: 'linear',

						queue	: false

					}

				});

			});

		}

	}

	

	enableMasonry();

	

	

	//Masonary Two

	function enableMasonryTwo() {

		if($('.masonry-two').length){

	

			var winDow = $(window);

			// Needed variables

			var $container=$('.masonry-two');

	

			$container.isotope({

				itemSelector: '.masonry-item',

				 masonry: {

					columnWidth : '.masonry-item',

				 },

				animationOptions:{

					duration:500,

					easing:'linear'

				}

			});

	

			winDow.on('resize', function(){



				$container.isotope({ 

					itemSelector: '.masonry-item',

					animationOptions: {

						duration: 500,

						easing	: 'linear',

						queue	: false

					}

				});

			});

		}

	}

	

	enableMasonryTwo();

	

	//Portfolio Carousel one

	if ($('.portfolio-carousel-one').length) {

		$('.portfolio-carousel-one').owlCarousel({

			animateOut: 'fadeOut',

    		animateIn: 'fadeIn',

			loop:true,

			mouseDrag:false,

			margin:30,

			nav:true,

			smartSpeed: 700,

			autoplay: true,

			autoplayTimeout:7000,

			navText: [ '<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>' ],

			responsive:{

				0:{

					items:1

				},

				600:{

					items:1

				},

				1024:{

					items:1

				},

			}

		});    		

	}



	//Portfolio Carousel Two

	if ($('.portfolio-carousel-two').length) {

		$('.portfolio-carousel-two').owlCarousel({

			animateOut: 'fadeOut',

    		animateIn: 'fadeIn',

			loop:true,

			mouseDrag:false,

			margin:30,

			nav:true,

			smartSpeed: 700,

			autoplay: true,

			autoplayTimeout:7000,

			navText: [ '<span class="arrow-left"></span>', '<span class="arrow-right"></span>' ],

			responsive:{

				0:{

					items:1

				},

				600:{

					items:1

				},

				1024:{

					items:1

				},

			}

		});    		

	}

	

	//Portfolio Carousel Slider

	if ($('.portfolio-carousel-three').length) {

		$('.portfolio-carousel-three').owlCarousel({

			loop:true,

			margin:20,

			nav:true,

			smartSpeed: 700,

			autoplay: 4000,

			navText: [ '<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>' ],

			responsive:{

				0:{

					items:1

				},

				600:{

					items:2

				},

				800:{

					items:3

				},

				1024:{

					items:4

				},

				1600:{

					items:5

				}

			}

		});    		

	}



	//Testimonial Carousel

	if ($('.testimonial-carousel').length) {

		$('.testimonial-carousel').owlCarousel({

			loop:true,

			margin:20,

			nav:true,

			smartSpeed: 700,

			autoplay: 4000,

			navText: [ '<span class="arrow-left"></span>', '<span class="arrow-right"></span>' ],

			responsive:{

				0:{

					items:1

				},

				600:{

					items:1

				},

				1024:{

					items:1

				},

			}

		});    		

	}



	//Testimonial Carousel

	if ($('.single-item-carousel').length) {

		$('.single-item-carousel').owlCarousel({

			loop:true,

			margin:20,

			nav:true,

			smartSpeed: 700,

			autoplay: 4000,

			navText: [ '<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>' ],

			responsive:{

				0:{

					items:1

				},

				600:{

					items:1

				},

				1024:{

					items:1

				},

			}

		});    		

	}	

//sponser

	if ($('.sponsors-carousel').length) {

		$('.sponsors-carousel').owlCarousel({

			loop:true,

			margin:0,

			nav:false,

			smartSpeed: 700,

			autoplay: 4000,

			navText: [ '<span class="fa fa-angle-left"></span>', '<span class="fa fa-angle-right"></span>' ],

			responsive:{

				0:{

					items:1

				},

				600:{

					items:3

				},

				800:{

					items:4

				},

				1200:{

					items:4

				},

			}

		});    		

	}

	//isotop

	

	//LightBox / Fancybox

	if($('.lightbox-image').length) {

		$('.lightbox-image').fancybox({

			openEffect  : 'fade',

			closeEffect : 'fade',

			helpers : {

				media : {}

			}

		});

	}

	

	//Contact Form Validation

	if($('#contact-form').length){

		$('#contact-form').validate({

			rules: {

				username: {

					required: true

				},

				email: {

					required: true,

					email: true

				},

				phone: {

					required: true

				},

				message: {

					required: true

				}

			}

		});

	}

	

	// Scroll to a Specific Div

	if($('.scroll-to-target').length){

		$(".scroll-to-target").on('click', function() {

			var target = $(this).attr('data-target');

		   // animate

		   $('html, body').animate({

			   scrollTop: $(target).offset().top

			 }, 1500);

	

		});

	}

	

	

	//Progress Bar

	if($('.progress-line').length){

		$('.progress-line').appear(function(){

			var el = $(this);

			var percent = el.data('width');

			$(el).css('width',percent+'%');

		},{accY: 0});

	}

	

	

	//Tabs Box

	if($('.tabs-box').length){

		$('.tabs-box .tab-buttons .tab-btn').on('click', function(e) {

			e.preventDefault();

			var target = $($(this).attr('data-tab'));

			

			if ($(target).is(':visible')){

				return false;

			}else{

				target.parents('.tabs-box').find('.tab-buttons').find('.tab-btn').removeClass('active-btn');

				$(this).addClass('active-btn');

				target.parents('.tabs-box').find('.tabs-content').find('.tab').fadeOut(0);

				target.parents('.tabs-box').find('.tabs-content').find('.tab').removeClass('active-tab');

				$(target).fadeIn(300);

				$(target).addClass('active-tab');

			}

		});

	}

	

	

	// Elements Animation

	if($('.wow').length){

		var wow = new WOW(

		  {

			boxClass:     'wow',      // animated element css class (default is wow)

			animateClass: 'animated', // animation css class (default is animated)

			offset:       0,          // distance to the element when triggering the animation (default is 0)

			mobile:       true,       // trigger animations on mobile devices (default is true)

			live:         true       // act on asynchronously loaded content (default is true)

		  }

		);

		wow.init();

	}



	//Fact Counter + Text Count

	if($('.count-box').length){

		$('.count-box').appear(function(){

	

			var $t = $(this),

				n = $t.find(".count-text").attr("data-stop"),

				r = parseInt($t.find(".count-text").attr("data-speed"), 10);

				

			if (!$t.hasClass("counted")) {

				$t.addClass("counted");

				$({

					countNum: $t.find(".count-text").text()

				}).animate({

					countNum: n

				}, {

					duration: r,

					easing: "linear",

					step: function() {

						$t.find(".count-text").text(Math.floor(this.countNum));

					},

					complete: function() {

						$t.find(".count-text").text(this.countNum);

					}

				});

			}

			

		},{accY: 0});

	}

	

	//Bottom Parallax

	function bottomParallax() {

		if($('.bottom-parallax').length){

			var windowpos = $(window).scrollTop();

			var siteFooter = $('.main-footer').height();

			var sitebodyHeight = $('.page-wrapper').height();

			var finalHeight = sitebodyHeight - siteFooter - 1100;

			if (windowpos >= finalHeight) {

				$('body').addClass('parallax-visible');

			} else {

				$('body').removeClass('parallax-visible');

			}

		}

	}

	

	bottomParallax();

	

	//Make Content Sticky

	if($('.sticky-box').length){

		var a = new StickySidebar('.portfolio-single .content-column .inner', {

			topSpacing: 80,

			bottomSpacing: 0,

			containerSelector: '.sticky-container',

			innerWrapperSelector: '.sticky-box'

		});

	}

	

	//Split Scroll (Home 7)	

	if($('#scroll-container').length){

		$('#scroll-container').multiscroll({

			navigation: true,

			css3:true

		});

	}

	



/* ==========================================================================

   When document is Scrollig, do

   ========================================================================== */

	

	$(window).on('scroll', function() {

		headerStyle();

		bottomParallax();

	});

	

/* ==========================================================================

   When document is loading, do

   ========================================================================== */

	

	$(window).on('load', function() {

		handlePreloader();

		enableMasonry();

		enableMasonryTwo();

	});





/* ==========================================================================

   When page is resized

   ========================================================================== */

	

	$(window).on('resize', function() {

		

	});



/* ==========================================================================

   When document is Resize, do

   ========================================================================== */

	



})(window.jQuery);



