<!DOCTYPE html>
<html lang="en"> 
<head>
  <title>Import CSV File</title>
  <meta charset="utf-8">
  <link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <style type="text/css">
    .panel-heading a{float: right;}
    #importFrm{margin-bottom: 20px;display: none;}
    #importFrm input[type=file] {display: inline;}

.abc{
    position: relative;
    margin-top: 85px;
}
.bob {
    background: cornsilk;
    width: 50%;
    height: 450px;
    left: 0;
    top: 15%;
    box-shadow: 3px 3px 3px grey;
    right: 0;
    margin: 0 auto;
    box-sizing: border-box;
    text-align: center;
}
.bob input[type=file]{ display: inline-block; width: 35%; height: 100%;border: 1px solid grey; background: grey; color: #fff;border-radius: 5px;}
.bob .btn-primary {  margin: 40px 0 0 0; padding: 12px 20px; }
.bob .btn-primary1  { 
  margin: 25px 0 50px 0; 
  padding: 12px 20px; 
  display: inline-block;
  color: #fff;
  background-color: #204d74;
  border-color: #122b40;
  border-radius: 5px;
   }

::-webkit-file-upload-button {
  background: grey;
  color: #fff;
  padding: 1em;
  border: none;
}
.iamges1{ position: absolute; top: 0; left: 0; right: 0; bottom: 0; margin: 0 auto;
 background: rgba(247, 247, 248, 0.74); width: 100%;  height: 100%; z-index: 999;}
  </style>
}


</head>
<body>
<div class="iamges1" id="loaderImg" style="display: none;">
<img src="<?php echo base_url("images/preloader.gif");?>" alt="loader1" style="width: 150px;height: 150px;z-index: 999;position: absolute;top: 30%;left: 44%;">
</div>
<div class="abc">
<div class="container bob">
    <h2 style="font-family: none;text-shadow: 3px 3px 3px #9a988df5;">Import CSV File Data into MySQL Database</h2>
    <?php if(!empty($status)){
        echo '<div class="alert alert-success">'.$status.'</div>';
    } ?>



<a class="btn-primary1" href="<?php echo site_url("welcome/download/");?>" align="center">Download Csv</a>

            <form action="<?php echo site_url("welcome/upload_file");?>" method="post" enctype="multipart/form-data" id="myForm">
                <input type="file" name="file" /><br>
                <input type="submit" class="btn btn-primary" name="importSubmit" value="IMPORT">
            </form>
</div>
</div>
</body>
</html>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>

<script type="text/javascript">
  
$(function(){
  $('#myForm').submit(function() {
    $('#loaderImg').show(); 
    return true;
  });
});

</script>
