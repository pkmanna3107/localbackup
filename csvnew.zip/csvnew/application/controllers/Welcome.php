<?php 
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	public function index()
	{
		$this->load->view('csvToMySQL');
	}
	public function upload_file(){
		
		$this->load->helper('string');
		$csvMimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
	    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
	        if(is_uploaded_file($_FILES['file']['tmp_name'])){
	            
	            //open uploaded csv file with read only mode
	            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
	            
	            // skip first line
	            // if your csv file have no heading, just comment the next line
	            fgetcsv($csvFile);
	            
	            //parse data from csv file line by line
	            while(($line = fgetcsv($csvFile)) !== FALSE){


				if(!empty($line[6])){

                    $this->db->insert 
                    ("oc_manufacturer",
	                     array(
	                    "name"=>$line[6],
	                ));

   				} 
                   $this->db->insert 
                    ("oc_product",
	                     array(
	                    "model"=>random_string('alnum', 16),
	                    "sku"=>$line[0],
	                    "quantity"=>$line[2],
	                    "image"=>$line[21],
	                    "original_price"=>$line[8],
	                    "price"=>$line[8]*71,
	                    "weight"=>$line[35],
	                    "length"=>$line[32],
	                    "width"=>$line[33],
	                    "height"=>$line[34],
	                    "date_added"=>date('Y-m-d H:i:s')

	                ));

	            }
	            
	            //close opened csv file
	            fclose($csvFile);

	            $qstring["status"] = 'Success';
	        }else{
	            $qstring["status"] = 'Error';
	        }
	    }else{
	        $qstring["status"] = 'Invalid file';
	    }
	    $this->upload_file1();
	    //$this->upload_file3();
	    //$this->load->view('csvToMySQL',$qstring);
	}



	public function upload_file1(){
		$this->load->helper('string');
		$csvMimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
	    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
	        if(is_uploaded_file($_FILES['file']['tmp_name'])){
	            
	            //open uploaded csv file with read only mode
	            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
	            
	            // skip first line
	            // if your csv file have no heading, just comment the next line
	            fgetcsv($csvFile);
	            

$oc_product = $this->db->select('*')
                            ->from('oc_product')
                            ->where(array())
                            ->get()->result_array();

                foreach($oc_product as $row){	
                
$product_id = $row['product_id'];

	            //parse data from csv file line by line
	            while(($line = fgetcsv($csvFile)) !== FALSE){

                    $this->db->insert 
                    ("oc_product_description",
	                     array(
	                    "product_id"=>$product_id,
	                    "description"=>$line[19],
	                    "color"=>$line[3],
	                    "size"=>$line[5]
	                 ));

$product_id++;

                    }

	            }

	            //close opened csv file
	            fclose($csvFile);

	            $qstring["status"] = 'Success';
	        }else{
	            $qstring["status"] = 'Error';
	        }
	    }else{
	        $qstring["status"] = 'Invalid file';
	    }
	    $this->upload_file2();
	    //$this->load->view('csvToMySQL',$qstring);
	}



	public function upload_file2(){
		$this->load->helper('string');
		$csvMimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
	    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
	        if(is_uploaded_file($_FILES['file']['tmp_name'])){
	            
	            //open uploaded csv file with read only mode
	            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
	            
	            // skip first line
	            // if your csv file have no heading, just comment the next line
	            fgetcsv($csvFile);
	            

			$oc_product = $this->db->select('*')
				                    ->from('oc_product')
				                    ->where(array())
				                    ->get()->result_array();

			                foreach($oc_product as $row){	
			                
			$product_id = $row['product_id'];

	            //parse data from csv file line by line
	            while(($line = fgetcsv($csvFile)) !== FALSE){


				$longShift = true;

				switch (true) {

					case ($line[11] != 0 && $line[11] !=null):
                    $this->db->insert 
                    ("oc_product_to_category",
	                     array(
	                    "product_id"=>$product_id,
	                    "category_id"=>$line[11]

	                 ));
						break;


					case ($line[13] != 0 && $line[13] !=null):

                    $this->db->insert 
                    ("oc_product_to_category",
	                     array(
	                    "product_id"=>$product_id,
	                    "category_id"=>$line[13]

	                 ));
						break;


					case ($line[15] != 0 && $line[15] !=null):

                    $this->db->insert 
                    ("oc_product_to_category",
	                     array(
	                    "product_id"=>$product_id,
	                    "category_id"=>$line[15]

	                 ));
						break;


					case ($line[17] != 0 && $line[17] !=null):

                    $this->db->insert 
                    ("oc_product_to_category",
	                     array(
	                    "product_id"=>$product_id,
	                    "category_id"=>$line[17]

	                 ));
						break;

					default:
                    $this->db->insert 
                    ("oc_product_to_category",
	                     array(
	                    "product_id"=>$product_id,
	                    "category_id"=>0

	                 ));
						break;

					}
		$product_id++;

                    
                }
	        }
	            //close opened csv file
	            fclose($csvFile);

	            $qstring["status"] = 'Success';
	        }else{
	            $qstring["status"] = 'Error';
	        }
	    }else{
	        $qstring["status"] = 'Invalid file';
	    }
	    $this->upload_file3();
	    $this->load->view('csvToMySQL',$qstring);
	}




	public function upload_file3(){
		$this->load->helper('string');
		$csvMimes = array('application/vnd.ms-excel','text/plain','text/csv','text/tsv');
	    if(!empty($_FILES['file']['name']) && in_array($_FILES['file']['type'],$csvMimes)){
	        if(is_uploaded_file($_FILES['file']['tmp_name'])){
	            
	            //open uploaded csv file with read only mode
	            $csvFile = fopen($_FILES['file']['tmp_name'], 'r');
	            
	            // skip first line
	            // if your csv file have no heading, just comment the next line
	            fgetcsv($csvFile);
	            
$oc_product = $this->db->select('*')
                            ->from('oc_product')
                            ->where(array())
                            ->get()->result_array();

                foreach($oc_product as $row){	
                
				$product_id = $row['product_id'];

	            while(($line = fgetcsv($csvFile)) !== FALSE){

		$table_array_index_key = array( //if your array does not have a named key.
		    0 => array( //first row
		        0 => $line[22],
		        ),
		    1 => array( //second row
		        0 => $line[23],
		        ),
		    2 => array( //second row
		        0 => $line[24],
		        ),

		    3 => array( //second row
		        0 => $line[25],
		        ),

		    4 => array( //second row
		        0 => $line[26],
		        ),
		    5 => array( //first row
		        0 => $line[27],
		        ),
		    6 => array( //second row
		        0 => $line[28],
		        ),
		    7 => array( //second row
		        0 => $line[29],
		        ),

		    8 => array( //second row
		        0 => $line[30],
		        ),

		    9 => array( //second row
		        0 => $line[31],
		        ),    


		    );


for($x=0;$x<count($table_array_index_key);$x++){
if(!empty($table_array_index_key[$x][0])){
        $this->db->insert 
        ("oc_product_image",
		array(
        	"product_id"=>$product_id,
            'image' => $table_array_index_key[$x][0]
         ));

		}
	}
		$product_id++;

                    }

	            }
	            
	            //close opened csv file
	            fclose($csvFile);

	            $qstring["status"] = 'Success';
	        }else{
	            $qstring["status"] = 'Error';
	        }
	    }else{
	        $qstring["status"] = 'Invalid file';
	    }
	    $this->load->view('csvToMySQL',$qstring);
	}	


public function download()
{
  $file ='Tongkart.csv';
$this->load->helper('download');
$name = $file;
$data = file_get_contents('download/'.$file); 
force_download($name, $data); 
    redirect('csvToMySQL','refresh');
}



}
