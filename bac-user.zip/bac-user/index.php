<?php 
// Header
include_once("include/header.php");
?>

<?php 
// top-menu
include_once("include/menu-top_dashboard.php");
?>

<?php 
// left side menu
include_once("include/sidebar-menu.php");
?>

<?php 
// home post
include_once("template/home.php");
?>

<?php 
// right side menu
include_once("template/activity.php");
?>



<?php 
// right side menu
include_once("include/right-sidebar.php");
?>

<?php 
// right side menu
include_once("include/footer.php");
?>