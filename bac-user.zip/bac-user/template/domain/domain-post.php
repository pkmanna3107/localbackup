<div class="page has-sidebar-left">
   <header class="blue accent-3 relative nav-sticky">
        <div class="container-fluid text-white">
            <div class="row p-t-b-10 ">
                <div class="col">
                    <h4>
                        <i class="icon-box"></i>
                        My Domain
                    </h4>
                </div>
            </div>
            <div class="row">
                <ul class="nav responsive-tab nav-material nav-material-white" id="v-pills-tab">
                    <li>
                        <a class="nav-link active" id="v-pills-1-tab" data-toggle="pill" href="#domain">
                            <i class="icon icon-home2"></i>All Domain</a>
                    </li>
                    <li>
                        <a class="nav-link" id="v-pills-2-tab" data-toggle="pill" href="#transfar-domain"><i class="icon icon-plus-circle mb-3"></i>Transfar Domain</a>
                    </li>
                    <li>
                        <a class="nav-link" id="v-pills-3-tab" data-toggle="pill" href="#trash-domain"><i class="icon icon-calendar"></i>Trash</a>
                    </li>
                </ul>
                <a class="btn-fab fab-right btn-primary" data-toggle="control-sidebar">
                    <i class="icon icon-menu"></i>
                </a>
            </div>
        </div>
    </header>
    <div class="container-fluid relative animatedParent animateOnce">
        <div class="tab-content pb-3" id="v-pills-tabContent">
            <!--Today Tab Start-->
            <div class="tab-pane animated fadeInUpShort show active" id="domain">
    <div class="container-fluid animatedParent animateOnce my-3">
        <div class="animated fadeInUpShort">
            <div class="row">
                <div class="col-md-12">
                    <div class="card no-b shadow">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover ">
                                    <tbody>
                                    <tr class="no-b">
                                    <td><h3>www.bacpost.com</h3>
                                     <div class="my-3">
                                        <small>350/365 days to Complete</small>
                                        <div class="progress" style="height: 3px;">
                                            <div class="progress-bar bg-danger" role="progressbar" style="width: 98%;" aria-valuenow="98"
                                                 aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                    <td></td>
                                    <td><a href="domain-setup.php"><span class="btn btn-info btn-lg r-20">SETUP</span></a></td>
                                    <td><a href="domain-dns.php"><span class="btn btn-success btn-lg r-20">DNS</span></a></td>
                                    <td><span class="btn btn-warning btn-lg r-20">MANAGE</span></td>
                                    </tr>
                                        <tr class="no-b">
                                    <td><h3>www.bacpost.com</h3>
                                     <div class="my-3">
                                        <small>300/365 days to Complete</small>
                                        <div class="progress" style="height: 3px;">
                                            <div class="progress-bar bg-warning" role="progressbar" style="width: 85%;" aria-valuenow="85"
                                                 aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                    <td></td>
                                   <td><a href="domain-setup.php"><span class="btn btn-info btn-lg r-20">SETUP</span></a></td>
                                    <td><a href="domain-dns.php"><span class="btn btn-success btn-lg r-20">DNS</span></a></td>
                                    <td><span class="btn btn-warning btn-lg r-20">MANAGE</span></td>
                                    </tr>
                                   
                             
                                 
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="pt-3" aria-label="Page navigation">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">2</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">3</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
            <div class="tab-pane animated fadeInUpShort show " id="transfar-domain">
                <div class="animated fadeInUpShort">
            <div class="row">
                <div class="col-md-12">
                    <div class="card no-b shadow">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover ">
                                    <tbody>
                                   
                                  
                                        <tr class="no-b">
                                    <td><h3>www.bacpost.com</h3>
                                     <div class="my-3">
                                        <small>135/365 days to Complete</small>
                                        <div class="progress" style="height: 3px;">
                                            <div class="progress-bar bg-info" role="progressbar" style="width: 29%;" aria-valuenow="29"
                                                 aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                    <td></td>
                                    <td><a href="domain-transfer.php"><span class="btn btn-warning btn-lg r-20">MANAGE</span></a></td>
                                    </tr>
                                        <tr class="no-b">
                                    <td><h3>www.bacpost.com</h3>
                                     <div class="my-3">
                                        <small>254/365 days to Complete</small>
                                        <div class="progress" style="height: 3px;">
                                            <div class="progress-bar bg-info" role="progressbar" style="width: 45%;" aria-valuenow="45"
                                                 aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                    <td></td>
                                    <td><a href="domain-transfer.php"><span class="btn btn-warning btn-lg r-20">MANAGE</span></a></td>
                                    </tr>
                                 
                                  
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <nav class="pt-3" aria-label="Page navigation">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">2</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">3</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
            <div class="tab-pane animated fadeInUpShort show " id="trash-domain">
                <div class="animated fadeInUpShort">
            <div class="row">
                <div class="col-md-12">
                    <div class="card no-b shadow">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover ">
                                    <tbody>
                                    <tr class="no-b">
                                    <td><h3>www.bacpost.com</h3>
                                     <div class="my-3">
                                        <small>350/365 days to Complete</small>
                                        <div class="progress" style="height: 3px;">
                                            <div class="progress-bar bg-danger" role="progressbar" style="width: 98%;" aria-valuenow="98"
                                                 aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                    <td></td>
                                    <td><span class="btn btn-danger btn-lg r-20">Renewal </span></td>
                                    <td><span class="btn btn-danger btn-lg r-20">Restore </span></td>

                                    </tr>
                                     </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="pt-3" aria-label="Page navigation">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">2</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">3</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
            </div>
        </div>
    </div>

</div>