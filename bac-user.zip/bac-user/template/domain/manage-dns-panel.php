<div class="page has-sidebar-left height-full">
<div class="container-fluid relative animatedParent animateOnce">
        <div class="tab-content pb-3" id="v-pills-tabContent">
            <div class="row">
                    <div class="col-md-12">
                        <div class="white p-5 r-5">
                             <div class="row">
                                <div class="col-md-7">
                                    <div class="card-title">
                                        <h3>www.omainname.com</h3>
                                        <h5><span class="red-text">Expired on 28-10-2018</span></h5>
                                    </div>
                                </div>
                                
                                 <div class="col-md-3">
                                    <a href="#nameserver"><span class="btn btn-info btn-lg r-20">Nameserver update</span></a>
                                 </div>
                                 <div class="col-md-2">
                                    <span class="btn btn-danger btn-lg r-20">Renew Now </span>
                                 </div>
                            </div>
                            <div class="col-md-12 p-5 r-5">
                               
                                     <button type="button" class="btn btn-info" data-toggle="collapse" data-target="#records">ADD Record</button>   
                                  <div id="records" class="collapse">
                                      <div class="row"> 
                                        <div class="col-md-6">  
                                    <div class="p-5 r-5">
                                        <div class="form-group ">
                                          <div class="form-line">
                                             <select id="inputState" class="form-control" placeholder="TTL *">
                                                <option >Custom</option>
                                                <option>A</option>
                                                <option>CNAME</option>
                                                <option>MX</option>
                                                <option>TXT</option>
                                                 <option>SRV</option>
                                                 <option>AAAA</option>
                                                 <option>CAA</option>
                                              </select>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                        <div class="col-md-6">
                                            <div class="form-group">
                                                <div class="form-line">
                                                      <input type="text" class="form-control" placeholder="Host *" />
                                                </div>
                                            </div>
                                             <div class="form-group">
                                                <div class="form-line">
                                                   <input type="text" class="form-control" placeholder="Points to *" />
                                                 </div>
                                               </div>
                                                <div class="form-group">
                                                   <div class="form-line">
                                                      <select id="inputState" class="form-control" placeholder="TTL *">
                                                        <option>Custom</option>
                                                        <option>1 Hour</option>
                                                        <option>1/2 Hour</option>
                                                        <option>2 Hour</option>
                                                        <option>4 Hour</option>
                                                        <option>1 day</option>
                                                        </select>
                                                    </div>
                                                </div>
                                                <div class="form-group">
                                                    <div class="form-line">
                                                        <input type="text" class="form-control" placeholder="Seconds *" />
                                                    </div>
                                                </div>
                                            <div class="row">
                                                    <span class="col-md-4"><button type="button" class="btn btn-block btn-success btn-flat"  style="color:#fff" data-toggle="collapse" data-target="#demo1"> Update</button>
                                                    </span> 
                                                    <span class="col-md-4" ><button type="button" class="btn btn-block btn-danger btn-flat" style="color:#fff" data-toggle="collapse" data-target="#demo1">Cancel</button>
                                                    </span>	
                                                </div>
                                            </div>
                                      </div>
                                  </div>
                            <div class="row my-3">
                               <div class="col-md-12">
                                    <div class="col-lg-12">
                        <div class="box">
                            <div class="box-header">
                                <h3 class="box-title">Record</h3>
                            </div>
                            
                            <!-- /.box-header -->
                            <div class="box-body no-padding">
                                <table class="table">
                                    <tr>
                                    <th>Type</th>
                                    <th>Name</th>
                                    <th>Value</th>
                                    <th>TTl</th>
                                    <th></th>
                                    </tr>
                                    
                                    <tbody>
                    <tr data-toggle="collapse" data-target="#demo1" class="accordion-toggle">
                        <td>A</td>
                        <td>@</td>
                        <td class="label">103.53.40.92</td>
                      	<td>600 seconds	</td>
                      	<td>
                      		<span ><button type="button" class="btn btn-block btn-danger accordion-toggle"  data-toggle="collapse" data-target="#demo1">Edit</button>
                          </span> 
                      	</td>
                    </tr>
                    <tr class="hiddenRow accordian-body collapse" id="demo1">
                    	<td>
                            <div class="form-group">
                              <div class="form-line">
                                 <input type="text" class="form-control" placeholder="Host *" />
                                </div>
                            </div>
                        </td>
                      	<td>
                            <div class="form-group">
                              <div class="form-line">
                                 <input type="text" class="form-control" placeholder="Points to *" />
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="form-group">
                              <div class="form-line">
                                 <select id="inputState" class="form-control" placeholder="TTL *">
                                            <option>Custom</option>
                                            <option>1 Hour</option>
                                            <option>1/2 Hour</option>
                                            <option>2 Hour</option>
                                            <option>4 Hour</option>
                                            <option>1 day</option>
                                        </select>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="form-group">
                              <div class="form-line">
                                 <input type="text" class="form-control" placeholder="Seconds *" />
                                </div>
                            </div>
                        </td>
                      	<td>
                            <span ><button type="button" class="btn btn-block btn-success btn-flat"  style="color:#fff" data-toggle="collapse" data-target="#demo1"> Update</button>
                          </span> 
                            <span ><button type="button" class="btn btn-block btn-danger btn-flat" style="color:#fff" data-toggle="collapse" data-target="#demo1">Cancel</button>
                          </span>
                      	</td>
                    </tr>  
                </tbody>
                             
                                    <tbody>
                    <tr data-toggle="collapse" data-target="#demo2" class="accordion-toggle">
                        <td>A</td>
                        <td>@</td>
                        <td class="label">103.53.40.92</td>
                      	<td>600 seconds	</td>
                      	<td>
                      		<span ><button type="button" class="btn btn-block btn-danger accordion-toggle"  data-toggle="collapse" data-target="#demo2">Edit</button>
                          </span> 
                      	</td>
                    </tr>
                    <tr class="hiddenRow accordian-body collapse" id="demo2">
                    	<td>
                            <div class="form-group">
                              <div class="form-line">
                                 <input type="text" class="form-control" placeholder="Host *" />
                                </div>
                            </div>
                        </td>
                      	<td>
                            <div class="form-group">
                              <div class="form-line">
                                 <input type="text" class="form-control" placeholder="Points to *" />
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="form-group">
                              <div class="form-line">
                                 <select id="inputState" class="form-control" placeholder="TTL *">
                                            <option>Custom</option>
                                            <option>1 Hour</option>
                                            <option>1/2 Hour</option>
                                            <option>2 Hour</option>
                                            <option>4 Hour</option>
                                            <option>1 day</option>
                                        </select>
                                </div>
                            </div>
                        </td>
                        <td>
                            <div class="form-group">
                              <div class="form-line">
                                 <input type="text" class="form-control" placeholder="Seconds *" />
                                </div>
                            </div>
                        </td>
                      	<td>
                            <span ><button type="button" class="btn btn-block btn-success btn-flat" style="color:#fff" data-toggle="collapse" data-target="#demo2"> Update</button>
                          </span> 
                            <span ><button type="button" class="btn btn-block btn-danger btn-flat" style="color:#fff" data-toggle="collapse" data-target="#demo2"> Cancel</button>
                          </span>
                      	</td>
                    </tr>  
                </tbody>
                                    
                         
                                </table>
                            </div>
                            <!-- /.box-body -->
                               <div class="box-tools">
                                    <ul class="pagination pagination-sm no-margin float-right">
                                        <li class="page-item"><a href="#" class="page-link">&#xAB;</a>
                                        </li>
                                        <li class="page-item"><a href="#" class="page-link">1</a>
                                        </li>
                                        <li class="page-item"><a href="#" class="page-link">2</a>
                                        </li>
                                        <li class="page-item"><a href="#" class="page-link">3</a>
                                        </li>
                                        <li class="page-item"><a href="#" class="page-link">&#xBB;</a>
                                        </li>
                                    </ul>
                                </div>
                        </div>
                        <!-- /.box -->
                       </div>
                      </div>
                     </div>
                     </div>
                    </div>
                </div>
    </div>
                <div class="row white p-5 r-5" id="nameserver">
                    <div class="col-md-6">
                        <h2>Nameservers</h2>
                            <div class="form-group">
                                <div class="form-line">
                                    <input type="text" class="form-control" placeholder="Nameserver1" />
                                </div>
                            </div>
                        <div class="form-group">
                            <div class="form-line">
                                <input type="text" class="form-control" placeholder="Nameserver2" />
                             </div>
                        </div> 
                        <span ><button type="button" class="btn btn-success"><a href="map.html" target="_blank" style="color:#fff"> Update</a></button>
                          </span> 
                    </div>
                    <div class="col-md-6">
                        <h2>Forwarding</h2>
                            <div class="row no-gutters bg-light r-3 p-2 mt-5">
                                        <div class="col-md-6 b-r p-3">
                                                <h5>DOMAIN</h5>
                                                <p>Not Setup</p>
                                                <span class="btn btn-success btn-lg r-20">Add</span>
                                        </div>
                                        <div class="col-md-6 p-3">
                                            <div class="">
                                                <h5>SUBDOMAIN</h5>
                                                <p>Not Setup</p>
                                                <span class="btn btn-success btn-lg r-20">Add</span>
                                            </div>
                                        </div>
                                    </div>
                        
                    </div>
                </div>
        </div>
    </div>

<!-- custome records -->
