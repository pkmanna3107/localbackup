<div class="page has-sidebar-left height-full">
<div class="container-fluid relative animatedParent animateOnce">
        <div class="tab-content pb-3" id="v-pills-tabContent">
            <div class="row">
                    <div class="col-md-12">
                        <div class="white p-5 r-5">
                             <div class="row">
                                <div class="col-md-10">
                                    <div class="card-title">
                                        <h3>www.omainname.com</h3>
                                        <h5><span class="red-text">Expired on 28-10-2018</span></h5>
                                    </div>
                                </div>
                                 <div class="col-md-2">
                                    <span class="btn btn-danger btn-lg r-20">Renew Now </span>
                                 </div>
                            </div>
                            <div class="row my-3">
                                <div class="col-md-4">
                                    <div class="my-3 mt-4">
                                        <h2>Contact Information</h2>
                                        <p>BAC Post
                                            Kolkata
                                            Kolkata, West Bengal
                                            India 700124
                                            +91.9681998877
                                            businessalphabets@gmail.com
                                            </p>
                                    </div>
                                </div>
                                <div class="col-md-4">
                                     <div class="row no-gutters bg-light r-3 p-2 mt-5">
                                        <div class="col-md-6 b-r p-3">
                                                <h5>Add Website</h5>
                                                <span class="btn btn-success btn-lg r-20"><div class=" icon-plus"></div></span>
                                        </div>
                                        <div class="col-md-6 p-3">
                                            <div class="">
                                                <h5>Add Email</h5>
                                                <span class="btn btn-success btn-lg r-20"><div class=" icon-plus"></div></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-4" style="height: 250px">
                                    
                                    <div class="my-3 mt-4">
                                        <h2>Additional Settings</h2>
                                        <p>Automatically renew your domain with your card on file so you never lose your domain.</p>
                                         <P>Locking prevents unauthorized changes, including transfer to another registrar.<br>Domain lock: On <span> <a href="#">Edit</a></span></P>
                                    </div>     
                                     
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
</div>
</div>
</div>