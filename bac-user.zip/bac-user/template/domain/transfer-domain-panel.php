<div class="page has-sidebar-left height-full">
<div class="container-fluid relative animatedParent animateOnce">
        <div class="tab-content pb-3" id="v-pills-tabContent">
            <div class="row">
                    <div class="col-md-12">
                        <div class="white p-5 r-5">
                             <div class="row">
                                <div class="col-md-10">
                                    <div class="card-title">
                                        <h3>www.omainname.com</h3>
                                        <h5><span class="red-text">Expired on 28-10-2018</span></h5>
                                    </div>
                                </div>
                                 <div class="col-md-2">
                                    <span class="btn btn-danger btn-lg r-20">Renew Now </span>
                                 </div>
                            </div>
                            <div class="row my-3">
                                <div class="col-md-6">
                                    <div class="my-3 mt-4">
                                     <div class="form-group">
                                        <div class="form-line">
                                            <label for="text-box">Where are you transferring your domain?</label>
                                         <input type="text" class="form-control" placeholder="Enter Provider Name" id="text-box"/>
                                        </div>
                                     </div>
                                       <div class="form-group">
                                            <label for="textariea">Why are you transferring?</label>
                                            <textarea class="form-control r-0" id="textariea"
                                                      rows="3"></textarea>
                                        </div>
                                        <span class="btn btn-info btn-lg r-20">Next</span>
                                    </div>
                                    
                                     <div class="row no-gutters bg-light r-3 p-2 mt-5">
                                        <div class="col-md-6 b-r p-3">
                                                <h5>Add Website</h5>
                                                <span class="btn btn-success btn-lg r-20"><div class=" icon-plus"></div></span>
                                        </div>
                                        <div class="col-md-6 p-3">
                                            <div class="">
                                                <h5>Add Email</h5>
                                                <span class="btn btn-success btn-lg r-20"><div class=" icon-plus"></div></span>
                                            </div>
                                        </div>
                                    </div>
                                
                                </div>
                                
                                <div class="col-md-6" >
                                    
                                    <div class="my-3 mt-4">
                                        <p translate=""><span class="ng-scope">If you have to transfer, here's what you can expect from the process.</span></p>

<h4 class="headline-primary" translate=""><span class="ng-scope">Domain transfer checklist</span></h4>
<ol class="list-big">
 	<li><span translate=""><span class="ng-scope">Make sure your administrative contact email is current. (It's where we send your transfer authorization code.)</span></span></li><br>
 	<li><span translate=""><span class="ng-scope">Verify that the new registrar will set up your DNS zone files.</span></span>
<span translate=""><strong class="ng-scope">Note:</strong><span class="ng-scope"> If you don't do this, your website and email could go down.</span></span></li><br>
 	<li><span translate=""><span class="ng-scope">Cancel Protected Registration or DBP Private Registration (if needed).</span></span></li><br>
 	<li><span translate=""><span class="ng-scope">Unlock your domain.</span></span>
</li><br>
 	<li><span translate=""><span class="ng-scope">Start the domain transfer at your new registrar. (We email you to ensure you requested the transfer.)</span></span></li><br>
 	<li><span translate=""><span class="ng-scope">Authorize the transfer with your new registrar. (Use the transfer authorization code we email you when you're done here.)</span></span></li><br>
</ol>
                                    </div>     
                                     
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        </div>
    </div>
</div>