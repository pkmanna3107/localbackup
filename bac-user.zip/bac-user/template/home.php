<div class="page has-sidebar-left height-full">
    <header class="blue accent-3 relative nav-sticky">
        <div class="container-fluid text-white">
            <div class="row p-t-b-10 ">
                <div class="col">
                    <h4>
                        <i class="icon-box"></i>
                        My Account
                    </h4>
                </div>
            </div>
            <div class="row">
                <ul class="nav responsive-tab nav-material nav-material-white" id="v-pills-tab">
                    <li>
                        <a class="nav-link active" id="v-pills-1-tab" data-toggle="pill" href="#v-pills-1">
                            <i class="icon icon-home2"></i>Dashboard</a>
                    </li>
                    <li>
                        <a class="nav-link" id="v-pills-2-tab" data-toggle="pill" href="#v-pills-2"><i class="icon icon-plus-circle mb-3"></i>Support</a>
                    </li>
                    <li>
                        <a class="nav-link" id="v-pills-3-tab" data-toggle="pill" href="#v-pills-3"><i class="icon icon-calendar"></i>Support Ticket</a>
                    </li>
                </ul>
                <a class="btn-fab fab-right btn-primary" data-toggle="control-sidebar">
                    <i class="icon icon-menu"></i>
                </a>
            </div>
        </div>
    </header>
    <div class="container-fluid relative animatedParent animateOnce">
        <div class="tab-content pb-3" id="v-pills-tabContent">
            <!--Today Tab Start-->
            <div class="tab-pane animated fadeInUpShort show active" id="v-pills-1">
                <div class="row ">
                    <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3 ">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-security s-48 text-primary"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-primary r-30">
                                        <i class="icon-check mr-2"></i>Domain</span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3 ">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-server s-48 text-success"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-success r-30">
                                        <i class="icon-check mr-2"></i>Hosting</span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                   <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3 ">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-email s-48 text-danger"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-danger r-30">
                                        <i class="icon-check mr-2"></i>Email Hosting</span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3 ">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-th s-48 text-warning"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-warning orange r-30">
                                        <i class="icon-check mr-2"></i>Combo Pack</span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row ">
                    <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-email2 s-48 text-secondary"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-secondary r-30">
                                        <i class="icon-check mr-2"></i>Bulk Email</span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3 ">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-search s-48 text-danger"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-danger r-30">
                                        <i class="icon-check mr-2"></i>Seo</span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                   <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3 ">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-share2 s-48 text-success"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-success r-30">
                                        <i class="icon-check mr-2"></i>Social Media Marketing </span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3 col-6 my-3">
                        <div class="counter-box white r-5 p-3 ">
                            <div class="p-4">
                                <div class="text-center">
                                    <span class="icon-security s-48 text-warning"></span>
                                </div>
                                <div class="mt-3 text-center">
                                    <span class="badge badge-warning orange r-30">
                                        <i class="icon-check mr-2"></i>Domain</span>
                                    <h5 class="sc-counter mt-3">1228</h5>
                                </div>
                            </div>
                            <div class="progress progress-xs r-0">
                                <div class="progress-bar" role="progressbar" style="width: 25%;" aria-valuenow="25"aria-valuemin="0" aria-valuemax="128"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <!--Today Tab End-->
            <!--Yesterday Tab Start-->
            <div class="tab-pane animated fadeInUpShort" id="v-pills-2">
               Abcd
            </div>
            <!--Yesterday Tab Start-->
            <!--Yesterday Tab Start-->
            <div class="tab-pane animated fadeInUpShort" id="v-pills-3">
                
            </div>
            <!--Yesterday Tab Start-->
        </div>
    </div>
</div>