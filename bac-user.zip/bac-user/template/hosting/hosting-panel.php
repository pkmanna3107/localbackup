<div class="page has-sidebar-left">
   <header class="blue accent-3 relative nav-sticky">
        <div class="container-fluid text-white">
            <div class="row p-t-b-10 ">
                <div class="col">
                    <h4>
                        <i class="icon-box"></i>
                        My Hostings
                    </h4>
                </div>
            </div>
            <div class="row">
                <ul class="nav responsive-tab nav-material nav-material-white" id="v-pills-tab">
                    <li>
                        <a class="nav-link active" id="v-pills-1-tab" data-toggle="pill" href="#domain">
                            <i class="icon icon-home2"></i>All Hosting Details </a>
                    </li>
                </ul>
                <a class="btn-fab fab-right btn-primary" data-toggle="control-sidebar">
                    <i class="icon icon-menu"></i>
                </a>
            </div>
        </div>
    </header>
    <div class="container-fluid relative animatedParent animateOnce">
        <div class="tab-content pb-3" id="v-pills-tabContent">
            <!--Today Tab Start-->
            <div class="tab-pane animated fadeInUpShort show active" id="domain">
    <div class="container-fluid animatedParent animateOnce my-3">
        <div class="animated fadeInUpShort">
            <div class="row">
                <div class="col-md-12">
                    <div class="card no-b shadow">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover ">
                                    <tbody>
                                    <tr class="no-b">
                                    <td><h3>www.bacpost.com</h3>
                                     <div class="my-3">
                                        <small>350/365 days to Complete</small>
                                        <div class="progress" style="height: 3px;">
                                            <div class="progress-bar bg-danger" role="progressbar" style="width: 98%;" aria-valuenow="98"
                                                 aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                    <td><p>nss1.bacpost.com</p><p>nss2.bacpost.com</p></td>
                                    <td><span class="btn btn-info btn-lg r-15">Cpanel</span>
                                        <span class="btn btn-warning btn-lg r-15">Edit Password</span></td>
                                    </tr>
                                       
                                        <tr class="no-b">
                                    <td><h3>www.bacpost.com</h3>
                                     <div class="my-3">
                                        <small>300/365 days to Complete</small>
                                        <div class="progress" style="height: 3px;">
                                            <div class="progress-bar bg-warning" role="progressbar" style="width: 85%;" aria-valuenow="85"
                                                 aria-valuemin="0" aria-valuemax="100">
                                            </div>
                                        </div>
                                    </div>
                                    </td>
                                    <td><p>nss1.bacpost.com</p><p>nss2.bacpost.com</p></td>
                                   
                                    <td><span class="btn btn-info btn-lg r-15">Cpanel</span>
                                            <span class="btn btn-warning btn-lg r-15">Edit Password</span></td>
                                    </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="pt-3" aria-label="Page navigation">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">2</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">3</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
           
            
        </div>
    </div>

</div>