<!DOCTYPE html>
<html lang="zxx">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="assets/img/basic/favicon.ico" type="image/x-icon">
    <title>BAC POST- User Panel</title>
    <!-- CSS -->
    <link rel="stylesheet" href="assets/css/app.css">
    <style>
  
  .table tr {
    cursor: pointer;
}
.hiddenRow {
    padding: 0 4px !important;
    background-color: #eeeeee;
    font-size: 14px;
    -webkit-transition: width 80ms ease-in;
    -moz-transition: width 80ms ease-in;
    -ms-transition: width 80ms ease-in;
    -o-transition: width 80ms ease-in;
    transition: width 80ms ease-in;
}

.table>tbody>tr>td>span{
  display:block;
  color: #000;
  font-weight: bold;
}

</style>
</head>
