
<div id="app">
<aside class="main-sidebar fixed offcanvas shadow">
    <section class="sidebar">
        <div class="w-80px mt-3 mb-3 ml-3">
            <img src="assets/img/basic/logo.png" alt="">
        </div>
        <div class="relative">
            <a data-toggle="collapse" href="#userSettingsCollapse" role="button" aria-expanded="false"
               aria-controls="userSettingsCollapse" class="btn-fab btn-fab-sm fab-right fab-top btn-primary shadow1 ">
                <i class="icon icon-cogs"></i>
            </a>
            <div class="user-panel p-3 light mb-2">
                <div>
                    <div class="float-left image">
                        <img class="user_avatar" src="assets/img/dummy/u2.png" alt="User Image">
                    </div>
                    <div class="float-left info">
                        <h6 class="font-weight-light mt-2 mb-1">Welcome BAC Post</h6>
                        <a href="#"><i class="icon-circle text-primary blink"></i> Online</a>
                    </div>
                </div>
                <div class="clearfix"></div>
                <div class="collapse multi-collapse" id="userSettingsCollapse">
                    <div class="list-group mt-3 shadow">
                        <a href="index.html" class="list-group-item list-group-item-action ">
                            <i class="mr-2 icon-umbrella text-blue"></i>Profile
                        </a>
                        <a href="#" class="list-group-item list-group-item-action"><i
                                class="mr-2 icon-cogs text-yellow"></i>Settings</a>
                        <a href="#" class="list-group-item list-group-item-action"><i
                                class="mr-2 icon-security text-purple"></i>Change Password</a>
                    </div>
                </div>
            </div>
        </div>
        <ul class="sidebar-menu">
            <li class="header"><a href="index.php"><strong>Dashboard</strong></a></li>
             <li class="treeview"><a href="#">
                <i class="icon icon-sailing-boat-water purple-text s-18"></i> <span>Dashboard</span> <i
                    class="icon icon-angle-left s-18 pull-right"></i>
            </a>
                <ul class="treeview-menu">
                    <li><a href="domain.php"><i class="icon icon-folder5"></i> 
                    <span>Domain</span>
                    <span class="badge r-3 badge-primary pull-right">4</span></a>
                    </li>
                    <li><a href="hosting.php"><i class="icon icon-folder5"></i>Hosting</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Email Hosting</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>SEO</a>
                    </li>
                    
                </ul>
            </li>
             <li class="treeview"><a href="#">
                <i class="icon icon icon-package blue-text s-18"></i>
                <span>Support Ticket </span>
                <span class="badge r-3 badge-primary pull-right">4</span>
            </a>
                <ul class="treeview-menu">
                    <li><a href="support.php"><i class="icon icon-circle-o"></i>All Tickets</a>
                    </li>
                    <li><a href="support-create.php"><i class="icon icon-add"></i>Add
                        New Tickets </a>
                    </li>
                </ul>
            </li>           
             <li class="treeview"><a href="#">
                <i class="icon icon-cogs purple-text s-18"></i> <span>My Account Sattings</span> <i
                    class="icon icon-angle-left s-18 pull-right"></i>
            </a>
                <ul class="treeview-menu">
                    <li><a href="domain.php"><i class="icon icon-folder5"></i> 
                    <span>My Profile</span></a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Renewals & Billing</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Payment Methods</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Login & PIN</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Delegate Access</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Domain Defaults</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Contact Preferences</a>
                    </li>
                    <li><a href="#"><i class="icon icon-folder5"></i>Payees</a>
                    </li>
                </ul>
            </li>
           
        </ul>
    </section>
</aside>