    <header class="blue accent-3 relative">
        <div class="container-fluid text-white">
            <div class="row p-t-b-10 ">
                <div class="col">
                    <h4>
                        <i class="icon-package"></i>
                        Support
                    </h4>
                </div>
            </div>
            <div class="row">
                <ul class="nav responsive-tab nav-material nav-material-white">
                    <li>
                        <a class="nav-link" href="support.php"><i class="icon icon-list"></i>All Support Tickets</a>
                    </li>
                    <li>
                        <a class="nav-link" href="support-create.php"><i
                                class="icon icon-plus-circle"></i> Add New Tickets</a>
                    </li>
                    <li>
                        <a class="nav-link" href="support-trash.php"><i class="icon icon-trash-can"></i>Trash</a>
                    </li>
                </ul>
            </div>
        </div>
    </header>