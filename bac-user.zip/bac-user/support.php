<?php 
// Header
include_once("include/header.php");
?>

<?php 
// top-menu
include_once("include/menu-top_dashboard.php");
?>

<?php 
// left side menu
include_once("include/sidebar-menu.php");
?> 
    
    
<!--Sidebar End-->

<div class="page has-sidebar-left">

    <?php 
// left side menu
include_once("include/support-menu.php");
?> 
    
    
    
    
    
    
    
    
    <div class="container-fluid animatedParent animateOnce my-3">
        <div class="animated fadeInUpShort">
            <div class="row">
                <div class="col-md-12">
                    <div class="card no-b shadow">
                        <div class="card-body p-0">
                            <div class="table-responsive">
                                <table class="table table-hover ">
                                    <tbody>
                                    <tr class="no-b">
                                        <td class="w-10"><span class="icon-mail-envelope-closed ">#110</span></td>
                                    <td><h6>Emailing Problem</h6>
                                    <small class="text-muted">Emailing Problem Emailing Problem</small>
                                    </td>
                                    <td>$250</td>
                                      <td><span><i class="icon icon-data_usage"></i> 5 days ago</span><br>
                                    <span><i class="icon icon-timer"></i> 17-Aug, 2018</span></td>
                                        <td><span class="icon-user">Asign To: Abhimoy Kolay</span></td>
                                    <td><span class="badge badge-success">Open</span></td>
                                    </tr>
                                    <tr class="no-b">
                                        <td class="w-10"><span class="icon-mail-envelope-open ">#110</span></td>
                                    <td><h6>Emailing Problem</h6>
                                    <small class="text-muted">Emailing Problem Emailing Problem</small>
                                    </td>
                                    <td>$250</td>
                                      <td><span><i class="icon icon-data_usage"></i> 5 days ago</span><br>
                                    <span><i class="icon icon-timer"></i> 17-Aug, 2018</span></td>
                                        <td><span class="icon-user">Asign To: Abhimoy Kolay</span></td>
                                    <td><span class="badge badge-warning">Hold</span></td>
                                    </tr>
                                  
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <nav class="pt-3" aria-label="Page navigation">
                <ul class="pagination">
                    <li class="page-item"><a class="page-link" href="#">Previous</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">1</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">2</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">3</a>
                    </li>
                    <li class="page-item"><a class="page-link" href="#">Next</a>
                    </li>
                </ul>
            </nav>
        </div>
    </div>
</div>
<!-- Right Sidebar -->
<?php 
// right side menu
include_once("template/activity.php");
?>



<?php 
// right side menu
include_once("include/right-sidebar.php");
?>

<?php 
// right side menu
include_once("include/footer.php");
?>