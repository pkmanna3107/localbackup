<?php 
// Header
include_once("include/header.php");
?>

<?php 
// top-menu
include_once("include/menu-top_dashboard.php");
?>

<?php 
// left side menu
include_once("include/sidebar-menu.php");
?> 
    

<div class="page has-sidebar-left">
      <?php 
// left side menu
include_once("include/support-menu.php");
?> 
   
    <div class="container-fluid animatedParent animateOnce my-3">
        <div class="animated fadeInUpShort">
            <form id="needs-validation" novalidate>
                <div class="row">
                    <div class="col-md-8 ">
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="validationCustom01">Enter Title</label>
                                <input type="text" class="form-control" id="validationCustom01"
                                       placeholder="Title" required>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="validationCustom02">Sub Title</label>
                                <input type="text" class="form-control" id="validationCustom02" placeholder="Subtitle"
                                      required>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6 mb-3">
                                <label for="category">Category</label>
                                <!--<input type="text" class="form-control"  placeholder="Mobile Phones" required>-->
                                <select id="category" class="custom-select form-control" required>
                                    <option value="">Domain</option>
                                    <option value="1">Hosting</option>
                                    <option value="2">Email</option>
                                    <option value="3">SEO</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please provide a valid category.
                                </div>
                            </div>
                            <div class="col-md-6 mb-3">
                                <label for="category">Sub Category</label>
                                <!--<input type="text" class="form-control"  placeholder="Mobile Phones" required>-->
                                <select id="category" class="custom-select form-control" required>
                                    <option value="">Domain</option>
                                    <option value="1">Hosting</option>
                                    <option value="2">Email</option>
                                    <option value="3">SEO</option>
                                </select>
                                <div class="invalid-feedback">
                                    Please provide a valid category.
                                </div>
                            </div>
                            
                            
                        </div>
                        <div class="form-group">
                            <label for="productDetails">Problem in Details</label>
                            <textarea class="form-control p-t-40" id="productDetails"
                                      placeholder="Write Something..." rows="17" required></textarea>
                            <div class="invalid-feedback">
                                Please provide a Valid details.
                            </div>
                        </div>
                        
                        <script>
                            // Example starter JavaScript for disabling form submissions if there are invalid fields
                            (function () {
                                "use strict";
                                window.addEventListener("load", function () {
                                    var form = document.getElementById("needs-validation");
                                    form.addEventListener("submit", function (event) {
                                        if (form.checkValidity() == false) {
                                            event.preventDefault();
                                            event.stopPropagation();
                                        }
                                        form.classList.add("was-validated");
                                        var editorElement = document.getElementById("productDetails");
                                        if (editorElement.value == '') {
                                            editorElement.parentNode.classList.add("is-invalid");
                                            editorElement.parentNode.classList.remove("is-valid");
                                        } else {
                                            editorElement.parentNode.classList.remove("is-invalid");
                                            editorElement.parentNode.classList.add("is-valid");
                                        }

                                    }, false);
                                }, false);
                            }());
                        </script>
                            
                    </div>
                    <div class="col-md-3">
                        <div class="card mt-4">
                            <h6 class="card-header white">Publish Box</h6>
                            <div class="card-body text-success">

                                <div class="custom-control custom-checkbox mb-3">
                                    <input type="checkbox" class="custom-control-input" id="customControlValidation1" required>
                                    <label class="custom-control-label" for="customControlValidation1">I agree your terms and condition</label>
                                    <div class="invalid-feedback">Example invalid feedback text</div>
                                </div>
                            </div>
                            <div class="card-footer bg-transparent">
                                <button class="btn btn-primary" type="submit">Publish</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>
</div>
<?php 
// right side menu
include_once("template/activity.php");
?>



<?php 
// right side menu
include_once("include/right-sidebar.php");
?>

<?php 
// right side menu
include_once("include/footer.php");
?>